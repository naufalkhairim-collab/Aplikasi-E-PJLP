<?php
// 1. Cek Login
if (!isset($_SESSION['level'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$level = $_SESSION['level'];
$tahun_filter = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// 2. Logika Penentuan ID PJLP
$id_pjlp_target = '';

if ($level == 'pjlp') {
    // Jika PJLP, ID target adalah dirinya sendiri
    $id_pjlp_target = $_SESSION['id_user']; 
} else {
    // Jika Admin/Pimpinan, ambil dari filter GET
    if (isset($_GET['id_pjlp'])) {
        $id_pjlp_target = amankan_input($_GET['id_pjlp']);
    }
}

// ==================================================================================
// TAMPILAN UTAMA
// ==================================================================================
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Riwayat Penerimaan Gaji</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Riwayat Gaji</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-12">
        
        <div class="card mb-3 border-0 shadow-sm">
            <div class="card-body py-3">
                <form action="index.php" method="GET">
                    <input type="hidden" name="page" value="riwayat_gaji">
                    
                    <div class="row align-items-end g-2">
                        <?php if ($level != 'pjlp'): ?>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Pilih Pegawai</label>
                            <select name="id_pjlp" class="form-select select2" required>
                                <option value="" disabled selected>-- Cari Nama Pegawai --</option>
                                <?php
                                $q_pjlp = mysqli_query($koneksi, "SELECT id_pjlp, nama_lengkap, nik FROM tbl_pjlp ORDER BY nama_lengkap ASC");
                                while ($p = mysqli_fetch_assoc($q_pjlp)) {
                                    $sel = ($p['id_pjlp'] == $id_pjlp_target) ? 'selected' : '';
                                    echo "<option value='{$p['id_pjlp']}' $sel>{$p['nama_lengkap']} (NIK: {$p['nik']})</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <div class="col-md-2">
                            <label class="form-label small fw-bold">Tahun</label>
                            <select name="tahun" class="form-select">
                                <?php
                                $thn_skrg = date('Y');
                                for ($t = $thn_skrg; $t >= 2023; $t--) {
                                    $sel = ($t == $tahun_filter) ? 'selected' : '';
                                    echo "<option value='$t' $sel>$t</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search me-1"></i> Tampilkan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if (!empty($id_pjlp_target)): ?>
            
            <?php
            // Ambil Info Pegawai
            $q_info = mysqli_query($koneksi, "SELECT nama_lengkap, nik FROM tbl_pjlp WHERE id_pjlp='$id_pjlp_target'");
            $d_info = mysqli_fetch_assoc($q_info);
            ?>

            <div class="card border-0 shadow-sm">
                <div class="card-header border-bottom bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-1 fw-bold text-dark">Data Gaji: <?= $d_info['nama_lengkap'] ?></h5>
                            <span class="text-muted small"><i class="bi bi-person-badge me-1"></i> NIK: <?= $d_info['nik'] ?> | <i class="bi bi-calendar-event me-1"></i> Tahun: <?= $tahun_filter ?></span>
                        </div>
                        <div class="d-none d-md-block">
                            <div class="p-2 bg-light rounded text-center border" style="min-width: 150px;">
                                <small class="d-block text-muted" style="font-size: 10px;">TOTAL PENDAPATAN (YTD)</small>
                                <?php
                                // Hitung Total Setahun
                                $q_total = mysqli_query($koneksi, "
                                    SELECT SUM(py.gaji_diterima) as total
                                    FROM tbl_payroll py
                                    JOIN tbl_kontrak k ON py.id_kontrak = k.id_kontrak
                                    WHERE k.id_pjlp = '$id_pjlp_target' AND py.tahun = '$tahun_filter' AND py.status_bayar='Lunas'
                                ");
                                $d_total = mysqli_fetch_assoc($q_total);
                                ?>
                                <span class="fw-bold text-success fs-5">Rp <?= number_format($d_total['total'], 0, ',', '.') ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Periode</th>
                                    <th>Unit Kerja</th>
                                    <th>Gaji Pokok</th>
                                    <th class="text-success">Tunjangan</th>
                                    <th class="text-danger">Potongan</th>
                                    <th>Take Home Pay</th>
                                    <th>Status</th>
                                    <th class="text-end pe-4">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $bulan_indo = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                                
                                $query = mysqli_query($koneksi, "
                                    SELECT py.*, u.nama_unit_kerja, u.id_unit_kerja
                                    FROM tbl_payroll py
                                    JOIN tbl_kontrak k ON py.id_kontrak = k.id_kontrak
                                    JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                    WHERE k.id_pjlp = '$id_pjlp_target' AND py.tahun = '$tahun_filter'
                                    ORDER BY py.bulan DESC
                                ");

                                if (mysqli_num_rows($query) > 0) {
                                    while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td class="ps-4 fw-medium">
                                        <?= $bulan_indo[$row['bulan']] ?>
                                    </td>
                                    <td class="text-muted small">
                                        <?= $row['nama_unit_kerja'] ?>
                                    </td>
                                    <td>Rp <?= number_format($row['gaji_pokok'], 0, ',', '.') ?></td>
                                    <td class="text-success">+ Rp <?= number_format($row['total_tunjangan'], 0, ',', '.') ?></td>
                                    <td class="text-danger">- Rp <?= number_format($row['total_potongan'], 0, ',', '.') ?></td>
                                    <td class="fw-bold text-primary">Rp <?= number_format($row['gaji_diterima'], 0, ',', '.') ?></td>
                                    <td>
                                        <?php if($row['status_bayar'] == 'Lunas'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill">Lunas</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill">Proses</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <a href="cetak_laporan.php?jenis=10&unit=<?= $row['id_unit_kerja'] ?>&bulan=<?= $row['bulan'] ?>&tahun=<?= $row['tahun'] ?>" target="_blank" class="btn btn-sm btn-outline-dark" data-bs-toggle="tooltip" title="Cetak Slip">
                                            <i class="bi bi-printer me-1"></i> Slip
                                        </a>
                                    </td>
                                </tr>
                                <?php 
                                    } 
                                } else {
                                    echo '<tr><td colspan="8" class="text-center py-4 text-muted">Belum ada data gaji untuk periode ini.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        <?php elseif ($level != 'pjlp'): ?>
            <div class="alert alert-info d-flex align-items-center border-0 shadow-sm" role="alert">
                <i class="bi bi-info-circle fs-4 me-3"></i>
                <div>
                    <strong>Informasi:</strong> Silakan pilih <strong>Nama Pegawai</strong> pada filter di atas untuk melihat riwayat gaji.
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>