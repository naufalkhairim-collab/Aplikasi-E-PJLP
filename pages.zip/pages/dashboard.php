<?php
// 1. Cek Login
if (!isset($_SESSION['status_login'])) {
    echo "<script>window.location.href='login.php';</script>";
    exit();
}

$level    = $_SESSION['level'];
$id_user  = $_SESSION['id_user'];
$tahun    = date('Y');
$hari_ini = date('Y-m-d');

// 2. FIX: Ambil Nama Lengkap jika Session Kosong
$nama_lengkap = isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : 'Pengguna';

if ($nama_lengkap == 'Pengguna') {
    if ($level == 'pjlp') {
        $q_n = mysqli_query($koneksi, "SELECT nama_lengkap FROM tbl_pjlp WHERE id_pjlp='$id_user'");
    } else {
        $q_n = mysqli_query($koneksi, "SELECT nama_lengkap FROM tbl_users WHERE id_user='$id_user'");
    }
    
    if ($d_n = mysqli_fetch_assoc($q_n)) {
        $nama_lengkap = $d_n['nama_lengkap'];
        $_SESSION['nama_lengkap'] = $nama_lengkap; // Simpan ke session biar hemat query
    }
}
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<div class="d-flex align-items-center mt-2 mb-4">
    <div>
        <h4 class="mb-0 fw-bold">Dashboard <?= ucfirst($level) ?></h4>
        <small class="text-muted">Selamat Datang, <strong><?= $nama_lengkap ?></strong></small>
    </div>
    <div class="ms-auto">
        <span class="badge bg-white text-dark border px-3 py-2 shadow-sm">
            <i class="bi bi-calendar-event me-2"></i> <?= date('d F Y') ?>
        </span>
    </div>
</div>

<?php 
// ============================================================================
// TAMPILAN 1: ADMIN & PIMPINAN
// ============================================================================
if ($level == 'admin' || $level == 'pimpinan'): 
    
    // --- [REVISI 2: LOGIC NOTIFIKASI KONTRAK] ---
    
    // A. Alert Kritis: Kontrak Sudah Lewat Tanggal (Expired) tapi Status Masih Aktif
    $q_expired = mysqli_query($koneksi, "
        SELECT k.nomor_kontrak, p.nama_lengkap, k.tgl_selesai_kontrak
        FROM tbl_kontrak k
        JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
        WHERE k.status_kontrak='Aktif' AND k.tgl_selesai_kontrak < CURDATE()
    ");
    $jml_expired = mysqli_num_rows($q_expired);

    // B. Alert Peringatan: Kontrak Akan Habis (H-30)
    $q_soon = mysqli_query($koneksi, "
        SELECT k.nomor_kontrak, p.nama_lengkap, k.tgl_selesai_kontrak,
        DATEDIFF(k.tgl_selesai_kontrak, CURDATE()) as sisa_hari
        FROM tbl_kontrak k
        JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
        WHERE k.status_kontrak='Aktif'
        AND DATEDIFF(k.tgl_selesai_kontrak, CURDATE()) BETWEEN 0 AND 30
        ORDER BY sisa_hari ASC
    ");
    $jml_soon = mysqli_num_rows($q_soon);

    // C. Pengajuan Cuti Menunggu
    $q_notif_cuti = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_pengajuan_cuti WHERE status_pengajuan='Diajukan'");
    $d_notif_cuti = mysqli_fetch_assoc($q_notif_cuti);
    // ------------------------------------

    // DATA WIDGET UTAMA
    $q_pjlp = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_pjlp WHERE status_pjlp='Aktif'");
    $d_pjlp = mysqli_fetch_assoc($q_pjlp);

    $d_kontrak_kritis = $jml_expired + $jml_soon; // Total Widget Kritis

    $q_absen = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_absensi WHERE tanggal='$hari_ini' AND status_kehadiran='Hadir'");
    $d_absen = mysqli_fetch_assoc($q_absen);

    // DATA GRAFIK
    $q_pagu = mysqli_query($koneksi, "SELECT SUM(pagu_anggaran_rekening) as total FROM tbl_dpa_detail");
    $d_pagu = mysqli_fetch_assoc($q_pagu);
    $total_pagu = $d_pagu['total'] ?? 0;

    $q_real = mysqli_query($koneksi, "SELECT SUM(gaji_diterima) as total FROM tbl_payroll WHERE status_bayar='Lunas'");
    $d_real = mysqli_fetch_assoc($q_real);
    $total_real = $d_real['total'] ?? 0;
    
    $sisa_pagu = $total_pagu - $total_real;
?>
    
    <div class="row mb-3">
        <div class="col-12">
            
            <?php if ($jml_expired > 0): ?>
            <div class="alert alert-danger shadow-sm border-0 d-flex align-items-start" role="alert">
                <div class="me-3 fs-2"><i class="bi bi-x-octagon-fill"></i></div>
                <div>
                    <h6 class="alert-heading fw-bold mb-1">Peringatan: <?= $jml_expired ?> Kontrak Telah Kadaluarsa!</h6>
                    <p class="small mb-1">Kontrak berikut sudah lewat tanggal selesai namun statusnya masih <b>Aktif</b>. Harap segera perbarui atau non-aktifkan.</p>
                    <ul class="mb-0 small ps-3">
                        <?php while($ex = mysqli_fetch_assoc($q_expired)) { ?>
                            <li><strong><?= $ex['nama_lengkap'] ?></strong> - Berakhir: <?= date('d-m-Y', strtotime($ex['tgl_selesai_kontrak'])) ?></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($jml_soon > 0): ?>
            <div class="alert alert-warning shadow-sm border-0 d-flex align-items-start" role="alert">
                <div class="me-3 fs-2"><i class="bi bi-exclamation-triangle-fill"></i></div>
                <div>
                    <h6 class="alert-heading fw-bold mb-1">Perhatian: <?= $jml_soon ?> Kontrak Segera Berakhir</h6>
                    <ul class="mb-0 small ps-3">
                        <?php 
                        $limit = 0;
                        while($soon = mysqli_fetch_assoc($q_soon)) { 
                            if($limit < 3) { // Tampilkan max 3 nama
                        ?>
                            <li><strong><?= $soon['nama_lengkap'] ?></strong> (Sisa: <?= $soon['sisa_hari'] ?> hari lagi)</li>
                        <?php 
                            }
                            $limit++;
                        } 
                        if($jml_soon > 3) echo "<li>Dan ".($jml_soon-3)." pegawai lainnya...</li>";
                        ?>
                    </ul>
                    <a href="index.php?page=kontrak_kerja" class="btn btn-sm btn-light text-warning mt-2 fw-bold">Kelola Kontrak</a>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($d_notif_cuti['total'] > 0): ?>
            <div class="alert alert-info shadow-sm border-0 d-flex align-items-center" role="alert">
                <div class="me-3 fs-2"><i class="bi bi-inbox-fill"></i></div>
                <div>
                    <h6 class="alert-heading fw-bold mb-1">Persetujuan Cuti Diperlukan</h6>
                    <p class="mb-0 small">Ada <strong><?= $d_notif_cuti['total'] ?></strong> pengajuan cuti baru menunggu tindakan.</p>
                    <a href="index.php?page=pengajuan_cuti_admin" class="btn btn-sm btn-light text-primary mt-2 fw-bold">Lihat Pengajuan</a>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 border-start border-4 border-primary">
                <div class="card-body">
                    <small class="text-muted fw-bold">TOTAL PJLP AKTIF</small>
                    <h3 class="mb-0 fw-bold text-primary"><?= $d_pjlp['total'] ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 border-start border-4 border-danger">
                <div class="card-body">
                    <small class="text-muted fw-bold">KONTRAK KRITIS</small>
                    <h3 class="mb-0 fw-bold text-danger"><?= $d_kontrak_kritis ?></h3>
                    <small class="text-danger" style="font-size: 10px;">Expired / < 30 Hari</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 border-start border-4 border-warning">
                <div class="card-body">
                    <small class="text-muted fw-bold">APPROVAL CUTI</small>
                    <h3 class="mb-0 fw-bold text-warning"><?= $d_notif_cuti['total'] ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm h-100 border-start border-4 border-success">
                <div class="card-body">
                    <small class="text-muted fw-bold">HADIR HARI INI</small>
                    <h3 class="mb-0 fw-bold text-success"><?= $d_absen['total'] ?></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0 fw-bold"><i class="bi bi-pie-chart-fill me-2"></i>Persentase Realisasi Anggaran</h6>
                </div>
                <div class="card-body">
                    <div id="chartRealisasi"></div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0 fw-bold"><i class="bi bi-trophy-fill me-2"></i>Top Kinerja Bulan Ini</h6>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php
                        $q_rank = mysqli_query($koneksi, "
                            SELECT p.nama_lengkap, k.skor_kinerja 
                            FROM tbl_kinerja k 
                            JOIN tbl_kontrak c ON k.id_kontrak = c.id_kontrak 
                            JOIN tbl_pjlp p ON c.id_pjlp = p.id_pjlp 
                            WHERE k.bulan = MONTH(CURDATE()) AND k.tahun = YEAR(CURDATE())
                            ORDER BY k.skor_kinerja DESC LIMIT 5
                        ");
                        if(mysqli_num_rows($q_rank) > 0){
                            while($r = mysqli_fetch_assoc($q_rank)){
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>
                                        {$r['nama_lengkap']}
                                        <span class='badge bg-primary rounded-pill'>{$r['skor_kinerja']}</span>
                                      </li>";
                            }
                        } else {
                            echo "<li class='list-group-item text-center text-muted py-4'>Belum ada penilaian bulan ini.</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
        var optionsRealisasi = {
            series: [<?= $total_real ?>, <?= $sisa_pagu ?>],
            labels: ['Realisasi', 'Sisa'],
            chart: { type: 'donut', height: 300 },
            colors: ['#198754', '#e9ecef'],
            plotOptions: {
                pie: { donut: { size: '70%', labels: { show: true, total: { show: true, label: 'Total Pagu', formatter: function (w) { let total = w.globals.seriesTotals.reduce((a, b) => a + b, 0); return 'Rp ' + (total / 1000000).toFixed(1) + ' Jt'; } } } } }
            },
            dataLabels: { enabled: false },
            legend: { position: 'bottom' }
        };
        var chart = new ApexCharts(document.querySelector("#chartRealisasi"), optionsRealisasi);
        chart.render();
    </script>


<?php 
// ============================================================================
// TAMPILAN 2: KEUANGAN
// ============================================================================
elseif ($level == 'keuangan'): 

    $q_pagu = mysqli_query($koneksi, "SELECT SUM(pagu_anggaran_rekening) as total FROM tbl_dpa_detail");
    $d_pagu = mysqli_fetch_assoc($q_pagu);
    $total_pagu = $d_pagu['total'] ?? 0;

    $q_lunas = mysqli_query($koneksi, "SELECT SUM(gaji_diterima) as total FROM tbl_payroll WHERE status_bayar='Lunas'");
    $d_lunas = mysqli_fetch_assoc($q_lunas);
    $total_lunas = $d_lunas['total'] ?? 0;

    $q_hutang = mysqli_query($koneksi, "SELECT COUNT(*) as jumlah, SUM(gaji_diterima) as total FROM tbl_payroll WHERE status_bayar='Proses'");
    $d_hutang = mysqli_fetch_assoc($q_hutang);
?>
    
    <?php if ($d_hutang['jumlah'] > 0): ?>
    <div class="row mb-3">
        <div class="col-12">
            <div class="alert alert-warning shadow-sm border-0 d-flex align-items-center" role="alert">
                <div class="me-3 fs-2"><i class="bi bi-cash-coin"></i></div>
                <div>
                    <h6 class="alert-heading fw-bold mb-1">Pembayaran Tertunda</h6>
                    <p class="mb-0 small">Ada <strong><?= $d_hutang['jumlah'] ?></strong> pegawai belum dibayar (Total: Rp <?= number_format($d_hutang['total'],0,',','.') ?>).</p>
                    <a href="index.php?page=proses_payroll" class="btn btn-sm btn-light text-warning mt-2 fw-bold">Proses Sekarang</a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 bg-primary text-white">
                <div class="card-body">
                    <small class="text-white-50 fw-bold">TOTAL PAGU</small>
                    <h3 class="mb-0 fw-bold">Rp <?= number_format($total_pagu, 0, ',', '.') ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 bg-success text-white">
                <div class="card-body">
                    <small class="text-white-50 fw-bold">REALISASI</small>
                    <h3 class="mb-0 fw-bold">Rp <?= number_format($total_lunas, 0, ',', '.') ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 bg-warning text-dark">
                <div class="card-body">
                    <small class="text-dark-50 fw-bold">BELUM BAYAR</small>
                    <h3 class="mb-0 fw-bold">Rp <?= number_format($d_hutang['total'], 0, ',', '.') ?></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0 fw-bold">Grafik Keuangan</h6>
                </div>
                <div class="card-body">
                    <div id="chartKeuangan"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var optionsKeuangan = {
            series: [{ name: 'Nominal', data: [<?= $total_pagu ?>, <?= $total_lunas ?>, <?= $d_hutang['total'] ?? 0 ?>] }],
            chart: { type: 'bar', height: 350 },
            plotOptions: { bar: { borderRadius: 4, horizontal: false, columnWidth: '50%' } },
            dataLabels: { enabled: false },
            xaxis: { categories: ['Pagu', 'Realisasi', 'Hutang'] },
            colors: ['#0d6efd', '#198754', '#ffc107'],
            yaxis: { labels: { formatter: function (value) { return "Rp " + (value / 1000000).toFixed(0) + " Jt"; } } }
        };
        var chartK = new ApexCharts(document.querySelector("#chartKeuangan"), optionsKeuangan);
        chartK.render();
    </script>


<?php 
// ============================================================================
// TAMPILAN 3: PJLP (PEGAWAI)
// ============================================================================
elseif ($level == 'pjlp'): 
    
    // Cek Kontrak Pribadi
    $q_kontrak = mysqli_query($koneksi, "
        SELECT id_kontrak, id_unit_kerja, tgl_selesai_kontrak, 
        DATEDIFF(tgl_selesai_kontrak, CURDATE()) as sisa_hari,
        status_kontrak
        FROM tbl_kontrak 
        WHERE id_pjlp='$id_user' AND status_kontrak='Aktif'
    ");
    $d_kontrak = mysqli_fetch_assoc($q_kontrak);
    $id_kontrak = $d_kontrak['id_kontrak'] ?? 0;
    
    // Cek Absen
    $q_absen_today = mysqli_query($koneksi, "SELECT * FROM tbl_absensi WHERE id_kontrak='$id_kontrak' AND tanggal='$hari_ini'");
    $d_absen_today = mysqli_fetch_assoc($q_absen_today);
    $jam_masuk  = $d_absen_today['jam_masuk'] ?? '-';
    $jam_pulang = $d_absen_today['jam_pulang'] ?? '-';
    $sudah_masuk = ($jam_masuk != '-');
    $sudah_pulang = ($jam_pulang != '-');

    // Cek Tugas
    $q_tugas = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tbl_tugas WHERE id_pjlp_penerima='$id_user' AND status_tugas='Baru'");
    $d_tugas = mysqli_fetch_assoc($q_tugas);

    // Lokasi Kantor
    $q_lokasi = mysqli_query($koneksi, "SELECT * FROM tbl_lokasi_kantor LIMIT 1");
    $d_lokasi = mysqli_fetch_assoc($q_lokasi);
    $lat_kantor = $d_lokasi['latitude'];
    $long_kantor = $d_lokasi['longitude'];
    $radius = $d_lokasi['radius_meter'];
?>

    <div class="row mb-3">
        <div class="col-12">
            
            <?php if ($d_kontrak && $d_kontrak['sisa_hari'] < 0): ?>
            <div class="alert alert-danger shadow-sm border-0 mb-3" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bi bi-x-circle-fill fs-3 me-3"></i>
                    <div>
                        <h6 class="fw-bold mb-1">Masa Kontrak Telah Berakhir</h6>
                        <p class="mb-0 small">Kontrak Anda berakhir pada <?= date('d M Y', strtotime($d_kontrak['tgl_selesai_kontrak'])) ?>. Hubungi admin untuk pembaruan.</p>
                    </div>
                </div>
            </div>

            <?php elseif ($d_kontrak && $d_kontrak['sisa_hari'] <= 30): ?>
            <div class="alert alert-warning shadow-sm border-0 mb-3" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bi bi-clock-history fs-3 me-3"></i>
                    <div>
                        <h6 class="fw-bold mb-1">Masa Kontrak Segera Berakhir</h6>
                        <p class="mb-0 small">
                            Tersisa <strong><?= $d_kontrak['sisa_hari'] ?> Hari</strong> lagi (<?= date('d M Y', strtotime($d_kontrak['tgl_selesai_kontrak'])) ?>).
                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($d_tugas['total'] > 0): ?>
            <div class="alert alert-info shadow-sm border-0" role="alert">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <i class="bi bi-clipboard-check me-2"></i>
                        Anda memiliki <strong><?= $d_tugas['total'] ?> Tugas Baru</strong>.
                    </div>
                    <a href="index.php?page=tugas_saya" class="btn btn-sm btn-light text-info fw-bold">Lihat</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-primary text-white">
                    <h6 class="card-title mb-0">Absensi Hari Ini</h6>
                </div>
                <div class="card-body text-center">
                    <h2 class="fw-bold mb-3"><?= date('H:i') ?></h2>
                    <div class="row mb-4">
                        <div class="col-6 border-end">
                            <small class="text-muted d-block">MASUK</small>
                            <span class="fw-bold fs-5 <?= $sudah_masuk ? 'text-success' : 'text-secondary' ?>"><?= $jam_masuk ?></span>
                        </div>
                        <div class="col-6">
                            <small class="text-muted d-block">PULANG</small>
                            <span class="fw-bold fs-5 <?= $sudah_pulang ? 'text-success' : 'text-secondary' ?>"><?= $jam_pulang ?></span>
                        </div>
                    </div>
                    <?php if (!$sudah_masuk): ?>
                        <a href="index.php?page=absen_masuk" class="btn btn-primary w-100 py-2 mb-2">ABSEN MASUK</a>
                    <?php elseif ($sudah_masuk && !$sudah_pulang): ?>
                        <a href="index.php?page=absen_pulang" class="btn btn-warning w-100 py-2 mb-2">ABSEN PULANG</a>
                    <?php else: ?>
                        <div class="alert alert-success py-2 mb-0">Selesai</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0 fw-bold">Lokasi</h6>
                </div>
                <div class="card-body p-0">
                    <div id="map" style="height: 250px; width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var map = L.map('map').setView([<?= $lat_kantor ?>, <?= $long_kantor ?>], 16);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
        var kantor = L.marker([<?= $lat_kantor ?>, <?= $long_kantor ?>]).addTo(map).bindPopup("<b>Kantor</b>").openPopup();
        L.circle([<?= $lat_kantor ?>, <?= $long_kantor ?>], { color: 'green', fillColor: '#28a745', fillOpacity: 0.2, radius: <?= $radius ?> }).addTo(map);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var lat = position.coords.latitude;
                var long = position.coords.longitude;
                var userMarker = L.marker([lat, long], { icon: L.icon({ iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png', iconSize: [25, 41], iconAnchor: [12, 41] }) }).addTo(map).bindPopup("Anda");
                var group = new L.featureGroup([kantor, userMarker]);
                map.fitBounds(group.getBounds());
            });
        }
    </script>

<?php endif; ?>