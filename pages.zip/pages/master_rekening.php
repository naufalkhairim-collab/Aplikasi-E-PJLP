<?php
// 1. Keamanan: Hanya Admin & Keuangan
if (!in_array($_SESSION['level'], ['admin', 'keuangan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- SIMPAN DATA ---
if (isset($_POST['btn_simpan'])) {
    $kode = amankan_input($_POST['kode_rekening']);
    $nama = amankan_input($_POST['nama_rekening']);

    // Validasi Duplikasi Kode
    $cek = mysqli_query($koneksi, "SELECT kode_rekening FROM tbl_master_rekening WHERE kode_rekening='$kode'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Gagal', 'Kode rekening sudah terdaftar!');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "INSERT INTO tbl_master_rekening (kode_rekening, nama_rekening) VALUES ('$kode', '$nama')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Rekening belanja ditambahkan');
        echo "<script>window.location.href='index.php?page=master_rekening';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id   = amankan_input($_POST['id_rekening']);
    $kode = amankan_input($_POST['kode_rekening']);
    $nama = amankan_input($_POST['nama_rekening']);

    // Validasi Duplikasi Kode (kecuali punya sendiri)
    $cek = mysqli_query($koneksi, "SELECT kode_rekening FROM tbl_master_rekening WHERE kode_rekening='$kode' AND id_rekening != '$id'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Gagal', 'Kode rekening sudah digunakan data lain!');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "UPDATE tbl_master_rekening SET kode_rekening='$kode', nama_rekening='$nama' WHERE id_rekening='$id'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data rekening diperbarui');
        echo "<script>window.location.href='index.php?page=master_rekening';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    // Cek Relasi dengan Tabel DPA Detail
    $cek_dpa = mysqli_query($koneksi, "SELECT id_dpa_detail FROM tbl_dpa_detail WHERE id_rekening='$id'");
    
    if (mysqli_num_rows($cek_dpa) > 0) {
        set_notifikasi('error', 'Gagal Hapus', 'Rekening ini sedang digunakan dalam DPA. Hapus data DPA terkait terlebih dahulu.');
        echo "<script>window.location.href='index.php?page=master_rekening';</script>";
        exit();
    }

    $query = "DELETE FROM tbl_master_rekening WHERE id_rekening='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Rekening berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=master_rekening';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Master Kode Rekening Belanja</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Master Rekening</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Rekening Belanja</h5>
                    <a href="index.php?page=master_rekening" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kode Rekening <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_rekening" class="form-control" required placeholder="Contoh: 5.1.02.02.01.0013">
                                <div class="form-text">Masukkan kode lengkap sesuai standar akuntansi.</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Uraian Rekening <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_rekening" class="form-control" required placeholder="Contoh: Belanja Jasa Tenaga Kebersihan">
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_master_rekening WHERE id_rekening='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=master_rekening';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Rekening Belanja</h5>
                    <a href="index.php?page=master_rekening" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_rekening" value="<?= $d['id_rekening'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kode Rekening <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_rekening" class="form-control" value="<?= $d['kode_rekening'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Uraian Rekening <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_rekening" class="form-control" value="<?= $d['nama_rekening'] ?>" required>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Kode Rekening</h5>
                    <a href="index.php?page=master_rekening&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Rekening
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Kode Rekening</th>
                                    <th>Uraian Rekening</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_master_rekening ORDER BY kode_rekening ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="badge bg-light text-dark border font-monospace"><?= $row['kode_rekening'] ?></span></td>
                                    <td><?= $row['nama_rekening'] ?></td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=master_rekening&act=edit&id=<?= $row['id_rekening'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=master_rekening&act=hapus&id=<?= $row['id_rekening'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>