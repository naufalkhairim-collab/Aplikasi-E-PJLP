<?php
// 1. Keamanan: Hanya Admin/Pimpinan/Keuangan
if (!in_array($_SESSION['level'], ['admin', 'pimpinan', 'keuangan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Setup Filter
$tanggal_filter = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');
$unit_filter    = isset($_GET['unit']) ? $_GET['unit'] : '';

// 3. Proses Hapus (Hanya Admin)
if (isset($_GET['act']) && $_GET['act'] == 'hapus' && isset($_GET['id'])) {
    if ($_SESSION['level'] == 'admin') {
        $id_absen = amankan_input($_GET['id']);
        
        // Hapus File Fisik
        $q_cek = mysqli_query($koneksi, "SELECT foto_masuk, foto_pulang FROM tbl_absensi WHERE id_absen='$id_absen'");
        $d_cek = mysqli_fetch_assoc($q_cek);
        
        if(!empty($d_cek['foto_masuk']) && file_exists("assets/uploads/absensi/".$d_cek['foto_masuk'])){
            unlink("assets/uploads/absensi/".$d_cek['foto_masuk']);
        }
        if(!empty($d_cek['foto_pulang']) && file_exists("assets/uploads/absensi/".$d_cek['foto_pulang'])){
            unlink("assets/uploads/absensi/".$d_cek['foto_pulang']);
        }

        $query = "DELETE FROM tbl_absensi WHERE id_absen='$id_absen'";
        if (mysqli_query($koneksi, $query)) {
            set_notifikasi('success', 'Terhapus', 'Data absensi berhasil dihapus');
        } else {
            set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
        }
    } else {
        set_notifikasi('error', 'Akses Ditolak', 'Hanya admin yang bisa menghapus data absensi');
    }
    // Redirect agar parameter hapus hilang
    echo "<script>window.location.href='index.php?page=absensi_harian&tanggal=$tanggal_filter&unit=$unit_filter';</script>";
    exit();
}
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Rekap Absensi Harian</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Absensi Harian</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-12">
        
        <div class="card mb-3">
            <div class="card-body py-3">
                <form action="index.php" method="GET">
                    <input type="hidden" name="page" value="absensi_harian">
                    <div class="row align-items-end">
                        <div class="col-md-3 mb-2 mb-md-0">
                            <label class="form-label small fw-bold">Tanggal</label>
                            <input type="date" name="tanggal" class="form-control" value="<?= $tanggal_filter ?>">
                        </div>
                        <div class="col-md-4 mb-2 mb-md-0">
                            <label class="form-label small fw-bold">Unit Kerja</label>
                            <select name="unit" class="form-select">
                                <option value="">- Semua Unit Kerja -</option>
                                <?php
                                $q_unit = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                                while ($u = mysqli_fetch_assoc($q_unit)) {
                                    $sel = ($u['id_unit_kerja'] == $unit_filter) ? 'selected' : '';
                                    echo "<option value='{$u['id_unit_kerja']}' $sel>{$u['nama_unit_kerja']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-filter me-1"></i> Tampilkan Data</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    Data Kehadiran: <?= date('d M Y', strtotime($tanggal_filter)) ?>
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama Pegawai</th>
                                <th>Unit Kerja</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Status</th>
                                <th width="10%">Bukti</th>
                                <?php if($_SESSION['level'] == 'admin'): ?>
                                <th width="5%">Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Query Data Absensi + Join Pegawai + Join Unit
                            $query_str = "
                                SELECT a.*, p.nama_lengkap, p.nik, u.nama_unit_kerja 
                                FROM tbl_absensi a
                                JOIN tbl_kontrak k ON a.id_kontrak = k.id_kontrak
                                JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                WHERE a.tanggal = '$tanggal_filter'
                            ";

                            if (!empty($unit_filter)) {
                                $query_str .= " AND k.id_unit_kerja = '$unit_filter'";
                            }

                            $query_str .= " ORDER BY a.jam_masuk DESC";
                            $query = mysqli_query($koneksi, $query_str);
                            $no = 1;

                            while ($row = mysqli_fetch_assoc($query)) {
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-xs bg-light rounded-circle d-flex align-items-center justify-content-center me-2">
                                            <i class="bi bi-person text-muted"></i>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fs-14"><?= $row['nama_lengkap'] ?></h6>
                                            <small class="text-muted"><?= $row['nik'] ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= $row['nama_unit_kerja'] ?></td>
                                
                                <td>
                                    <?php if($row['jam_masuk']): ?>
                                        <span class="d-block fw-bold text-dark"><?= date('H:i', strtotime($row['jam_masuk'])) ?></span>
                                        <?php if($row['status_masuk'] == 'Terlambat'): ?>
                                            <span class="badge bg-danger-subtle text-danger" style="font-size: 10px;">Terlambat</span>
                                        <?php else: ?>
                                            <span class="badge bg-success-subtle text-success" style="font-size: 10px;">Tepat Waktu</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php if($row['jam_pulang']): ?>
                                        <span class="fw-bold text-dark"><?= date('H:i', strtotime($row['jam_pulang'])) ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning">Belum Pulang</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php 
                                        $st = $row['status_kehadiran'];
                                        $color = 'secondary';
                                        if($st == 'Hadir') $color = 'success';
                                        elseif($st == 'Sakit') $color = 'info';
                                        elseif($st == 'Izin') $color = 'warning';
                                        elseif($st == 'Alpa') $color = 'danger';
                                    ?>
                                    <span class="badge bg-<?= $color ?>-subtle text-<?= $color ?>"><?= $st ?></span>
                                </td>

                                <td>
                                    <div class="d-flex gap-1">
                                        <?php if(!empty($row['foto_masuk'])): ?>
                                            <button type="button" class="btn btn-sm btn-light border" 
                                                onclick="lihatFoto('assets/uploads/absensi/<?= $row['foto_masuk'] ?>', 'Foto Masuk: <?= addslashes($row['nama_lengkap']) ?>')"
                                                data-bs-toggle="tooltip" title="Foto Masuk">
                                                <i class="bi bi-image text-primary"></i>
                                            </button>
                                        <?php endif; ?>

                                        <?php if(!empty($row['lat_masuk'])): ?>
                                            <button type="button" class="btn btn-sm btn-light border"
                                                onclick="lihatPeta(<?= $row['lat_masuk'] ?>, <?= $row['long_masuk'] ?>, 'Lokasi Masuk: <?= addslashes($row['nama_lengkap']) ?>')"
                                                data-bs-toggle="tooltip" title="Lokasi Masuk">
                                                <i class="bi bi-geo-alt-fill text-danger"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>

                                <?php if($_SESSION['level'] == 'admin'): ?>
                                <td>
                                    <button onclick="konfirmasiHapus('index.php?page=absensi_harian&act=hapus&id=<?= $row['id_absen'] ?>&tanggal=<?= $tanggal_filter ?>&unit=<?= $unit_filter ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus Log">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalFoto" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalFotoTitle">Bukti Foto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-0">
                <img src="" id="imgViewer" class="img-fluid" style="width: 100%; max-height: 500px; object-fit: contain;">
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalPeta" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalPetaTitle">Lokasi Absensi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div id="mapViewer" style="height: 450px; width: 100%;"></div>
            </div>
        </div>
    </div>
</div>

<script>
    // --- FUNGSI LIHAT FOTO ---
    function lihatFoto(url, title) {
        document.getElementById('imgViewer').src = url;
        document.getElementById('modalFotoTitle').innerText = title;
        var myModal = new bootstrap.Modal(document.getElementById('modalFoto'));
        myModal.show();
    }

    // --- FUNGSI LIHAT PETA ---
    var map; // Global variable untuk map agar bisa direfresh

    function lihatPeta(lat, lng, title) {
        document.getElementById('modalPetaTitle').innerText = title;
        
        var myModalEl = document.getElementById('modalPeta');
        var myModal = new bootstrap.Modal(myModalEl);
        myModal.show();

        // Event saat modal sudah benar-benar muncul (penting untuk Leaflet rendering)
        myModalEl.addEventListener('shown.bs.modal', function () {
            // Jika map sudah ada, hapus dulu
            if (map) {
                map.remove();
            }

            // Inisialisasi Map Baru
            map = L.map('mapViewer').setView([lat, lng], 16);

            // Layer
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© OpenStreetMap'
            }).addTo(map);

            // Marker
            L.marker([lat, lng]).addTo(map)
                .bindPopup(title)
                .openPopup();
            
            // Invalidate size agar map tidak abu-abu sebagian
            map.invalidateSize();
        });
    }
</script>