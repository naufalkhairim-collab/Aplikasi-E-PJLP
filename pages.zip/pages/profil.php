<?php
// Ambil ID dan Level dari Session
$id_user = $_SESSION['id_user'];
$level   = $_SESSION['level'];

// Tentukan Tabel dan Kolom berdasarkan Level
if ($level == 'admin' || $level == 'pimpinan' || $level == 'keuangan') {
    $tabel = 'tbl_users';
    $pk    = 'id_user';
} else {
    // Asumsi selain 3 level di atas adalah PJLP
    $tabel = 'tbl_pjlp';
    $pk    = 'id_pjlp';
}

// ==================================================================================
// PROSES UPDATE PROFIL
// ==================================================================================
if (isset($_POST['btn_simpan'])) {
    $nama_lengkap = amankan_input($_POST['nama_lengkap']);
    $email        = amankan_input($_POST['email']);
    $no_hp        = amankan_input($_POST['no_hp']);
    
    // Alamat hanya untuk PJLP
    $alamat_query = "";
    if ($tabel == 'tbl_pjlp') {
        $alamat = amankan_input($_POST['alamat']);
        $alamat_query = ", alamat='$alamat'";
    }

    // Logic Password
    $pass_query = "";
    if (!empty($_POST['password'])) {
        $password = md5($_POST['password']);
        $pass_query = ", password='$password'";
    }

    // Logic Upload Foto
    $foto_query = "";
    if (!empty($_FILES['foto']['name'])) {
        $file_name = $_FILES['foto']['name'];
        $file_tmp  = $_FILES['foto']['tmp_name'];
        $file_ext  = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed   = ['jpg', 'jpeg', 'png'];

        if (in_array($file_ext, $allowed)) {
            // Nama file unik: profile_LEVE_ID_WAKTU.ext
            $new_name = "profile_" . $level . "_" . $id_user . "_" . time() . "." . $file_ext;
            
            // Pindahkan file ke assets/img/
            if (move_uploaded_file($file_tmp, "assets/img/" . $new_name)) {
                $foto_query = ", foto='$new_name'";
                
                // Update Session Foto agar header langsung berubah
                $_SESSION['foto'] = $new_name;
            }
        } else {
            set_notifikasi('warning', 'Format Salah', 'Foto harus format JPG/PNG');
            echo "<script>history.back();</script>";
            exit();
        }
    }

    // Update Session Nama
    $_SESSION['nama'] = $nama_lengkap;

    // Query Update Dinamis
    $query = "UPDATE $tabel SET 
              nama_lengkap = '$nama_lengkap',
              email        = '$email',
              no_hp        = '$no_hp'
              $alamat_query
              $pass_query
              $foto_query
              WHERE $pk = '$id_user'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Profil Anda berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=profil';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
}

// ==================================================================================
// AMBIL DATA USER SAAT INI
// ==================================================================================
$query_user = mysqli_query($koneksi, "SELECT * FROM $tabel WHERE $pk = '$id_user'");
$u = mysqli_fetch_assoc($query_user);

// Fallback foto jika kosong
$foto_profil = !empty($u['foto']) ? $u['foto'] : 'default-user.png';
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Profil Saya</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profil</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-xl-4">
        <div class="card">
            <div class="card-body text-center">
                <div class="mb-4 mt-3">
                    <img src="assets/img/<?= $foto_profil ?>" class="rounded-circle avatar-xl img-thumbnail" alt="Foto Profil" style="width: 120px; height: 120px; object-fit: cover;">
                </div>
                <h5 class="mb-1"><?= $u['nama_lengkap'] ?></h5>
                <p class="text-muted mb-3 text-uppercase badge bg-light text-primary"><?= isset($u['level']) ? $u['level'] : 'Pegawai PJLP' ?></p>

                <div class="text-start mt-4">
                    <h6 class="fs-13 text-uppercase fw-semibold mb-3">Detail Informasi</h6>
                    <div class="table-responsive">
                        <table class="table table-borderless table-sm mb-0">
                            <tbody>
                                <tr>
                                    <td class="text-muted" width="35%">Username</td>
                                    <td class="fw-medium"><?= isset($u['username']) ? $u['username'] : $u['nik'] ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Email</td>
                                    <td class="fw-medium"><?= !empty($u['email']) ? $u['email'] : '-' ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">No. HP</td>
                                    <td class="fw-medium"><?= !empty($u['no_hp']) ? $u['no_hp'] : '-' ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Terdaftar</td>
                                    <td class="fw-medium">
                                        <?= isset($u['created_at']) ? date('d M Y', strtotime($u['created_at'])) : '-' ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-8">
        
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="bi bi-info-circle me-2"></i>
            Pastikan folder <strong>assets/img/</strong> sudah tersedia di direktori sebelum mengupload file foto.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Edit Profil</h5>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    
                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Nama Lengkap <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_lengkap" value="<?= $u['nama_lengkap'] ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" name="email" value="<?= $u['email'] ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">No. Handphone</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="no_hp" value="<?= $u['no_hp'] ?>">
                        </div>
                    </div>

                    <?php if ($tabel == 'tbl_pjlp'): ?>
                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Alamat</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="alamat" rows="2"><?= $u['alamat'] ?></textarea>
                        </div>
                    </div>
                    <?php endif; ?>

                    <hr class="border-dashed my-4">

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Ganti Foto</label>
                        <div class="col-sm-9">
                            <input type="file" class="form-control" name="foto" accept="image/*">
                            <small class="text-muted">Biarkan kosong jika tidak ingin mengubah foto.</small>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Ganti Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name="password" placeholder="********">
                            <small class="text-muted">Biarkan kosong jika tidak ingin mengubah password.</small>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-sm-9 offset-sm-3 text-end">
                            <button type="submit" name="btn_simpan" class="btn btn-primary">
                                <i class="bi bi-save me-1"></i> Simpan Perubahan
                            </button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>