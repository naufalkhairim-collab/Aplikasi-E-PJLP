<?php
// 1. Keamanan: Hanya Admin & Keuangan
if (!in_array($_SESSION['level'], ['admin', 'keuangan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// API AJAX: HITUNG GAJI OTOMATIS (Added)
// ==================================================================================
if ($act == 'get_kalkulasi') {
    // Bersihkan buffer agar tidak ada output HTML lain
    ob_clean(); 
    
    $id_kontrak = $_POST['id_kontrak'];
    $bulan      = $_POST['bulan'];
    $tahun      = $_POST['tahun'];

    // 1. Ambil Gaji Pokok
    $q_gaji = mysqli_query($koneksi, "SELECT gaji_pokok FROM tbl_gaji_pjlp WHERE id_kontrak='$id_kontrak'");
    $d_gaji = mysqli_fetch_assoc($q_gaji);
    $gapok  = $d_gaji['gaji_pokok'] ?? 0;

    // 2. Hitung Absensi
    $q_absen = mysqli_query($koneksi, "
        SELECT 
            SUM(CASE WHEN status_kehadiran='Hadir' THEN 1 ELSE 0 END) as hadir,
            SUM(CASE WHEN status_kehadiran='Alpa' THEN 1 ELSE 0 END) as alpa,
            SUM(CASE WHEN status_masuk='Terlambat' THEN 1 ELSE 0 END) as telat
        FROM tbl_absensi 
        WHERE id_kontrak='$id_kontrak' AND MONTH(tanggal)='$bulan' AND YEAR(tanggal)='$tahun'
    ");
    $d_absen = mysqli_fetch_assoc($q_absen);
    
    $hadir = $d_absen['hadir'] ?? 0;
    $alpa  = $d_absen['alpa'] ?? 0;
    $telat = $d_absen['telat'] ?? 0;

    // 3. LOGIKA HITUNG BERDASARKAN NILAI DI DATABASE
    $hasil = [];
    $q_komp = mysqli_query($koneksi, "SELECT * FROM tbl_komponen_gaji");
    
    while($k = mysqli_fetch_assoc($q_komp)) {
        $nominal_db = $k['nominal_default']; // Nilai default dari admin
        $nama       = strtolower($k['nama_komponen']);
        $final_nilai = 0;

        // --- A. LOGIKA TUNJANGAN ---
        if (strpos($nama, 'makan') !== false || strpos($nama, 'transport') !== false) {
            // Tarif per hari x Jumlah Hadir
            $final_nilai = $hadir * $nominal_db;
        }
        
        // --- B. LOGIKA POTONGAN ---
        elseif (strpos($nama, 'bpjs') !== false) {
            // Jika admin isi nominal fix, pakai itu. Jika 0, hitung persentase.
            if ($nominal_db > 0) {
                $final_nilai = $nominal_db;
            } else {
                if (strpos($nama, '1%') !== false) $final_nilai = $gapok * 0.01;
                elseif (strpos($nama, '2%') !== false) $final_nilai = $gapok * 0.02;
                elseif (strpos($nama, '4%') !== false) $final_nilai = $gapok * 0.04;
            }
        }
        elseif (strpos($nama, 'alpa') !== false) {
            // Jika ada nilai denda harian di DB, pakai itu. Jika 0, pakai rumus proporsional.
            if ($nominal_db > 0) {
                $final_nilai = $alpa * $nominal_db;
            } else {
                $final_nilai = $alpa * ($gapok / 22); 
            }
        }
        elseif (strpos($nama, 'telat') !== false || strpos($nama, 'keterlambatan') !== false) {
            // Kalikan jumlah telat dengan tarif denda
            $final_nilai = $telat * $nominal_db;
        }
        
        // --- C. KOMPONEN TETAP ---
        else {
            // Langsung ambil nilai flat dari database (THR, Koperasi, dll)
            $final_nilai = $nominal_db;
        }

        $hasil[$k['id_komponen']] = floor($final_nilai);
    }

    header('Content-Type: application/json');
    echo json_encode([
        'gapok' => $gapok,
        'komponen' => $hasil,
        'info_absen' => "Hadir: $hadir hari, Telat: $telat kali, Alpa: $alpa hari"
    ]);
    exit(); // Stop eksekusi agar tidak tercampur HTML
}

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES HITUNG & SIMPAN GAJI ---
if (isset($_POST['btn_simpan'])) {
    $id_kontrak = amankan_input($_POST['id_kontrak']);
    $bulan      = amankan_input($_POST['bulan']);
    $tahun      = amankan_input($_POST['tahun']);
    $gaji_pokok = amankan_input($_POST['gaji_pokok']); 
    
    // Ambil Data Kontrak untuk DPA
    $q_kontrak = mysqli_query($koneksi, "SELECT id_dpa_detail FROM tbl_kontrak WHERE id_kontrak='$id_kontrak'");
    $d_kontrak = mysqli_fetch_assoc($q_kontrak);
    $id_dpa    = $d_kontrak['id_dpa_detail'];

    // Cek Duplikasi Periode
    $cek = mysqli_query($koneksi, "SELECT id_payroll FROM tbl_payroll WHERE id_kontrak='$id_kontrak' AND bulan='$bulan' AND tahun='$tahun'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Gagal', 'Pegawai ini sudah digaji pada periode tersebut!');
        echo "<script>history.back();</script>";
        exit();
    }

    // Hitung Total Tunjangan & Potongan dari Array Input
    $total_tunjangan = 0;
    $total_potongan  = 0;
    
    $detail_insert = [];

    // Loop komponen dari post
    if (isset($_POST['komponen'])) {
        foreach ($_POST['komponen'] as $id_komp => $nominal) {
            $nominal = (int)$nominal;
            $tipe    = $_POST['tipe_komponen'][$id_komp];
            $nama_k  = $_POST['nama_komponen'][$id_komp];

            if ($tipe == 'tunjangan') {
                $total_tunjangan += $nominal;
            } else {
                $total_potongan += $nominal;
            }

            $detail_insert[] = [
                'id' => $id_komp,
                'nama' => $nama_k,
                'tipe' => $tipe,
                'jumlah' => $nominal
            ];
        }
    }

    $gaji_bersih = $gaji_pokok + $total_tunjangan - $total_potongan;
    $tgl_buat    = date('Y-m-d H:i:s');

    // 1. Insert Header Payroll
    $query_header = "INSERT INTO tbl_payroll (id_kontrak, id_dpa_detail, bulan, tahun, gaji_pokok, total_tunjangan, total_potongan, gaji_diterima, status_bayar, tgl_dibuat) 
                     VALUES ('$id_kontrak', '$id_dpa', '$bulan', '$tahun', '$gaji_pokok', '$total_tunjangan', '$total_potongan', '$gaji_bersih', 'Proses', '$tgl_buat')";

    if (mysqli_query($koneksi, $query_header)) {
        $id_payroll = mysqli_insert_id($koneksi);

        // 2. Insert Detail Komponen
        foreach ($detail_insert as $det) {
            if ($det['jumlah'] > 0) { 
                $q_det = "INSERT INTO tbl_payroll_detail (id_payroll, id_komponen_gaji, nama_komponen, tipe, jumlah) 
                          VALUES ('$id_payroll', '{$det['id']}', '{$det['nama']}', '{$det['tipe']}', '{$det['jumlah']}')";
                mysqli_query($koneksi, $q_det);
            }
        }

        set_notifikasi('success', 'Berhasil', 'Payroll berhasil diproses.');
        echo "<script>window.location.href='index.php?page=proses_payroll';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL Header: ' . mysqli_error($koneksi));
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    $query = "DELETE FROM tbl_payroll WHERE id_payroll='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data payroll dibatalkan/dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=proses_payroll';</script>";
    exit();
}

// --- UPDATE STATUS BAYAR ---
if ($act == 'bayar' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    mysqli_query($koneksi, "UPDATE tbl_payroll SET status_bayar='Lunas' WHERE id_payroll='$id'");
    set_notifikasi('success', 'Lunas', 'Status gaji diubah menjadi Lunas');
    echo "<script>window.location.href='index.php?page=proses_payroll';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Proses Penggajian (Payroll)</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Payroll</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM INPUT GAJI (STEP 1: PILIH PEGAWAI & INPUT KOMPONEN)
    // ==========================================================================
    case 'tambah':
        // Ambil Data Pegawai Aktif
        $pegawai = [];
        $q_peg = mysqli_query($koneksi, "
            SELECT k.id_kontrak, p.nama_lengkap, p.nik, u.nama_unit_kerja, gp.gaji_pokok
            FROM tbl_kontrak k
            JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
            JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
            LEFT JOIN tbl_gaji_pjlp gp ON k.id_kontrak = gp.id_kontrak
            WHERE k.status_kontrak = 'Aktif'
            ORDER BY p.nama_lengkap ASC
        ");
        
        // Ambil Master Komponen Gaji
        $komponen = [];
        $q_kom = mysqli_query($koneksi, "SELECT * FROM tbl_komponen_gaji ORDER BY tipe DESC, nama_komponen ASC");
        while($k = mysqli_fetch_assoc($q_kom)){
            $komponen[] = $k;
        }
?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Input Gaji Bulanan</h5>
                    <a href="index.php?page=proses_payroll" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <h6 class="mb-3 text-primary fw-bold">1. Informasi Dasar</h6>
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Periode Gaji <span class="text-danger">*</span></label>
                            <div class="col-sm-5">
                                <select name="bulan" class="form-select" required>
                                    <option value="" disabled selected>Bulan</option>
                                    <?php
                                    $bulan_indo = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                                    foreach ($bulan_indo as $k => $v) {
                                        $selected = ($k == date('n')) ? 'selected' : '';
                                        echo "<option value='$k' $selected>$v</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-sm-4">
                                <input type="number" name="tahun" class="form-control" value="<?= date('Y') ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Pilih Pegawai <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="id_kontrak" id="select_pegawai" class="form-select select2" required>
                                    <option value="" disabled selected>-- Pilih Pegawai --</option>
                                    <?php while ($p = mysqli_fetch_assoc($q_peg)) { ?>
                                        <option value="<?= $p['id_kontrak'] ?>">
                                            <?= $p['nama_lengkap'] ?> - <?= $p['nama_unit_kerja'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Gaji Pokok</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-text">Rp</span>
                                    <input type="number" name="gaji_pokok" id="gaji_pokok" class="form-control bg-light" readonly value="0">
                                </div>
                                <div class="form-text">Gaji pokok diisi otomatis oleh sistem.</div>
                            </div>
                        </div>

                        <hr class="my-4 border-dashed">
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="text-primary fw-bold mb-0">2. Komponen Gaji (Hitung Otomatis)</h6>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="hitungOtomatis()">
                                <i class="bi bi-arrow-clockwise me-1"></i> Refresh Hitungan
                            </button>
                        </div>

                        <div class="row">
                            <?php foreach($komponen as $k): 
                                $bg_icon = ($k['tipe'] == 'tunjangan') ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger';
                                $icon = ($k['tipe'] == 'tunjangan') ? 'bi-plus-lg' : 'bi-dash-lg';
                            ?>
                            <div class="col-md-6 mb-3">
                                <label class="form-label d-flex justify-content-between">
                                    <span><?= $k['nama_komponen'] ?></span>
                                    <span class="badge <?= $bg_icon ?> text-uppercase" style="font-size: 10px;"><?= $k['tipe'] ?></span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text <?= $bg_icon ?>"><i class="bi <?= $icon ?>"></i></span>
                                    <input type="number" 
                                           name="komponen[<?= $k['id_komponen'] ?>]" 
                                           class="form-control hitung-gaji" 
                                           value="0" min="0" 
                                           data-tipe="<?= $k['tipe'] ?>"
                                           oninput="hitungTotalUI()">
                                    <input type="hidden" name="nama_komponen[<?= $k['id_komponen'] ?>]" value="<?= $k['nama_komponen'] ?>">
                                    <input type="hidden" name="tipe_komponen[<?= $k['id_komponen'] ?>]" value="<?= $k['tipe'] ?>">
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <hr class="my-4">

                        <div class="row justify-content-end">
                            <div class="col-md-6">
                                <div class="card bg-primary text-white">
                                    <div class="card-body p-3 text-center">
                                        <h6 class="mb-1 text-white-50">Total Gaji Diterima (THP)</h6>
                                        <h2 class="mb-0 fw-bold" id="label_thp">Rp 0</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12 text-end">
                                <button type="reset" class="btn btn-light me-2">Reset</button>
                                <button type="submit" name="btn_simpan" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i> Simpan & Proses</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Trigger saat Pegawai, Bulan, atau Tahun berubah
            $('#select_pegawai, select[name="bulan"], input[name="tahun"]').change(function() {
                hitungOtomatis();
            });
        });

        function hitungOtomatis() {
            var id_kontrak = $('#select_pegawai').val();
            var bulan      = $('select[name="bulan"]').val();
            var tahun      = $('input[name="tahun"]').val();

            if (id_kontrak && bulan && tahun) {
                // Indikator Loading
                $('#label_thp').text('Menghitung...');

                $.ajax({
                    url: 'index.php?page=proses_payroll&act=get_kalkulasi',
                    type: 'POST',
                    data: {
                        id_kontrak: id_kontrak,
                        bulan: bulan,
                        tahun: tahun
                    },
                    dataType: 'json',
                    success: function(response) {
                        // 1. Isi Gaji Pokok
                        $('#gaji_pokok').val(response.gapok);

                        // 2. Loop dan Isi Komponen
                        $.each(response.komponen, function(id_komp, nilai) {
                            // Cari input name="komponen[ID]"
                            $('input[name="komponen[' + id_komp + ']"]').val(nilai);
                        });

                        // 3. Hitung Total UI
                        hitungTotalUI();
                        
                        console.log("Absensi: " + response.info_absen);
                    },
                    error: function(xhr, status, error) {
                        console.error("Error AJAX: " + error);
                        $('#label_thp').text('Gagal Hitung');
                    }
                });
            }
        }

        // Kalkulator Client-Side (Update Total saat user edit manual)
        function hitungTotalUI() {
            var gapok = parseFloat($('#gaji_pokok').val()) || 0;
            var tunjangan = 0;
            var potongan = 0;

            $('.hitung-gaji').each(function() {
                var val = parseFloat($(this).val()) || 0;
                var tipe = $(this).data('tipe');
                
                if(tipe === 'tunjangan') {
                    tunjangan += val;
                } else {
                    potongan += val;
                }
            });

            var total = gapok + tunjangan - potongan;
            
            // Format Rupiah
            var formatter = new Intl.NumberFormat('id-ID', {
                style: 'currency',
                currency: 'IDR',
                minimumFractionDigits: 0
            });

            $('#label_thp').text(formatter.format(total));
        }
    </script>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA PAYROLL
    // ==========================================================================
    default:
        // Filter Bulan/Tahun
        $f_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
        $f_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <form action="index.php" method="GET">
                        <input type="hidden" name="page" value="proses_payroll">
                        <div class="row g-2 align-items-center">
                            <div class="col-auto">
                                <h5 class="card-title mb-0 me-3">Data Payroll</h5>
                            </div>
                            <div class="col-auto">
                                <select name="bulan" class="form-select form-select-sm">
                                    <?php
                                    $bulan_indo = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                                    foreach ($bulan_indo as $k => $v) {
                                        $sel = ($k == $f_bulan) ? 'selected' : '';
                                        echo "<option value='$k' $sel>$v</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-auto">
                                <input type="number" name="tahun" class="form-control form-control-sm" value="<?= $f_tahun ?>" style="width: 80px;">
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-filter"></i> Filter</button>
                            </div>
                            <div class="col text-end">
                                <a href="index.php?page=proses_payroll&act=tambah" class="btn btn-success btn-sm">
                                    <i class="bi bi-cash-coin me-1"></i> Input Gaji
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Pegawai</th>
                                    <th>Gaji Pokok</th>
                                    <th>Tunjangan</th>
                                    <th>Potongan</th>
                                    <th>Total (THP)</th>
                                    <th>Status</th>
                                    <th width="10%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "
                                    SELECT py.*, p.nama_lengkap, p.nik 
                                    FROM tbl_payroll py
                                    JOIN tbl_kontrak k ON py.id_kontrak = k.id_kontrak
                                    JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                    WHERE py.bulan = '$f_bulan' AND py.tahun = '$f_tahun'
                                    ORDER BY py.tgl_dibuat DESC
                                ");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <div class="fw-bold"><?= $row['nama_lengkap'] ?></div>
                                        <small class="text-muted"><?= $row['nik'] ?></small>
                                    </td>
                                    <td>Rp <?= number_format($row['gaji_pokok'], 0, ',', '.') ?></td>
                                    <td class="text-success">+ Rp <?= number_format($row['total_tunjangan'], 0, ',', '.') ?></td>
                                    <td class="text-danger">- Rp <?= number_format($row['total_potongan'], 0, ',', '.') ?></td>
                                    <td class="fw-bold text-primary">Rp <?= number_format($row['gaji_diterima'], 0, ',', '.') ?></td>
                                    <td>
                                        <?php if($row['status_bayar'] == 'Lunas'): ?>
                                            <span class="badge bg-success-subtle text-success">Lunas</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning-subtle text-warning">Proses</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                Aksi
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="cetak_laporan.php?jenis=10&unit=all&bulan=<?= $row['bulan'] ?>&tahun=<?= $row['tahun'] ?>" target="_blank"><i class="bi bi-printer me-2"></i> Cetak Slip</a></li>
                                                <?php if($row['status_bayar'] != 'Lunas'): ?>
                                                <li><a class="dropdown-item text-success" href="index.php?page=proses_payroll&act=bayar&id=<?= $row['id_payroll'] ?>"><i class="bi bi-check-circle me-2"></i> Tandai Lunas</a></li>
                                                <?php endif; ?>
                                                <li><hr class="dropdown-divider"></li>
                                                <li><a class="dropdown-item text-danger" href="#" onclick="konfirmasiHapus('index.php?page=proses_payroll&act=hapus&id=<?= $row['id_payroll'] ?>')"><i class="bi bi-trash me-2"></i> Hapus</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>