<?php
// 1. Keamanan: Admin & Pimpinan
if (!in_array($_SESSION['level'], ['admin', 'pimpinan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- SIMPAN DATA ---
if (isset($_POST['btn_simpan'])) {
    $penerima   = amankan_input($_POST['id_pjlp_penerima']);
    $judul      = amankan_input($_POST['judul_tugas']);
    $deskripsi  = amankan_input($_POST['deskripsi_tugas']);
    $deadline   = amankan_input($_POST['deadline']);
    
    $pemberi    = $_SESSION['id_user']; // User yang login
    $tgl_beri   = date('Y-m-d H:i:s'); // Waktu saat ini
    $status     = 'Baru';

    $query = "INSERT INTO tbl_tugas (id_user_pemberi, id_pjlp_penerima, judul_tugas, deskripsi_tugas, tgl_beri, deadline, status_tugas) 
              VALUES ('$pemberi', '$penerima', '$judul', '$deskripsi', '$tgl_beri', '$deadline', '$status')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terkirim', 'Tugas berhasil diberikan kepada pegawai.');
        echo "<script>window.location.href='index.php?page=penugasan';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_tugas   = amankan_input($_POST['id_tugas']);
    $penerima   = amankan_input($_POST['id_pjlp_penerima']);
    $judul      = amankan_input($_POST['judul_tugas']);
    $deskripsi  = amankan_input($_POST['deskripsi_tugas']);
    $deadline   = amankan_input($_POST['deadline']);
    $status     = amankan_input($_POST['status_tugas']);

    $query = "UPDATE tbl_tugas SET 
              id_pjlp_penerima = '$penerima',
              judul_tugas = '$judul',
              deskripsi_tugas = '$deskripsi',
              deadline = '$deadline',
              status_tugas = '$status'
              WHERE id_tugas = '$id_tugas'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data tugas diperbarui');
        echo "<script>window.location.href='index.php?page=penugasan';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    $query = "DELETE FROM tbl_tugas WHERE id_tugas='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data tugas berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=penugasan';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen Penugasan Pegawai</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tugas</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Buat Tugas Baru</h5>
                    <a href="index.php?page=penugasan" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Judul Tugas <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="judul_tugas" class="form-control" required placeholder="Contoh: Perbaikan Taman Kota">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Pegawai Penerima <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="id_pjlp_penerima" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Pegawai --</option>
                                    <?php
                                    // Ambil PJLP Aktif
                                    $q_pjlp = mysqli_query($koneksi, "SELECT id_pjlp, nama_lengkap, nik FROM tbl_pjlp WHERE status_pjlp='Aktif' ORDER BY nama_lengkap ASC");
                                    while ($p = mysqli_fetch_assoc($q_pjlp)) {
                                        echo "<option value='{$p['id_pjlp']}'>{$p['nama_lengkap']} (NIK: {$p['nik']})</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Deskripsi Detail</label>
                            <div class="col-sm-9">
                                <textarea name="deskripsi_tugas" class="form-control" rows="4" placeholder="Jelaskan detail pekerjaan..."></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Batas Waktu (Deadline)</label>
                            <div class="col-sm-5">
                                <input type="datetime-local" name="deadline" class="form-control">
                                <div class="form-text">Biarkan kosong jika tidak ada deadline spesifik.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-send me-1"></i> Berikan Tugas</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_tugas WHERE id_tugas='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=penugasan';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Tugas</h5>
                    <a href="index.php?page=penugasan" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_tugas" value="<?= $d['id_tugas'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Judul Tugas <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="judul_tugas" class="form-control" value="<?= $d['judul_tugas'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Pegawai Penerima</label>
                            <div class="col-sm-9">
                                <select name="id_pjlp_penerima" class="form-select" required>
                                    <?php
                                    $q_pjlp = mysqli_query($koneksi, "SELECT id_pjlp, nama_lengkap FROM tbl_pjlp WHERE status_pjlp='Aktif'");
                                    while ($p = mysqli_fetch_assoc($q_pjlp)) {
                                        $sel = ($p['id_pjlp'] == $d['id_pjlp_penerima']) ? 'selected' : '';
                                        echo "<option value='{$p['id_pjlp']}' $sel>{$p['nama_lengkap']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Deskripsi</label>
                            <div class="col-sm-9">
                                <textarea name="deskripsi_tugas" class="form-control" rows="4"><?= $d['deskripsi_tugas'] ?></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Deadline</label>
                            <div class="col-sm-5">
                                <input type="datetime-local" name="deadline" class="form-control" value="<?= $d['deadline'] ?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Status Tugas</label>
                            <div class="col-sm-5">
                                <select name="status_tugas" class="form-select">
                                    <option value="Baru" <?= ($d['status_tugas'] == 'Baru') ? 'selected' : '' ?>>Baru</option>
                                    <option value="Dikerjakan" <?= ($d['status_tugas'] == 'Dikerjakan') ? 'selected' : '' ?>>Sedang Dikerjakan</option>
                                    <option value="Selesai" <?= ($d['status_tugas'] == 'Selesai') ? 'selected' : '' ?>>Selesai</option>
                                    <option value="Ditinjau" <?= ($d['status_tugas'] == 'Ditinjau') ? 'selected' : '' ?>>Ditinjau (Revisi)</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Tugas Pegawai</h5>
                    <a href="index.php?page=penugasan&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Buat Tugas
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Judul Tugas</th>
                                    <th>Penerima (PJLP)</th>
                                    <th>Pemberi</th>
                                    <th>Deadline</th>
                                    <th>Status</th>
                                    <th width="15%">Aksi</th> </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "
                                    SELECT t.*, p.nama_lengkap as nama_pjlp, u.nama_lengkap as nama_pemberi 
                                    FROM tbl_tugas t
                                    JOIN tbl_pjlp p ON t.id_pjlp_penerima = p.id_pjlp
                                    JOIN tbl_users u ON t.id_user_pemberi = u.id_user
                                    ORDER BY t.tgl_beri DESC
                                ");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <span class="fw-medium text-dark"><?= $row['judul_tugas'] ?></span><br>
                                        <small class="text-muted"><?= date('d/m/Y', strtotime($row['tgl_beri'])) ?></small>
                                    </td>
                                    <td><?= $row['nama_pjlp'] ?></td>
                                    <td><small><?= $row['nama_pemberi'] ?></small></td>
                                    <td>
                                        <?php if($row['deadline']): ?>
                                            <?= date('d M Y H:i', strtotime($row['deadline'])) ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $st = $row['status_tugas'];
                                            $badge = 'secondary';
                                            if($st == 'Baru') $badge = 'primary';
                                            elseif($st == 'Dikerjakan') $badge = 'warning';
                                            elseif($st == 'Selesai') $badge = 'success';
                                            elseif($st == 'Ditinjau') $badge = 'info';
                                        ?>
                                        <span class="badge bg-<?= $badge ?>-subtle text-<?= $badge ?>"><?= $st ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="cetak_laporan.php?jenis=14&id_tugas=<?= $row['id_tugas'] ?>" target="_blank" class="btn btn-sm btn-secondary" data-bs-toggle="tooltip" title="Cetak SPT">
                                                <i class="bi bi-printer"></i>
                                            </a>

                                            <a href="index.php?page=penugasan&act=edit&id=<?= $row['id_tugas'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=penugasan&act=hapus&id=<?= $row['id_tugas'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>