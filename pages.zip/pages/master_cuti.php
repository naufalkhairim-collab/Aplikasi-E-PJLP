<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act'
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC
// ==================================================================================

// --- SIMPAN DATA ---
if (isset($_POST['btn_simpan'])) {
    $kode       = amankan_input($_POST['kode_cuti']);
    $nama       = amankan_input($_POST['nama_cuti']);
    $tipe       = amankan_input($_POST['tipe_cuti']);
    $file       = amankan_input($_POST['memerlukan_file']);     // 1 atau 0
    $kuota      = amankan_input($_POST['mengurangi_kuota']);    // 1 atau 0
    $potongan   = amankan_input($_POST['potongan_gaji_persen']);

    // Validasi Kode Unik
    $cek = mysqli_query($koneksi, "SELECT kode_cuti FROM tbl_master_cuti WHERE kode_cuti='$kode'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Duplikasi', 'Kode Cuti sudah ada!');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "INSERT INTO tbl_master_cuti (kode_cuti, nama_cuti, tipe_cuti, memerlukan_file, mengurangi_kuota, potongan_gaji_persen) 
              VALUES ('$kode', '$nama', '$tipe', '$file', '$kuota', '$potongan')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Jenis cuti berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=master_cuti';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id         = amankan_input($_POST['id_master_cuti']);
    $kode       = amankan_input($_POST['kode_cuti']);
    $nama       = amankan_input($_POST['nama_cuti']);
    $tipe       = amankan_input($_POST['tipe_cuti']);
    $file       = amankan_input($_POST['memerlukan_file']);
    $kuota      = amankan_input($_POST['mengurangi_kuota']);
    $potongan   = amankan_input($_POST['potongan_gaji_persen']);

    $query = "UPDATE tbl_master_cuti SET 
              kode_cuti = '$kode', 
              nama_cuti = '$nama', 
              tipe_cuti = '$tipe', 
              memerlukan_file = '$file', 
              mengurangi_kuota = '$kuota', 
              potongan_gaji_persen = '$potongan' 
              WHERE id_master_cuti = '$id'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Jenis cuti berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=master_cuti';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    // Cek Relasi: Apakah sudah digunakan di Pengajuan Cuti?
    $cek_pengajuan = mysqli_query($koneksi, "SELECT id_pengajuan FROM tbl_pengajuan_cuti WHERE id_master_cuti='$id'");
    // Cek Relasi: Apakah sudah digunakan di Tabel Kuota?
    $cek_kuota     = mysqli_query($koneksi, "SELECT id_kuota FROM tbl_kuota_cuti_pjlp WHERE id_master_cuti='$id'");

    if (mysqli_num_rows($cek_pengajuan) > 0 || mysqli_num_rows($cek_kuota) > 0) {
        set_notifikasi('error', 'Gagal Hapus', 'Data tidak bisa dihapus karena sudah digunakan dalam transaksi pengajuan atau pengaturan kuota.');
        echo "<script>window.location.href='index.php?page=master_cuti';</script>";
        exit();
    }

    $query = "DELETE FROM tbl_master_cuti WHERE id_master_cuti='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Jenis cuti berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=master_cuti';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Data Master Cuti & Izin</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Master Cuti</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Jenis Cuti/Izin</h5>
                    <a href="index.php?page=master_cuti" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kode Cuti <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_cuti" class="form-control" required placeholder="Contoh: C01, IZN, SKT">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Cuti <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_cuti" class="form-control" required placeholder="Contoh: Cuti Tahunan, Izin Sakit">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tipe <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="tipe_cuti" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Tipe --</option>
                                    <option value="Cuti">Cuti (Hak Pegawai)</option>
                                    <option value="Izin">Izin (Keperluan Pribadi)</option>
                                    <option value="Sakit">Sakit</option>
                                    <option value="Dinas Luar">Dinas Luar</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Wajib Upload File?</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="memerlukan_file" id="f1" value="1">
                                    <label class="form-check-label" for="f1">Ya (Wajib)</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="memerlukan_file" id="f0" value="0" checked>
                                    <label class="form-check-label" for="f0">Tidak</label>
                                </div>
                                <div class="form-text">Contoh: Surat Dokter untuk Sakit, Surat Tugas untuk DL.</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kurangi Kuota Cuti?</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="mengurangi_kuota" id="k1" value="1" checked>
                                    <label class="form-check-label" for="k1">Ya (Mengurangi)</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="mengurangi_kuota" id="k0" value="0">
                                    <label class="form-check-label" for="k0">Tidak</label>
                                </div>
                                <div class="form-text">Jika Ya, maka akan memotong jatah cuti tahunan pegawai.</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Potongan Gaji (%)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="potongan_gaji_persen" class="form-control" value="0" min="0" max="100" step="0.01">
                                    <span class="input-group-text">%</span>
                                </div>
                                <div class="form-text">Isi 0 jika tidak ada potongan gaji.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_master_cuti WHERE id_master_cuti='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=master_cuti';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Jenis Cuti</h5>
                    <a href="index.php?page=master_cuti" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_master_cuti" value="<?= $d['id_master_cuti'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kode Cuti <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="kode_cuti" class="form-control" value="<?= $d['kode_cuti'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Cuti <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_cuti" class="form-control" value="<?= $d['nama_cuti'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tipe <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="tipe_cuti" class="form-select" required>
                                    <option value="Cuti" <?= ($d['tipe_cuti'] == 'Cuti') ? 'selected' : '' ?>>Cuti</option>
                                    <option value="Izin" <?= ($d['tipe_cuti'] == 'Izin') ? 'selected' : '' ?>>Izin</option>
                                    <option value="Sakit" <?= ($d['tipe_cuti'] == 'Sakit') ? 'selected' : '' ?>>Sakit</option>
                                    <option value="Dinas Luar" <?= ($d['tipe_cuti'] == 'Dinas Luar') ? 'selected' : '' ?>>Dinas Luar</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Wajib Upload File?</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="memerlukan_file" id="ef1" value="1" <?= ($d['memerlukan_file'] == '1') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="ef1">Ya</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="memerlukan_file" id="ef0" value="0" <?= ($d['memerlukan_file'] == '0') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="ef0">Tidak</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kurangi Kuota?</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="mengurangi_kuota" id="ek1" value="1" <?= ($d['mengurangi_kuota'] == '1') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="ek1">Ya</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="mengurangi_kuota" id="ek0" value="0" <?= ($d['mengurangi_kuota'] == '0') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="ek0">Tidak</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Potongan Gaji (%)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="potongan_gaji_persen" class="form-control" value="<?= $d['potongan_gaji_persen'] ?>" min="0" max="100" step="0.01">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Jenis Cuti</h5>
                    <a href="index.php?page=master_cuti&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Data
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Kode</th>
                                    <th>Nama Cuti/Izin</th>
                                    <th>Tipe</th>
                                    <th>Pengaturan</th>
                                    <th>Potongan</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_master_cuti ORDER BY tipe_cuti ASC, nama_cuti ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= $row['kode_cuti'] ?></span></td>
                                    <td class="fw-medium"><?= $row['nama_cuti'] ?></td>
                                    <td>
                                        <?php 
                                            $color = 'secondary';
                                            if($row['tipe_cuti'] == 'Cuti') $color = 'success';
                                            elseif($row['tipe_cuti'] == 'Sakit') $color = 'warning';
                                            elseif($row['tipe_cuti'] == 'Dinas Luar') $color = 'info';
                                        ?>
                                        <span class="badge bg-<?= $color ?>-subtle text-<?= $color ?>"><?= $row['tipe_cuti'] ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column gap-1">
                                            <?php if($row['memerlukan_file'] == '1'): ?>
                                                <span class="badge bg-primary-subtle text-primary"><i class="bi bi-file-earmark-arrow-up"></i> Wajib Upload</span>
                                            <?php endif; ?>
                                            
                                            <?php if($row['mengurangi_kuota'] == '1'): ?>
                                                <span class="badge bg-danger-subtle text-danger"><i class="bi bi-pie-chart"></i> Kurangi Kuota</span>
                                            <?php else: ?>
                                                <span class="badge bg-success-subtle text-success"><i class="bi bi-infinity"></i> Bebas Kuota</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($row['potongan_gaji_persen'] > 0): ?>
                                            <span class="text-danger fw-bold"><?= $row['potongan_gaji_persen'] ?>%</span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=master_cuti&act=edit&id=<?= $row['id_master_cuti'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=master_cuti&act=hapus&id=<?= $row['id_master_cuti'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>