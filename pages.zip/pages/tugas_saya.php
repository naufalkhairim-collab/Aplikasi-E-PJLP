<?php
// 1. Keamanan: Hanya PJLP
if ($_SESSION['level'] != 'pjlp') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$id_pjlp = $_SESSION['id_user'];

// ==================================================================================
// PROSES UPDATE STATUS TUGAS
// ==================================================================================
if (isset($_GET['act']) && isset($_GET['id'])) {
    $act = $_GET['act'];
    $id_tugas = amankan_input($_GET['id']);
    $status_baru = '';

    if ($act == 'mulai') {
        $status_baru = 'Dikerjakan';
        $pesan = 'Status berubah menjadi Sedang Dikerjakan.';
    } elseif ($act == 'selesai') {
        $status_baru = 'Selesai';
        $pesan = 'Tugas berhasil diselesaikan!';
    }

    if ($status_baru) {
        $query = "UPDATE tbl_tugas SET status_tugas='$status_baru' WHERE id_tugas='$id_tugas' AND id_pjlp_penerima='$id_pjlp'";
        if (mysqli_query($koneksi, $query)) {
            set_notifikasi('success', 'Berhasil', $pesan);
            echo "<script>window.location.href='index.php?page=tugas_saya';</script>";
            exit();
        }
    }
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Daftar Tugas Saya</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tugas</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        
        <ul class="nav nav-pills nav-fill mb-4 bg-white p-1 rounded shadow-sm" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active rounded-pill fw-bold" id="pills-aktif-tab" data-bs-toggle="pill" data-bs-target="#pills-aktif" type="button" role="tab">
                    <i class="bi bi-hourglass-split me-1"></i> Tugas Aktif
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link rounded-pill fw-bold" id="pills-selesai-tab" data-bs-toggle="pill" data-bs-target="#pills-selesai" type="button" role="tab">
                    <i class="bi bi-check-all me-1"></i> Riwayat Selesai
                </button>
            </li>
        </ul>

        <div class="tab-content" id="pills-tabContent">
            
            <div class="tab-pane fade show active" id="pills-aktif" role="tabpanel">
                <?php
                $q_aktif = mysqli_query($koneksi, "
                    SELECT t.*, u.nama_lengkap as pemberi 
                    FROM tbl_tugas t 
                    JOIN tbl_users u ON t.id_user_pemberi = u.id_user 
                    WHERE t.id_pjlp_penerima='$id_pjlp' AND t.status_tugas IN ('Baru', 'Dikerjakan', 'Ditinjau')
                    ORDER BY t.tgl_beri DESC
                ");

                if (mysqli_num_rows($q_aktif) > 0) {
                    while ($row = mysqli_fetch_assoc($q_aktif)) {
                        // Logic Badge Status
                        $badge = 'bg-primary';
                        if ($row['status_tugas'] == 'Dikerjakan') $badge = 'bg-warning text-dark';
                        elseif ($row['status_tugas'] == 'Ditinjau') $badge = 'bg-info text-white';

                        // Logic Deadline
                        $deadline_html = '';
                        if ($row['deadline']) {
                            $dl = strtotime($row['deadline']);
                            $now = time();
                            $color_dl = ($dl < $now) ? 'text-danger fw-bold' : 'text-muted';
                            $text_dl = ($dl < $now) ? 'Terlewat' : 'Batas Waktu';
                            $deadline_html = "<small class='$color_dl'><i class='bi bi-calendar-event me-1'></i> $text_dl: " . date('d M H:i', $dl) . "</small>";
                        }
                ?>
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="badge <?= $badge ?> rounded-pill px-3"><?= $row['status_tugas'] ?></span>
                                <small class="text-muted"><?= date('d M Y', strtotime($row['tgl_beri'])) ?></small>
                            </div>
                            
                            <h5 class="fw-bold text-dark mb-2"><?= $row['judul_tugas'] ?></h5>
                            <p class="text-muted small mb-3"><?= nl2br($row['deskripsi_tugas']) ?></p>
                            
                            <div class="d-flex justify-content-between align-items-center border-top pt-3">
                                <div>
                                    <small class="text-muted d-block" style="font-size: 10px;">DIBERIKAN OLEH</small>
                                    <span class="fw-bold small text-dark"><?= $row['pemberi'] ?></span>
                                    <div class="mt-1"><?= $deadline_html ?></div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <a href="cetak_laporan.php?jenis=14&id_tugas=<?= $row['id_tugas'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary rounded-pill px-3" title="Download SPT">
                                        <i class="bi bi-printer me-1"></i> SPT
                                    </a>

                                    <?php if($row['status_tugas'] == 'Baru'): ?>
                                        <button onclick="updateStatus('<?= $row['id_tugas'] ?>', 'mulai')" class="btn btn-sm btn-primary rounded-pill px-3">
                                            <i class="bi bi-play-fill me-1"></i> Kerjakan
                                        </button>
                                    <?php elseif($row['status_tugas'] == 'Dikerjakan'): ?>
                                        <button onclick="updateStatus('<?= $row['id_tugas'] ?>', 'selesai')" class="btn btn-sm btn-success rounded-pill px-3">
                                            <i class="bi bi-check-lg me-1"></i> Selesai
                                        </button>
                                    <?php elseif($row['status_tugas'] == 'Ditinjau'): ?>
                                        <button class="btn btn-sm btn-secondary rounded-pill px-3" disabled>
                                            <i class="bi bi-eye me-1"></i> Menunggu
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo '<div class="text-center py-5 text-muted"><img src="assets/img/no-data.jpg" height="100" class="mb-3 opacity-50"><p>Tidak ada tugas aktif saat ini.</p></div>';
                }
                ?>
            </div>

            <div class="tab-pane fade" id="pills-selesai" role="tabpanel">
                <?php
                $q_selesai = mysqli_query($koneksi, "
                    SELECT t.*, u.nama_lengkap as pemberi 
                    FROM tbl_tugas t 
                    JOIN tbl_users u ON t.id_user_pemberi = u.id_user 
                    WHERE t.id_pjlp_penerima='$id_pjlp' AND t.status_tugas = 'Selesai'
                    ORDER BY t.deadline DESC LIMIT 20
                ");

                if (mysqli_num_rows($q_selesai) > 0) {
                    while ($row = mysqli_fetch_assoc($q_selesai)) {
                ?>
                    <div class="card border-0 shadow-sm mb-3 opacity-75">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="fw-bold text-dark mb-1 text-decoration-line-through"><?= $row['judul_tugas'] ?></h6>
                                    <small class="text-muted">Pemberi: <?= $row['pemberi'] ?></small>
                                </div>
                                <span class="badge bg-success-subtle text-success"><i class="bi bi-check-circle-fill"></i> Selesai</span>
                            </div>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo '<div class="text-center py-5 text-muted"><img src="assets/img/no-data.jpg" height="100" class="mb-3 opacity-50"><p>Tidak ada tugas aktif saat ini.</p></div>';
                }
                ?>
            </div>

        </div>
    </div>
</div>

<script>
    function updateStatus(id, act) {
        var text = (act === 'mulai') ? "Mulai kerjakan tugas ini?" : "Tandai tugas ini sebagai selesai?";
        var btnText = (act === 'mulai') ? "Ya, Mulai" : "Ya, Selesai";
        var color = (act === 'mulai') ? "#0d6efd" : "#198754";

        Swal.fire({
            title: 'Konfirmasi',
            text: text,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: color,
            cancelButtonColor: '#d33',
            confirmButtonText: btnText,
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `index.php?page=tugas_saya&act=${act}&id=${id}`;
            }
        });
    }
</script>