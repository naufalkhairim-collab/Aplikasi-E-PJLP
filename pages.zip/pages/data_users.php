<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act' (action) dari URL
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $nama           = amankan_input($_POST['nama_lengkap']);
    $username       = amankan_input($_POST['username']);
    $email          = amankan_input($_POST['email']);
    $no_hp          = amankan_input($_POST['no_hp']);
    $level          = amankan_input($_POST['level']);
    $status         = amankan_input($_POST['status_aktif']);
    $password       = md5($_POST['password']); 

    // Validasi Username/Email Unik
    $cek_user = mysqli_query($koneksi, "SELECT username FROM tbl_users WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($cek_user) > 0) {
        set_notifikasi('error', 'Gagal', 'Username atau Email sudah terdaftar!');
        echo "<script>history.back();</script>";
        exit();
    }

    // Upload Foto Profil
    $foto_user = 'default-user.png';
    if (!empty($_FILES['foto']['name'])) {
        $allowed_ext = ['jpg', 'jpeg', 'png'];
        $file_name   = $_FILES['foto']['name'];
        $file_tmp    = $_FILES['foto']['tmp_name'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            $foto_user = "user_" . time() . "." . $file_ext;
            move_uploaded_file($file_tmp, "assets/img/" . $foto_user);
        } else {
            set_notifikasi('warning', 'Format Salah', 'Foto harus format JPG/PNG');
            echo "<script>history.back();</script>";
            exit();
        }
    }

    $query = "INSERT INTO tbl_users (nama_lengkap, email, no_hp, username, password, level, foto, status_aktif) 
              VALUES ('$nama', '$email', '$no_hp', '$username', '$password', '$level', '$foto_user', '$status')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Pengguna baru berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=data_users';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_user        = amankan_input($_POST['id_user']);
    $nama           = amankan_input($_POST['nama_lengkap']);
    $username       = amankan_input($_POST['username']);
    $email          = amankan_input($_POST['email']);
    $no_hp          = amankan_input($_POST['no_hp']);
    $level          = amankan_input($_POST['level']);
    $status         = amankan_input($_POST['status_aktif']);

    // Cek Password
    $password_query = "";
    if (!empty($_POST['password'])) {
        $pass_hash = md5($_POST['password']);
        $password_query = ", password='$pass_hash'";
    }

    // Handle Upload Update
    $q_lama = mysqli_query($koneksi, "SELECT foto FROM tbl_users WHERE id_user='$id_user'");
    $d_lama = mysqli_fetch_assoc($q_lama);

    $foto_user = $d_lama['foto'];
    if (!empty($_FILES['foto']['name'])) {
        $allowed_ext = ['jpg', 'jpeg', 'png'];
        $file_name   = $_FILES['foto']['name'];
        $file_tmp    = $_FILES['foto']['tmp_name'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            // Hapus foto lama jika bukan default
            if ($d_lama['foto'] != 'default-user.png' && file_exists("assets/img/" . $d_lama['foto'])) {
                unlink("assets/img/" . $d_lama['foto']);
            }

            $foto_user = "user_" . time() . "." . $file_ext;
            move_uploaded_file($file_tmp, "assets/img/" . $foto_user);
        }
    }

    $query = "UPDATE tbl_users SET 
              nama_lengkap='$nama', username='$username', email='$email', no_hp='$no_hp', 
              level='$level', status_aktif='$status', foto='$foto_user' 
              $password_query
              WHERE id_user='$id_user'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data pengguna berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=data_users';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- PROSES HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id_user = amankan_input($_GET['id']);
    
    // Proteksi agar tidak bisa menghapus diri sendiri
    if ($id_user == $_SESSION['id_user']) {
        set_notifikasi('error', 'Ditolak', 'Anda tidak bisa menghapus akun sendiri!');
        echo "<script>window.location.href='index.php?page=data_users';</script>";
        exit();
    }

    // Hapus foto fisik
    $q_cek = mysqli_query($koneksi, "SELECT foto FROM tbl_users WHERE id_user='$id_user'");
    $d_cek = mysqli_fetch_assoc($q_cek);
    
    if($d_cek['foto'] != 'default-user.png' && file_exists("assets/img/".$d_cek['foto'])){
        unlink("assets/img/".$d_cek['foto']);
    }

    $query = "DELETE FROM tbl_users WHERE id_user='$id_user'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Pengguna berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Data mungkin berelasi dengan tabel lain');
    }
    echo "<script>window.location.href='index.php?page=data_users';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen Data Pengguna</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Users</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH (HORIZONTAL)
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>
                Pastikan folder <strong>assets/img/</strong> tersedia untuk menyimpan foto profil pengguna.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah User Baru</h5>
                    <a href="index.php?page=data_users" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lengkap <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lengkap" class="form-control" required placeholder="Nama User">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Username <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="username" class="form-control" required placeholder="Username unik">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Email <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="email" name="email" class="form-control" required placeholder="email@instansi.com">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">No. HP</label>
                            <div class="col-sm-9">
                                <input type="text" name="no_hp" class="form-control" placeholder="08xxxx">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Password <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="password" name="password" class="form-control" required placeholder="Password Login">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Level Akses <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="level" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Level --</option>
                                    <option value="admin">Administrator (Full Akses)</option>
                                    <option value="pimpinan">Pimpinan (Approval & Monitoring)</option>
                                    <option value="keuangan">Keuangan (Penggajian)</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Status Akun</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_aktif" id="st_1" value="1" checked>
                                    <label class="form-check-label" for="st_1">Aktif</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_aktif" id="st_0" value="0">
                                    <label class="form-check-label" for="st_0">Diblokir</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Foto Profil</label>
                            <div class="col-sm-9">
                                <input type="file" name="foto" class="form-control" accept="image/*">
                                <div class="form-text">Format JPG/PNG.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT (HORIZONTAL)
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_users WHERE id_user='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_users';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-9">
            
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>
                Pastikan folder <strong>assets/img/</strong> tersedia untuk menyimpan foto profil pengguna.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit User: <?= $d['nama_lengkap'] ?></h5>
                    <a href="index.php?page=data_users" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <input type="hidden" name="id_user" value="<?= $d['id_user'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lengkap <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lengkap" class="form-control" value="<?= $d['nama_lengkap'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Username <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="username" class="form-control" value="<?= $d['username'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Email <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="email" name="email" class="form-control" value="<?= $d['email'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">No. HP</label>
                            <div class="col-sm-9">
                                <input type="text" name="no_hp" class="form-control" value="<?= $d['no_hp'] ?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Password</label>
                            <div class="col-sm-9">
                                <input type="password" name="password" class="form-control" placeholder="Isi jika ingin mengganti password">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Level Akses <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="level" class="form-select" required>
                                    <option value="admin" <?= ($d['level'] == 'admin') ? 'selected' : '' ?>>Administrator</option>
                                    <option value="pimpinan" <?= ($d['level'] == 'pimpinan') ? 'selected' : '' ?>>Pimpinan</option>
                                    <option value="keuangan" <?= ($d['level'] == 'keuangan') ? 'selected' : '' ?>>Keuangan</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Status Akun</label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_aktif" id="est_1" value="1" <?= ($d['status_aktif'] == '1') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="est_1">Aktif</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_aktif" id="est_0" value="0" <?= ($d['status_aktif'] == '0') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="est_0">Diblokir</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Foto Profil</label>
                            <div class="col-sm-9">
                                <div class="d-flex align-items-center gap-3">
                                    <img src="assets/img/<?= $d['foto'] ?>" class="avatar-md rounded-circle border" alt="Old Photo">
                                    <div class="flex-grow-1">
                                        <input type="file" name="foto" class="form-control" accept="image/*">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA USERS
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Pengguna Sistem</h5>
                    <a href="index.php?page=data_users&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah User
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Pengguna</th>
                                    <th>Kontak</th>
                                    <th>Level</th>
                                    <th>Status</th>
                                    <th>Login Terakhir</th>
                                    <th width="10%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_users ORDER BY id_user DESC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $foto = !empty($row['foto']) ? $row['foto'] : 'default-user.png';
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="assets/img/<?= $foto ?>" alt="" class="avatar-sm rounded-circle me-2 object-fit-cover">
                                            <div>
                                                <h6 class="mb-0 fs-14"><?= $row['nama_lengkap'] ?></h6>
                                                <small class="text-muted">@<?= $row['username'] ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span class="fs-12"><i class="bi bi-envelope me-1"></i> <?= $row['email'] ?></span>
                                            <span class="fs-12 text-muted"><i class="bi bi-telephone me-1"></i> <?= $row['no_hp'] ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                            $badge_color = 'secondary';
                                            if($row['level'] == 'admin') $badge_color = 'primary';
                                            elseif($row['level'] == 'pimpinan') $badge_color = 'info';
                                            elseif($row['level'] == 'keuangan') $badge_color = 'warning';
                                        ?>
                                        <span class="badge bg-<?= $badge_color ?>-subtle text-<?= $badge_color ?> text-uppercase"><?= $row['level'] ?></span>
                                    </td>
                                    <td>
                                        <?php if($row['status_aktif'] == '1'): ?>
                                            <span class="badge bg-success-subtle text-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger">Blokir</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="fs-12 text-muted">
                                            <?= ($row['last_login']) ? date('d/m/Y H:i', strtotime($row['last_login'])) : 'Belum Login' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_users&act=edit&id=<?= $row['id_user'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            
                                            <?php if($row['id_user'] != $_SESSION['id_user']): ?>
                                            <button onclick="konfirmasiHapus('index.php?page=data_users&act=hapus&id=<?= $row['id_user'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>