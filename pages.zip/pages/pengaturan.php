<?php
// 1. Amankan Halaman (Hanya Admin)
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Proses Simpan Data
if (isset($_POST['btn_simpan'])) {
    // Ambil data text
    $nama_aplikasi   = amankan_input($_POST['nama_aplikasi']);
    $nama_instansi   = amankan_input($_POST['nama_instansi']);
    $nama_pimpinan   = amankan_input($_POST['nama_pimpinan']);
    $nip_pimpinan    = amankan_input($_POST['nip_pimpinan']);
    $alamat_instansi = amankan_input($_POST['alamat_instansi']);
    $telp_instansi   = amankan_input($_POST['telp_instansi']);
    $email_instansi  = amankan_input($_POST['email_instansi']);

    // Ambil data lama
    $query_old = mysqli_query($koneksi, "SELECT logo_instansi, background_login FROM tbl_pengaturan WHERE id_pengaturan = 1");
    $data_old  = mysqli_fetch_assoc($query_old);

    // --- LOGIC UPLOAD LOGO ---
    $logo_name = $data_old['logo_instansi']; 
    if (!empty($_FILES['logo_instansi']['name'])) {
        $allowed_ext = ['jpg', 'jpeg', 'png'];
        $file_name   = $_FILES['logo_instansi']['name'];
        $file_tmp    = $_FILES['logo_instansi']['tmp_name'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            $logo_name = "logo_" . time() . "." . $file_ext;
            move_uploaded_file($file_tmp, "assets/img/" . $logo_name);
        } else {
            set_notifikasi('warning', 'Format Salah', 'Logo harus berupa JPG/PNG');
        }
    }

    // --- LOGIC UPLOAD BACKGROUND ---
    $bg_name = $data_old['background_login'];
    if (!empty($_FILES['background_login']['name'])) {
        $allowed_ext = ['jpg', 'jpeg', 'png'];
        $file_name   = $_FILES['background_login']['name'];
        $file_tmp    = $_FILES['background_login']['tmp_name'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (in_array($file_ext, $allowed_ext)) {
            $bg_name = "bg_" . time() . "." . $file_ext;
            move_uploaded_file($file_tmp, "assets/img/" . $bg_name);
        } else {
            set_notifikasi('warning', 'Format Salah', 'Background harus berupa JPG/PNG');
        }
    }

    // Update Database
    $query_update = "UPDATE tbl_pengaturan SET 
        nama_aplikasi   = '$nama_aplikasi',
        nama_instansi   = '$nama_instansi',
        nama_pimpinan   = '$nama_pimpinan',
        nip_pimpinan    = '$nip_pimpinan',
        alamat_instansi = '$alamat_instansi',
        telp_instansi   = '$telp_instansi',
        email_instansi  = '$email_instansi',
        logo_instansi   = '$logo_name',
        background_login= '$bg_name'
        WHERE id_pengaturan = 1";

    if (mysqli_query($koneksi, $query_update)) {
        set_notifikasi('success', 'Berhasil', 'Pengaturan aplikasi diperbarui!');
        echo "<script>window.location.href='index.php?page=pengaturan';</script>";
        exit;
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan database');
    }
}

// 3. Ambil Data Saat Ini
$query_view = mysqli_query($koneksi, "SELECT * FROM tbl_pengaturan WHERE id_pengaturan = 1");
$d = mysqli_fetch_assoc($query_view);
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Pengaturan Aplikasi</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
            </ol>
        </nav>
    </div>
</div>

<form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
    <div class="row">
        
        <div class="col-xl-8">

            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>
                Pastikan folder <strong>assets/img/</strong> sudah tersedia di direktori sebelum mengupload file.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div> 

            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title mb-0">Identitas Instansi & Aplikasi</h5>
                </div>
                <div class="card-body">
                    
                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Nama Aplikasi <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_aplikasi" value="<?= $d['nama_aplikasi'] ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Nama Instansi <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_instansi" value="<?= $d['nama_instansi'] ?>" required>
                        </div>
                    </div>

                    <hr class="my-4 border-dashed">

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Nama Pimpinan</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nama_pimpinan" value="<?= $d['nama_pimpinan'] ?>" placeholder="Kepala Dinas / Direktur">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">NIP Pimpinan</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="nip_pimpinan" value="<?= $d['nip_pimpinan'] ?>">
                        </div>
                    </div>

                    <hr class="my-4 border-dashed">

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">No. Telepon / WA</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="telp_instansi" value="<?= $d['telp_instansi'] ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Email Resmi</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" name="email_instansi" value="<?= $d['email_instansi'] ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label text-end">Alamat Lengkap</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="alamat_instansi" rows="3"><?= $d['alamat_instansi'] ?></textarea>
                            <div class="form-text">Alamat ini akan ditampilkan pada Kop Surat Laporan.</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-xl-4">
            
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Logo Instansi</h5>
                </div>
                <div class="card-body text-center">
                    <div class="mb-3 p-3 bg-light rounded border">
                        <?php $img_logo = !empty($d['logo_instansi']) ? $d['logo_instansi'] : 'default.png'; ?>
                        <img src="assets/img/<?= $img_logo ?>" alt="Preview Logo" class="img-fluid" style="max-height: 100px;">
                    </div>
                    <div class="text-start">
                        <label class="form-label fw-medium">Ganti Logo</label>
                        <input type="file" class="form-control" name="logo_instansi" accept="image/*">
                        <small class="text-muted d-block mt-1">Disarankan format PNG Transparan.</small>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Background Login</h5>
                </div>
                <div class="card-body text-center">
                    <div class="mb-3 p-2 bg-light rounded border">
                        <?php $img_bg = !empty($d['background_login']) ? $d['background_login'] : 'default-bg.jpg'; ?>
                        <img src="assets/img/<?= $img_bg ?>" alt="Preview BG" class="img-fluid rounded" style="max-height: 120px; width: 100%; object-fit: cover;">
                    </div>
                    <div class="text-start">
                        <label class="form-label fw-medium">Ganti Background</label>
                        <input type="file" class="form-control" name="background_login" accept="image/*">
                        <small class="text-muted d-block mt-1">Resolusi disarankan: 1920x1080 px.</small>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="row mt-4 mb-5">
        <div class="col-12 text-end">
            <button type="reset" class="btn btn-light me-2">Reset Perubahan</button>
            <button type="submit" name="btn_simpan" class="btn btn-primary px-4">
                <i class="bi bi-save me-1"></i> Simpan Pengaturan
            </button>
        </div>
    </div>
</form>