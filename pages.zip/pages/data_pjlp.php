<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act' (action) dari URL
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $nik            = amankan_input($_POST['nik']);
    $nama           = amankan_input($_POST['nama_lengkap']);
    $password       = md5($_POST['password']); 
    $tempat_lahir   = amankan_input($_POST['tempat_lahir']);
    $tgl_lahir      = amankan_input($_POST['tgl_lahir']);
    $jk             = amankan_input($_POST['jenis_kelamin']);
    $alamat         = amankan_input($_POST['alamat']);
    $no_hp          = amankan_input($_POST['no_hp']);
    $email          = amankan_input($_POST['email']);
    $nib_nomor      = amankan_input($_POST['nib_nomor']);
    $nib_tgl        = amankan_input($_POST['nib_tgl_terbit']);
    $status         = amankan_input($_POST['status_pjlp']);

    // Validasi NIK Unik
    $cek_nik = mysqli_query($koneksi, "SELECT nik FROM tbl_pjlp WHERE nik='$nik'");
    if (mysqli_num_rows($cek_nik) > 0) {
        set_notifikasi('error', 'Gagal', 'NIK sudah terdaftar!');
        echo "<script>history.back();</script>";
        exit(); // Exit ditambahkan
    }

    // Upload File KTP
    $file_ktp = '';
    if (!empty($_FILES['file_ktp']['name'])) {
        $ext = pathinfo($_FILES['file_ktp']['name'], PATHINFO_EXTENSION);
        $file_ktp = "ktp_" . $nik . "." . $ext;
        move_uploaded_file($_FILES['file_ktp']['tmp_name'], "assets/uploads/dokumen/" . $file_ktp);
    }

    // Upload File NIB
    $file_nib = '';
    if (!empty($_FILES['file_nib']['name'])) {
        $ext = pathinfo($_FILES['file_nib']['name'], PATHINFO_EXTENSION);
        $file_nib = "nib_" . $nik . "." . $ext;
        move_uploaded_file($_FILES['file_nib']['tmp_name'], "assets/uploads/dokumen/" . $file_nib);
    }

    $query = "INSERT INTO tbl_pjlp (nik, nama_lengkap, password, tempat_lahir, tgl_lahir, jenis_kelamin, alamat, no_hp, email, nib_nomor, nib_tgl_terbit, file_ktp, file_nib, status_pjlp) 
              VALUES ('$nik', '$nama', '$password', '$tempat_lahir', '$tgl_lahir', '$jk', '$alamat', '$no_hp', '$email', '$nib_nomor', '$nib_tgl', '$file_ktp', '$file_nib', '$status')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data PJLP berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=data_pjlp';</script>";
        exit(); // Exit PENTING agar notifikasi tidak hilang
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_pjlp        = amankan_input($_POST['id_pjlp']);
    $nik            = amankan_input($_POST['nik']);
    $nama           = amankan_input($_POST['nama_lengkap']);
    $tempat_lahir   = amankan_input($_POST['tempat_lahir']);
    $tgl_lahir      = amankan_input($_POST['tgl_lahir']);
    $jk             = amankan_input($_POST['jenis_kelamin']);
    $alamat         = amankan_input($_POST['alamat']);
    $no_hp          = amankan_input($_POST['no_hp']);
    $email          = amankan_input($_POST['email']);
    $nib_nomor      = amankan_input($_POST['nib_nomor']);
    $nib_tgl        = amankan_input($_POST['nib_tgl_terbit']);
    $status         = amankan_input($_POST['status_pjlp']);

    // Cek Password
    $password_query = "";
    if (!empty($_POST['password'])) {
        $pass_hash = md5($_POST['password']);
        $password_query = ", password='$pass_hash'";
    }

    // Handle Upload Update
    $q_lama = mysqli_query($koneksi, "SELECT * FROM tbl_pjlp WHERE id_pjlp='$id_pjlp'");
    $d_lama = mysqli_fetch_assoc($q_lama);

    $file_ktp = $d_lama['file_ktp'];
    if (!empty($_FILES['file_ktp']['name'])) {
        $ext = pathinfo($_FILES['file_ktp']['name'], PATHINFO_EXTENSION);
        $file_ktp = "ktp_" . $nik . "_" . time() . "." . $ext;
        move_uploaded_file($_FILES['file_ktp']['tmp_name'], "assets/uploads/dokumen/" . $file_ktp);
    }

    $file_nib = $d_lama['file_nib'];
    if (!empty($_FILES['file_nib']['name'])) {
        $ext = pathinfo($_FILES['file_nib']['name'], PATHINFO_EXTENSION);
        $file_nib = "nib_" . $nik . "_" . time() . "." . $ext;
        move_uploaded_file($_FILES['file_nib']['tmp_name'], "assets/uploads/dokumen/" . $file_nib);
    }

    $query = "UPDATE tbl_pjlp SET 
              nik='$nik', nama_lengkap='$nama', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir', 
              jenis_kelamin='$jk', alamat='$alamat', no_hp='$no_hp', email='$email', 
              nib_nomor='$nib_nomor', nib_tgl_terbit='$nib_tgl', 
              file_ktp='$file_ktp', file_nib='$file_nib', status_pjlp='$status' 
              $password_query
              WHERE id_pjlp='$id_pjlp'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data PJLP berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=data_pjlp';</script>";
        exit(); // Exit PENTING agar notifikasi tidak hilang
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- PROSES HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id_pjlp = amankan_input($_GET['id']);
    
    // Hapus fisik file
    $q_cek = mysqli_query($koneksi, "SELECT file_ktp, file_nib FROM tbl_pjlp WHERE id_pjlp='$id_pjlp'");
    $d_cek = mysqli_fetch_assoc($q_cek);
    
    if(!empty($d_cek['file_ktp']) && file_exists("assets/uploads/dokumen/".$d_cek['file_ktp'])){
        unlink("assets/uploads/dokumen/".$d_cek['file_ktp']);
    }
    if(!empty($d_cek['file_nib']) && file_exists("assets/uploads/dokumen/".$d_cek['file_nib'])){
        unlink("assets/uploads/dokumen/".$d_cek['file_nib']);
    }

    $query = "DELETE FROM tbl_pjlp WHERE id_pjlp='$id_pjlp'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data PJLP berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Data tidak bisa dihapus karena berelasi dengan tabel lain');
    }
    echo "<script>window.location.href='index.php?page=data_pjlp';</script>";
    exit(); // Exit PENTING
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen Data PJLP</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data PJLP</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH DATA (HORIZONTAL FORM)
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>
                Pastikan folder <strong>assets/uploads/dokumen/</strong> sudah tersedia di direktori sebelum mengupload file.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Data PJLP Baru</h5>
                    <a href="index.php?page=data_pjlp" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">NIK <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nik" class="form-control" required maxlength="16" placeholder="Masukkan 16 digit NIK">
                                <div class="invalid-feedback">NIK wajib diisi 16 digit.</div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lengkap <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lengkap" class="form-control" required placeholder="Nama sesuai KTP">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Password Login <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="password" name="password" class="form-control" required placeholder="Password untuk akses sistem">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tempat & Tgl Lahir</label>
                            <div class="col-sm-5">
                                <input type="text" name="tempat_lahir" class="form-control" placeholder="Tempat Lahir">
                            </div>
                            <div class="col-sm-4">
                                <input type="date" name="tgl_lahir" class="form-control">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jenis Kelamin <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="jk_l" value="L" checked>
                                    <label class="form-check-label" for="jk_l">Laki-laki</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="jk_p" value="P">
                                    <label class="form-check-label" for="jk_p">Perempuan</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Alamat Lengkap</label>
                            <div class="col-sm-9">
                                <textarea name="alamat" class="form-control" rows="3" placeholder="Alamat domisili saat ini"></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kontak</label>
                            <div class="col-sm-5">
                                <input type="text" name="no_hp" class="form-control" placeholder="No. HP / WhatsApp">
                            </div>
                            <div class="col-sm-4">
                                <input type="email" name="email" class="form-control" placeholder="Alamat Email">
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Informasi NIB</label>
                            <div class="col-sm-5">
                                <input type="text" name="nib_nomor" class="form-control" placeholder="Nomor NIB">
                            </div>
                            <div class="col-sm-4">
                                <input type="date" name="nib_tgl_terbit" class="form-control" placeholder="Tgl Terbit">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Status Kepegawaian</label>
                            <div class="col-sm-9">
                                <select name="status_pjlp" class="form-select">
                                    <option value="Aktif">Aktif</option>
                                    <option value="Non-Aktif">Non-Aktif</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Dokumen Pendukung</label>
                            <div class="col-sm-9">
                                <div class="input-group mb-2">
                                    <label class="input-group-text w-100px" for="upKTP">File KTP</label>
                                    <input type="file" class="form-control" name="file_ktp" id="upKTP">
                                </div>
                                <div class="input-group">
                                    <label class="input-group-text w-100px" for="upNIB">File NIB</label>
                                    <input type="file" class="form-control" name="file_nib" id="upNIB">
                                </div>
                                <div class="form-text">Format yang diperbolehkan: JPG, PNG, PDF.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset Form</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT DATA (HORIZONTAL FORM)
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_pjlp WHERE id_pjlp='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_pjlp';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="bi bi-info-circle me-2"></i>
                Pastikan folder <strong>assets/uploads/dokumen/</strong> sudah tersedia jika ingin memperbarui dokumen.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Data PJLP: <?= $d['nama_lengkap'] ?></h5>
                    <a href="index.php?page=data_pjlp" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <input type="hidden" name="id_pjlp" value="<?= $d['id_pjlp'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">NIK <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nik" class="form-control" value="<?= $d['nik'] ?>" required maxlength="16">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lengkap <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lengkap" class="form-control" value="<?= $d['nama_lengkap'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Password</label>
                            <div class="col-sm-9">
                                <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak ingin mengubah password">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tempat & Tgl Lahir</label>
                            <div class="col-sm-5">
                                <input type="text" name="tempat_lahir" class="form-control" value="<?= $d['tempat_lahir'] ?>">
                            </div>
                            <div class="col-sm-4">
                                <input type="date" name="tgl_lahir" class="form-control" value="<?= $d['tgl_lahir'] ?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jenis Kelamin <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="e_jk_l" value="L" <?= ($d['jenis_kelamin'] == 'L') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="e_jk_l">Laki-laki</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="e_jk_p" value="P" <?= ($d['jenis_kelamin'] == 'P') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="e_jk_p">Perempuan</label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Alamat Lengkap</label>
                            <div class="col-sm-9">
                                <textarea name="alamat" class="form-control" rows="3"><?= $d['alamat'] ?></textarea>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Kontak</label>
                            <div class="col-sm-5">
                                <input type="text" name="no_hp" class="form-control" value="<?= $d['no_hp'] ?>" placeholder="No HP">
                            </div>
                            <div class="col-sm-4">
                                <input type="email" name="email" class="form-control" value="<?= $d['email'] ?>" placeholder="Email">
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Informasi NIB</label>
                            <div class="col-sm-5">
                                <input type="text" name="nib_nomor" class="form-control" value="<?= $d['nib_nomor'] ?>" placeholder="Nomor NIB">
                            </div>
                            <div class="col-sm-4">
                                <input type="date" name="nib_tgl_terbit" class="form-control" value="<?= $d['nib_tgl_terbit'] ?>">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Status Kepegawaian</label>
                            <div class="col-sm-9">
                                <select name="status_pjlp" class="form-select">
                                    <option value="Aktif" <?= ($d['status_pjlp'] == 'Aktif') ? 'selected' : '' ?>>Aktif</option>
                                    <option value="Non-Aktif" <?= ($d['status_pjlp'] == 'Non-Aktif') ? 'selected' : '' ?>>Non-Aktif</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Dokumen Pendukung</label>
                            <div class="col-sm-9">
                                <div class="input-group mb-1">
                                    <label class="input-group-text w-100px">File KTP</label>
                                    <input type="file" class="form-control" name="file_ktp">
                                </div>
                                <?php if(!empty($d['file_ktp'])): ?>
                                    <div class="mb-2">
                                        <a href="assets/uploads/dokumen/<?= $d['file_ktp'] ?>" target="_blank" class="badge bg-info-subtle text-info text-decoration-none">
                                            <i class="bi bi-eye"></i> Lihat KTP Lama
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <div class="input-group mb-1">
                                    <label class="input-group-text w-100px">File NIB</label>
                                    <input type="file" class="form-control" name="file_nib">
                                </div>
                                <?php if(!empty($d['file_nib'])): ?>
                                    <div>
                                        <a href="assets/uploads/dokumen/<?= $d['file_nib'] ?>" target="_blank" class="badge bg-info-subtle text-info text-decoration-none">
                                            <i class="bi bi-eye"></i> Lihat NIB Lama
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA TABEL
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Pegawai PJLP</h5>
                    <a href="index.php?page=data_pjlp&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah PJLP
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>NIK</th>
                                    <th>Nama Lengkap</th>
                                    <th>JK</th>
                                    <th>No. HP</th>
                                    <th>Status</th>
                                    <th width="10%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_pjlp ORDER BY id_pjlp DESC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $row['nik'] ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-xs bg-light rounded-circle d-flex align-items-center justify-content-center me-2">
                                                <i class="bi bi-person text-primary"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0"><?= $row['nama_lengkap'] ?></h6>
                                                <small class="text-muted"><?= $row['email'] ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= $row['jenis_kelamin'] ?></td>
                                    <td><?= $row['no_hp'] ?></td>
                                    <td>
                                        <?php if($row['status_pjlp'] == 'Aktif'): ?>
                                            <span class="badge bg-success-subtle text-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger">Non-Aktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_pjlp&act=edit&id=<?= $row['id_pjlp'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=data_pjlp&act=hapus&id=<?= $row['id_pjlp'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>