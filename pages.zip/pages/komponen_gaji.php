<?php
// 1. Keamanan
if (!in_array($_SESSION['level'], ['admin', 'keuangan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// LOGIC CRUD
// ==================================================================================

// --- SIMPAN ---
if (isset($_POST['btn_simpan'])) {
    $nama = amankan_input($_POST['nama_komponen']);
    $tipe = amankan_input($_POST['tipe']);
    $nominal = amankan_input(str_replace('.', '', $_POST['nominal'])); // Hapus titik ribuan

    // Validasi Duplikasi
    $cek = mysqli_query($koneksi, "SELECT nama_komponen FROM tbl_komponen_gaji WHERE nama_komponen='$nama'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Duplikasi', 'Nama komponen gaji sudah ada!');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "INSERT INTO tbl_komponen_gaji (nama_komponen, tipe, nominal_default) VALUES ('$nama', '$tipe', '$nominal')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Komponen gaji berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=komponen_gaji';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- UPDATE ---
if (isset($_POST['btn_update'])) {
    $id   = amankan_input($_POST['id_komponen']);
    $nama = amankan_input($_POST['nama_komponen']);
    $tipe = amankan_input($_POST['tipe']);
    $nominal = amankan_input(str_replace('.', '', $_POST['nominal']));

    $query = "UPDATE tbl_komponen_gaji SET nama_komponen='$nama', tipe='$tipe', nominal_default='$nominal' WHERE id_komponen='$id'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Komponen gaji diperbarui');
        echo "<script>window.location.href='index.php?page=komponen_gaji';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- HAPUS ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    // Cek Relasi Payroll
    $cek_payroll = mysqli_query($koneksi, "SELECT id_payroll_detail FROM tbl_payroll_detail WHERE id_komponen_gaji='$id'");
    
    if (mysqli_num_rows($cek_payroll) > 0) {
        set_notifikasi('error', 'Gagal', 'Komponen sudah digunakan dalam payroll. Tidak bisa dihapus.');
        echo "<script>window.location.href='index.php?page=komponen_gaji';</script>";
        exit();
    }

    mysqli_query($koneksi, "DELETE FROM tbl_komponen_gaji WHERE id_komponen='$id'");
    set_notifikasi('success', 'Terhapus', 'Komponen gaji dihapus');
    echo "<script>window.location.href='index.php?page=komponen_gaji';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Master Komponen Gaji</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Komponen</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    case 'tambah':
    case 'edit':
        $is_edit = ($act == 'edit');
        $d = [];
        if ($is_edit) {
            $id = amankan_input($_GET['id']);
            $q = mysqli_query($koneksi, "SELECT * FROM tbl_komponen_gaji WHERE id_komponen='$id'");
            $d = mysqli_fetch_assoc($q);
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0 fw-bold text-primary"><?= $is_edit ? 'Edit Komponen' : 'Tambah Komponen Baru' ?></h5>
                    <a href="index.php?page=komponen_gaji" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <?php if($is_edit): ?>
                            <input type="hidden" name="id_komponen" value="<?= $d['id_komponen'] ?>">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Nama Komponen <span class="text-danger">*</span></label>
                            <input type="text" name="nama_komponen" class="form-control" value="<?= $is_edit ? $d['nama_komponen'] : '' ?>" required placeholder="Contoh: Tunjangan Makan">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Tipe Komponen <span class="text-danger">*</span></label>
                            <div class="d-flex gap-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="tipe" id="t_tunjangan" value="tunjangan" <?= ($is_edit && $d['tipe']=='tunjangan') ? 'checked' : (($is_edit)?'':'checked') ?>>
                                    <label class="form-check-label text-success fw-bold" for="t_tunjangan"><i class="bi bi-plus-circle"></i> Tunjangan (Penambah)</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="tipe" id="t_potongan" value="potongan" <?= ($is_edit && $d['tipe']=='potongan') ? 'checked' : '' ?>>
                                    <label class="form-check-label text-danger fw-bold" for="t_potongan"><i class="bi bi-dash-circle"></i> Potongan (Pengurang)</label>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">Nilai Default / Tarif (Rp)</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" name="nominal" class="form-control" value="<?= $is_edit ? $d['nominal_default'] : '0' ?>" required>
                            </div>
                            <div class="form-text text-muted small">
                                * Masukkan angka saja.<br>
                                * Jika <b>Tunjangan Makan/Transport</b>, isi tarif per hari (misal: 50000).<br>
                                * Jika <b>BPJS/Pajak</b>, biarkan 0 (karena dihitung % dari sistem).<br>
                                * Jika <b>Tunjangan Tetap/Potongan Koperasi</b>, isi nominal bulanan.
                            </div>
                        </div>
                        
                        <div class="text-end mt-4">
                            <button type="submit" name="<?= $is_edit ? 'btn_update' : 'btn_simpan' ?>" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i> Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0 fw-bold">Daftar Komponen Gaji</h5>
                    <a href="index.php?page=komponen_gaji&act=tambah" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i> Tambah</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-hover align-middle" style="width:100%">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Komponen</th>
                                    <th>Tipe</th>
                                    <th>Nilai Default / Tarif</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_komponen_gaji ORDER BY tipe DESC, nama_komponen ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="fw-bold"><?= $row['nama_komponen'] ?></td>
                                    <td>
                                        <?php if($row['tipe'] == 'tunjangan'): ?>
                                            <span class="badge bg-success-subtle text-success">Tunjangan</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger">Potongan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        Rp <?= number_format($row['nominal_default'], 0, ',', '.') ?>
                                        <small class="text-muted d-block" style="font-size: 10px;">
                                            <?php 
                                            // Helper text logika
                                            $n = strtolower($row['nama_komponen']);
                                            if(strpos($n, 'makan')!==false || strpos($n, 'transport')!==false) echo "(Dikali Jumlah Kehadiran)";
                                            elseif(strpos($n, 'telat')!==false || strpos($n, 'alpa')!==false) echo "(Dikali Jumlah Pelanggaran)";
                                            elseif($row['nominal_default'] == 0) echo "(Persentase / Manual)";
                                            else echo "(Flat / Tetap)";
                                            ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=komponen_gaji&act=edit&id=<?= $row['id_komponen'] ?>" class="btn btn-sm btn-info text-white"><i class="bi bi-pencil-square"></i></a>
                                            <button onclick="konfirmasiHapus('index.php?page=komponen_gaji&act=hapus&id=<?= $row['id_komponen'] ?>')" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
    break;
}
?>