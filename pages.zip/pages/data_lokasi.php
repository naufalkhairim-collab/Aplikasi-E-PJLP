<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act' (action) dari URL
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $nama_lokasi = amankan_input($_POST['nama_lokasi']);
    $latitude    = amankan_input($_POST['latitude']);
    $longitude   = amankan_input($_POST['longitude']);
    $radius      = amankan_input($_POST['radius_meter']);

    $query = "INSERT INTO tbl_lokasi_kantor (nama_lokasi, latitude, longitude, radius_meter) 
              VALUES ('$nama_lokasi', '$latitude', '$longitude', '$radius')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Lokasi kantor berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=data_lokasi';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_lokasi   = amankan_input($_POST['id_lokasi']);
    $nama_lokasi = amankan_input($_POST['nama_lokasi']);
    $latitude    = amankan_input($_POST['latitude']);
    $longitude   = amankan_input($_POST['longitude']);
    $radius      = amankan_input($_POST['radius_meter']);

    $query = "UPDATE tbl_lokasi_kantor SET 
              nama_lokasi = '$nama_lokasi', 
              latitude = '$latitude', 
              longitude = '$longitude', 
              radius_meter = '$radius' 
              WHERE id_lokasi = '$id_lokasi'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data lokasi berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=data_lokasi';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- PROSES HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id_lokasi = amankan_input($_GET['id']);
    
    $query = "DELETE FROM tbl_lokasi_kantor WHERE id_lokasi='$id_lokasi'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Lokasi kantor berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=data_lokasi';</script>";
    exit();
}
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
<script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>

<style>
    #map { height: 450px; width: 100%; border-radius: 8px; z-index: 1; }
    /* Fix bug icon search di beberapa template */
    .leaflet-control-geocoder-icon { 
        background-image: url('https://unpkg.com/leaflet-control-geocoder/dist/images/geocoder.png'); 
        width: 26px; height: 26px;
    }
</style>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Data Lokasi Kantor (GPS)</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Lokasi Kantor</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH (HORIZONTAL)
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Lokasi Kantor</h5>
                    <a href="index.php?page=data_lokasi" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="mb-4 border rounded p-1">
                            <div id="map"></div>
                            <div class="d-flex justify-content-between mt-2 px-2">
                                <small class="text-muted"><i class="bi bi-search"></i> Gunakan tombol Cari (Kaca Pembesar) di peta untuk mencari lokasi.</small>
                                <small class="text-muted"><i class="bi bi-arrows-move"></i> Geser Marker Biru untuk titik presisi.</small>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lokasi <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lokasi" class="form-control" required placeholder="Contoh: Kantor Walikota Banjarmasin">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Koordinat <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="input-group mb-2">
                                    <span class="input-group-text">Lat</span>
                                    <input type="text" name="latitude" id="lat" class="form-control" required readonly placeholder="-3.xxxxxxx">
                                    <span class="input-group-text">Long</span>
                                    <input type="text" name="longitude" id="long" class="form-control" required readonly placeholder="114.xxxxxxx">
                                </div>
                                <button type="button" class="btn btn-sm btn-info text-white" onclick="getCurrentLocation()">
                                    <i class="bi bi-geo-alt me-1"></i> Ambil Lokasi Saya Saat Ini
                                </button>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Radius Absensi</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="radius_meter" id="radius" class="form-control" value="50" min="10" required oninput="updateRadius()">
                                    <span class="input-group-text">Meter</span>
                                </div>
                                <div class="form-text">Jarak maksimal pegawai bisa absen (Visualisasi lingkaran biru di peta).</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Koordinat Default: Banjarmasin
        var defaultLat = -3.31686840;
        var defaultLng = 114.59018350;

        // Inisialisasi Map
        var map = L.map('map').setView([defaultLat, defaultLng], 15);

        // Tile Layers
        var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OSM' });
        var googleSat = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{ maxZoom: 20, subdomains:['mt0','mt1','mt2','mt3'] });
        var googleHybrid = L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}',{ maxZoom: 20, subdomains:['mt0','mt1','mt2','mt3'] });
        var googleStreets = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',{ maxZoom: 20, subdomains:['mt0','mt1','mt2','mt3'] });

        // Set Default Layer
        googleStreets.addTo(map);

        // Layer Control
        var baseMaps = {
            "Google Streets": googleStreets,
            "Google Satellite": googleSat,
            "Google Hybrid": googleHybrid,
            "OpenStreetMap": osm
        };
        L.control.layers(baseMaps).addTo(map);

        // -- FITUR PENCARIAN (GEOCODER) --
        L.Control.geocoder({
            defaultMarkGeocode: false
        })
        .on('markgeocode', function(e) {
            var bbox = e.geocode.bbox;
            var poly = L.polygon([
                bbox.getSouthEast(),
                bbox.getNorthEast(),
                bbox.getNorthWest(),
                bbox.getSouthWest()
            ]);
            map.fitBounds(poly.getBounds());

            // Pindahkan Marker ke hasil pencarian
            var center = e.geocode.center;
            marker.setLatLng(center);
            circle.setLatLng(center);
            
            // Isi Input
            document.getElementById('lat').value = center.lat;
            document.getElementById('long').value = center.lng;
        })
        .addTo(map);

        // Marker (Draggable)
        var marker = L.marker([defaultLat, defaultLng], {draggable: true}).addTo(map);
        
        // Circle (Radius)
        var circle = L.circle([defaultLat, defaultLng], {
            color: 'blue',
            fillColor: '#30a2ff',
            fillOpacity: 0.2,
            radius: 50 // Default form value
        }).addTo(map);

        // Update saat marker digeser
        marker.on('dragend', function (e) {
            var position = marker.getLatLng();
            circle.setLatLng(position); 
            map.panTo(position);
            document.getElementById('lat').value = position.lat;
            document.getElementById('long').value = position.lng;
        });

        // Update saat peta diklik
        map.on('click', function(e) {
            var position = e.latlng;
            marker.setLatLng(position);
            circle.setLatLng(position);
            document.getElementById('lat').value = position.lat;
            document.getElementById('long').value = position.lng;
        });

        function updateRadius() {
            var r = document.getElementById('radius').value;
            if(r) { circle.setRadius(r); }
        }

        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                    var newLatLng = new L.LatLng(lat, lng);
                    marker.setLatLng(newLatLng);
                    circle.setLatLng(newLatLng);
                    map.setView(newLatLng, 18);
                    document.getElementById('lat').value = lat;
                    document.getElementById('long').value = lng;
                    Swal.fire('Berhasil', 'Lokasi ditemukan!', 'success');
                }, function() {
                    Swal.fire('Gagal', 'Pastikan GPS aktif.', 'error');
                });
            }
        }
    </script>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT (HORIZONTAL)
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_lokasi_kantor WHERE id_lokasi='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_lokasi';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Lokasi Kantor</h5>
                    <a href="index.php?page=data_lokasi" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_lokasi" value="<?= $d['id_lokasi'] ?>">
                        
                        <div class="mb-4 border rounded p-1">
                            <div id="map"></div>
                            <div class="text-center mt-2">
                                <small class="text-muted">Lokasi saat ini: <?= $d['nama_lokasi'] ?></small>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Lokasi <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_lokasi" class="form-control" value="<?= $d['nama_lokasi'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Koordinat <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <div class="input-group mb-2">
                                    <span class="input-group-text">Lat</span>
                                    <input type="text" name="latitude" id="lat" class="form-control" value="<?= $d['latitude'] ?>" required readonly>
                                    <span class="input-group-text">Long</span>
                                    <input type="text" name="longitude" id="long" class="form-control" value="<?= $d['longitude'] ?>" required readonly>
                                </div>
                                <button type="button" class="btn btn-sm btn-info text-white" onclick="getCurrentLocation()">
                                    <i class="bi bi-geo-alt me-1"></i> Reset ke Lokasi Saya
                                </button>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Radius Absensi</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="radius_meter" id="radius" class="form-control" value="<?= $d['radius_meter'] ?>" min="10" required oninput="updateRadius()">
                                    <span class="input-group-text">Meter</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        var dbLat = <?= $d['latitude'] ?>;
        var dbLng = <?= $d['longitude'] ?>;
        var dbRadius = <?= $d['radius_meter'] ?>;

        var map = L.map('map').setView([dbLat, dbLng], 17);

        var osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OSM' });
        var googleHybrid = L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}',{ maxZoom: 20, subdomains:['mt0','mt1','mt2','mt3'] });
        var googleStreets = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',{ maxZoom: 20, subdomains:['mt0','mt1','mt2','mt3'] });

        googleStreets.addTo(map);

        var baseMaps = {
            "Google Streets": googleStreets,
            "Google Hybrid": googleHybrid,
            "OpenStreetMap": osm
        };
        L.control.layers(baseMaps).addTo(map);

        // SEARCH BOX
        L.Control.geocoder({
            defaultMarkGeocode: false
        })
        .on('markgeocode', function(e) {
            var bbox = e.geocode.bbox;
            var poly = L.polygon([bbox.getSouthEast(), bbox.getNorthEast(), bbox.getNorthWest(), bbox.getSouthWest()]);
            map.fitBounds(poly.getBounds());
            var center = e.geocode.center;
            marker.setLatLng(center);
            circle.setLatLng(center);
            document.getElementById('lat').value = center.lat;
            document.getElementById('long').value = center.lng;
        })
        .addTo(map);

        var marker = L.marker([dbLat, dbLng], {draggable: true}).addTo(map);
        var circle = L.circle([dbLat, dbLng], {
            color: 'blue',
            fillColor: '#30a2ff',
            fillOpacity: 0.2,
            radius: dbRadius
        }).addTo(map);

        marker.on('dragend', function (e) {
            var position = marker.getLatLng();
            marker.setLatLng(position, {draggable: true});
            circle.setLatLng(position);
            document.getElementById('lat').value = position.lat;
            document.getElementById('long').value = position.lng;
        });

        map.on('click', function(e) {
            var position = e.latlng;
            marker.setLatLng(position);
            circle.setLatLng(position);
            document.getElementById('lat').value = position.lat;
            document.getElementById('long').value = position.lng;
        });

        function updateRadius() {
            var r = document.getElementById('radius').value;
            if(r) { circle.setRadius(r); }
        }

        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;
                    var newLatLng = new L.LatLng(lat, lng);
                    marker.setLatLng(newLatLng);
                    circle.setLatLng(newLatLng);
                    map.setView(newLatLng, 18);
                    document.getElementById('lat').value = lat;
                    document.getElementById('long').value = lng;
                    Swal.fire('Berhasil', 'Lokasi diupdate!', 'success');
                });
            }
        }
    </script>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA LOKASI
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Titik Lokasi Kantor</h5>
                    <!-- <a href="index.php?page=data_lokasi&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Lokasi
                    </a> -->
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Lokasi</th>
                                    <th>Latitude</th>
                                    <th>Longitude</th>
                                    <th>Radius</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_lokasi_kantor ORDER BY nama_lokasi ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="fw-medium text-primary"><?= $row['nama_lokasi'] ?></span></td>
                                    <td><?= $row['latitude'] ?></td>
                                    <td><?= $row['longitude'] ?></td>
                                    <td><span class="badge bg-info-subtle text-info"><?= $row['radius_meter'] ?> Meter</span></td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="https://www.google.com/maps/search/?api=1&query=<?= $row['latitude'] ?>,<?= $row['longitude'] ?>" target="_blank" class="btn btn-sm btn-success text-white" data-bs-toggle="tooltip" title="Lihat di Gmaps">
                                                <i class="bi bi-map"></i>
                                            </a>
                                            <a href="index.php?page=data_lokasi&act=edit&id=<?= $row['id_lokasi'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <!-- <button onclick="konfirmasiHapus('index.php?page=data_lokasi&act=hapus&id=<?= $row['id_lokasi'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button> -->
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>