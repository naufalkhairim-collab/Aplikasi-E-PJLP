<?php
// 1. Keamanan: Hanya Admin
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// LOGIC CRUD
// ==================================================================================

// --- SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $id_pjlp  = amankan_input($_POST['id_pjlp']);
    $id_cuti  = amankan_input($_POST['id_master_cuti']);
    $tahun    = amankan_input($_POST['tahun']);
    $kuota    = amankan_input($_POST['kuota_awal']);

    // Cek Duplikasi (Satu PJLP tidak boleh punya 2 settingan kuota untuk jenis cuti yang sama di tahun yang sama)
    $cek = mysqli_query($koneksi, "SELECT id_kuota FROM tbl_kuota_cuti_pjlp WHERE id_pjlp='$id_pjlp' AND id_master_cuti='$id_cuti' AND tahun='$tahun'");
    
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Gagal', 'Pegawai ini sudah memiliki kuota untuk jenis cuti tersebut di tahun ini.');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "INSERT INTO tbl_kuota_cuti_pjlp (id_pjlp, id_master_cuti, tahun, kuota_awal, kuota_terpakai) 
              VALUES ('$id_pjlp', '$id_cuti', '$tahun', '$kuota', '0')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Kuota cuti berhasil ditambahkan.');
        echo "<script>window.location.href='index.php?page=data_kuota_cuti';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem.');
    }
}

// --- UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_kuota = amankan_input($_POST['id_kuota']);
    $kuota    = amankan_input($_POST['kuota_awal']);
    $terpakai = amankan_input($_POST['kuota_terpakai']);

    $query = "UPDATE tbl_kuota_cuti_pjlp SET kuota_awal='$kuota', kuota_terpakai='$terpakai' WHERE id_kuota='$id_kuota'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Data kuota diperbarui.');
        echo "<script>window.location.href='index.php?page=data_kuota_cuti';</script>";
        exit();
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    $query = "DELETE FROM tbl_kuota_cuti_pjlp WHERE id_kuota='$id'";
    
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data kuota dihapus.');
    }
    echo "<script>window.location.href='index.php?page=data_kuota_cuti';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen Kuota Cuti Pegawai</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Kuota Cuti</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Set Kuota Cuti Baru</h5>
                    <a href="index.php?page=data_kuota_cuti" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small">Pilih Pegawai (PJLP)</label>
                            <select name="id_pjlp" class="form-select select2" required>
                                <option value="" disabled selected>-- Cari Pegawai --</option>
                                <?php
                                $q_p = mysqli_query($koneksi, "SELECT id_pjlp, nama_lengkap, nik FROM tbl_pjlp WHERE status_pjlp='Aktif' ORDER BY nama_lengkap ASC");
                                while ($p = mysqli_fetch_assoc($q_p)) {
                                    echo "<option value='{$p['id_pjlp']}'>{$p['nama_lengkap']} - {$p['nik']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small">Jenis Cuti</label>
                                <select name="id_master_cuti" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Jenis --</option>
                                    <?php
                                    // Hanya tampilkan jenis cuti yang "mengurangi_kuota" = 1
                                    $q_c = mysqli_query($koneksi, "SELECT * FROM tbl_master_cuti WHERE mengurangi_kuota='1'");
                                    while ($c = mysqli_fetch_assoc($q_c)) {
                                        echo "<option value='{$c['id_master_cuti']}'>{$c['nama_cuti']}</option>";
                                    }
                                    ?>
                                </select>
                                <div class="form-text">Hanya jenis cuti yang memotong kuota yang muncul.</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small">Tahun Berlaku</label>
                                <input type="number" name="tahun" class="form-control" value="<?= date('Y') ?>" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold small">Jumlah Kuota Awal (Hari)</label>
                            <input type="number" name="kuota_awal" class="form-control" value="12" required>
                            <div class="form-text">Default cuti tahunan biasanya 12 hari.</div>
                        </div>

                        <div class="text-end">
                            <button type="submit" name="btn_simpan" class="btn btn-primary px-4">
                                <i class="bi bi-save me-1"></i> Simpan Kuota
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "
            SELECT k.*, p.nama_lengkap, m.nama_cuti 
            FROM tbl_kuota_cuti_pjlp k
            JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
            JOIN tbl_master_cuti m ON k.id_master_cuti = m.id_master_cuti
            WHERE k.id_kuota='$id'
        ");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_kuota_cuti';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Kuota Cuti</h5>
                    <a href="index.php?page=data_kuota_cuti" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <input type="hidden" name="id_kuota" value="<?= $d['id_kuota'] ?>">

                        <div class="alert alert-light border">
                            <strong>Pegawai:</strong> <?= $d['nama_lengkap'] ?><br>
                            <strong>Jenis Cuti:</strong> <?= $d['nama_cuti'] ?> (Tahun <?= $d['tahun'] ?>)
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small">Total Kuota (Hari)</label>
                                <input type="number" name="kuota_awal" class="form-control" value="<?= $d['kuota_awal'] ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small">Sudah Terpakai (Hari)</label>
                                <input type="number" name="kuota_terpakai" class="form-control" value="<?= $d['kuota_terpakai'] ?>" required>
                                <div class="form-text text-danger">Ubah hanya jika perlu koreksi manual.</div>
                            </div>
                        </div>

                        <div class="text-end mt-3">
                            <button type="submit" name="btn_update" class="btn btn-primary px-4">
                                <i class="bi bi-save me-1"></i> Simpan Perubahan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0 fw-bold">Daftar Kuota Cuti</h5>
                    <a href="index.php?page=data_kuota_cuti&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Set Kuota Baru
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-hover align-middle" style="width:100%">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Pegawai</th>
                                    <th>Jenis Cuti</th>
                                    <th>Tahun</th>
                                    <th class="text-center">Total Kuota</th>
                                    <th class="text-center">Terpakai</th>
                                    <th class="text-center">Sisa</th>
                                    <th width="10%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "
                                    SELECT k.*, p.nama_lengkap, m.nama_cuti 
                                    FROM tbl_kuota_cuti_pjlp k
                                    JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                    JOIN tbl_master_cuti m ON k.id_master_cuti = m.id_master_cuti
                                    ORDER BY k.tahun DESC, p.nama_lengkap ASC
                                ");
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $sisa = $row['kuota_awal'] - $row['kuota_terpakai'];
                                    $badge = ($sisa > 0) ? 'success' : 'danger';
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="fw-bold"><?= $row['nama_lengkap'] ?></td>
                                    <td><?= $row['nama_cuti'] ?></td>
                                    <td><?= $row['tahun'] ?></td>
                                    <td class="text-center"><?= $row['kuota_awal'] ?></td>
                                    <td class="text-center"><?= $row['kuota_terpakai'] ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-<?= $badge ?> rounded-pill px-3"><?= $sisa ?> Hari</span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_kuota_cuti&act=edit&id=<?= $row['id_kuota'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil-square"></i></a>
                                            <button onclick="konfirmasiHapus('index.php?page=data_kuota_cuti&act=hapus&id=<?= $row['id_kuota'] ?>')" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
    break;
}
?>