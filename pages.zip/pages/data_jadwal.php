<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act' (action) dari URL
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $nama_jadwal = amankan_input($_POST['nama_jadwal']);
    $jam_masuk   = amankan_input($_POST['jam_masuk']);
    $jam_pulang  = amankan_input($_POST['jam_pulang']);
    $toleransi   = amankan_input($_POST['toleransi_masuk_menit']);

    $query = "INSERT INTO tbl_jadwal_kerja (nama_jadwal, jam_masuk, jam_pulang, toleransi_masuk_menit) 
              VALUES ('$nama_jadwal', '$jam_masuk', '$jam_pulang', '$toleransi')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Jadwal kerja berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=data_jadwal';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_jadwal   = amankan_input($_POST['id_jadwal']);
    $nama_jadwal = amankan_input($_POST['nama_jadwal']);
    $jam_masuk   = amankan_input($_POST['jam_masuk']);
    $jam_pulang  = amankan_input($_POST['jam_pulang']);
    $toleransi   = amankan_input($_POST['toleransi_masuk_menit']);

    $query = "UPDATE tbl_jadwal_kerja SET 
              nama_jadwal = '$nama_jadwal', 
              jam_masuk = '$jam_masuk', 
              jam_pulang = '$jam_pulang', 
              toleransi_masuk_menit = '$toleransi' 
              WHERE id_jadwal = '$id_jadwal'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Jadwal kerja berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=data_jadwal';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- PROSES HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id_jadwal = amankan_input($_GET['id']);
    
    // Cek Relasi Data (Opsional: Jika nanti tabel jadwal berelasi dengan tabel lain)
    // Untuk saat ini langsung hapus karena di SQL dump belum ada relasi mengikat kuat (Cascade/Restrict)
    
    $query = "DELETE FROM tbl_jadwal_kerja WHERE id_jadwal='$id_jadwal'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Jadwal kerja berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Data tidak bisa dihapus karena sedang digunakan');
    }
    echo "<script>window.location.href='index.php?page=data_jadwal';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Data Master Jadwal Kerja</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Jadwal Kerja</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH (HORIZONTAL)
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Jadwal Kerja</h5>
                    <a href="index.php?page=data_jadwal" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Jadwal <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_jadwal" class="form-control" required placeholder="Contoh: Shift Pagi, Non-Shift">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jam Masuk <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="time" name="jam_masuk" class="form-control" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jam Pulang <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="time" name="jam_pulang" class="form-control" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Toleransi (Menit)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="toleransi_masuk_menit" class="form-control" value="0" min="0">
                                    <span class="input-group-text">Menit</span>
                                </div>
                                <div class="form-text">Batas toleransi keterlambatan yang diizinkan.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT (HORIZONTAL)
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_jadwal_kerja WHERE id_jadwal='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_jadwal';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Jadwal Kerja</h5>
                    <a href="index.php?page=data_jadwal" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_jadwal" value="<?= $d['id_jadwal'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Jadwal <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_jadwal" class="form-control" value="<?= $d['nama_jadwal'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jam Masuk <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="time" name="jam_masuk" class="form-control" value="<?= $d['jam_masuk'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Jam Pulang <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="time" name="jam_pulang" class="form-control" value="<?= $d['jam_pulang'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Toleransi (Menit)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <input type="number" name="toleransi_masuk_menit" class="form-control" value="<?= $d['toleransi_masuk_menit'] ?>" min="0">
                                    <span class="input-group-text">Menit</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA JADWAL
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Jadwal Kerja</h5>
                    <a href="index.php?page=data_jadwal&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Jadwal
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Jadwal</th>
                                    <th>Jam Masuk</th>
                                    <th>Jam Pulang</th>
                                    <th>Toleransi</th>
                                    <th width="10%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_jadwal_kerja ORDER BY nama_jadwal ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><span class="fw-medium text-primary"><?= $row['nama_jadwal'] ?></span></td>
                                    <td><?= date('H:i', strtotime($row['jam_masuk'])) ?> WIB</td>
                                    <td><?= date('H:i', strtotime($row['jam_pulang'])) ?> WIB</td>
                                    <td>
                                        <?php if($row['toleransi_masuk_menit'] > 0): ?>
                                            <span class="badge bg-warning-subtle text-warning"><?= $row['toleransi_masuk_menit'] ?> Menit</span>
                                        <?php else: ?>
                                            <span class="badge bg-success-subtle text-success">0 Menit</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_jadwal&act=edit&id=<?= $row['id_jadwal'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=data_jadwal&act=hapus&id=<?= $row['id_jadwal'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>