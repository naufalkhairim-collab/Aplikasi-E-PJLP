<?php
// 1. Keamanan: Hanya Admin & Pimpinan
if (!in_array($_SESSION['level'], ['admin', 'pimpinan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (APPROVE, REJECT, HAPUS)
// ==================================================================================

// --- PROSES SETUJUI (APPROVE) ---
if ($act == 'approve' && isset($_GET['id'])) {
    $id_pengajuan = amankan_input($_GET['id']);
    $id_admin     = $_SESSION['id_user'];
    $tgl_now      = date('Y-m-d H:i:s');

    // 1. Ambil Data Pengajuan & Master Cuti
    $q_cek = mysqli_query($koneksi, "
        SELECT pc.*, mc.mengurangi_kuota 
        FROM tbl_pengajuan_cuti pc
        JOIN tbl_master_cuti mc ON pc.id_master_cuti = mc.id_master_cuti
        WHERE pc.id_pengajuan = '$id_pengajuan'
    ");
    $d_cek = mysqli_fetch_assoc($q_cek);

    if ($d_cek['status_pengajuan'] != 'Diajukan') {
        set_notifikasi('warning', 'Sudah Inproses', 'Data ini sudah diproses sebelumnya.');
        echo "<script>window.location.href='index.php?page=pengajuan_cuti_admin';</script>";
        exit();
    }

    // 2. Logika Potong Kuota (Jika Jenis Cuti Mengurangi Kuota)
    $tahun_ini = date('Y');
    if ($d_cek['mengurangi_kuota'] == '1') {
        $id_pjlp     = $d_cek['id_pjlp'];
        $id_master   = $d_cek['id_master_cuti'];
        $jumlah_hari = $d_cek['jumlah_hari'];

        // Cek apakah data kuota ada?
        $cek_kuota = mysqli_query($koneksi, "SELECT * FROM tbl_kuota_cuti_pjlp WHERE id_pjlp='$id_pjlp' AND id_master_cuti='$id_master' AND tahun='$tahun_ini'");
        
        if (mysqli_num_rows($cek_kuota) > 0) {
            // Update Kuota Terpakai
            mysqli_query($koneksi, "UPDATE tbl_kuota_cuti_pjlp SET kuota_terpakai = kuota_terpakai + $jumlah_hari WHERE id_pjlp='$id_pjlp' AND id_master_cuti='$id_master' AND tahun='$tahun_ini'");
        } else {
            // Jika belum ada record kuota, buat baru (Opsional, tergantung kebijakan)
            // Di sini kita abaikan atau bisa insert baru dengan kuota default
        }
    }

    // 3. Update Status Pengajuan
    $query = "UPDATE tbl_pengajuan_cuti SET 
              status_pengajuan = 'Disetujui',
              id_user_penyetuju = '$id_admin',
              tgl_disetujui = '$tgl_now'
              WHERE id_pengajuan = '$id_pengajuan'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Disetujui', 'Pengajuan cuti telah disetujui.');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem.');
    }
    echo "<script>window.location.href='index.php?page=pengajuan_cuti_admin';</script>";
    exit();
}

// --- PROSES TOLAK (REJECT) ---
if (isset($_POST['btn_tolak'])) {
    $id_pengajuan = amankan_input($_POST['id_pengajuan']);
    $catatan      = amankan_input($_POST['catatan_atasan']);
    $id_admin     = $_SESSION['id_user'];
    $tgl_now      = date('Y-m-d H:i:s');

    $query = "UPDATE tbl_pengajuan_cuti SET 
              status_pengajuan = 'Ditolak',
              id_user_penyetuju = '$id_admin',
              tgl_disetujui = '$tgl_now',
              catatan_atasan = '$catatan'
              WHERE id_pengajuan = '$id_pengajuan'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Ditolak', 'Pengajuan cuti ditolak.');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem.');
    }
    echo "<script>window.location.href='index.php?page=pengajuan_cuti_admin';</script>";
    exit();
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    if ($_SESSION['level'] != 'admin') { // Hanya admin boleh hapus
        set_notifikasi('error', 'Akses Ditolak', 'Hanya Admin yang boleh menghapus data.');
        echo "<script>history.back();</script>";
        exit();
    }

    $id = amankan_input($_GET['id']);
    
    // Hapus File Fisik
    $q_file = mysqli_query($koneksi, "SELECT file_pendukung FROM tbl_pengajuan_cuti WHERE id_pengajuan='$id'");
    $d_file = mysqli_fetch_assoc($q_file);
    if (!empty($d_file['file_pendukung']) && file_exists("assets/uploads/cuti/" . $d_file['file_pendukung'])) {
        unlink("assets/uploads/cuti/" . $d_file['file_pendukung']);
    }

    $query = "DELETE FROM tbl_pengajuan_cuti WHERE id_pengajuan='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data pengajuan berhasil dihapus');
    }
    echo "<script>window.location.href='index.php?page=pengajuan_cuti_admin';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Persetujuan Cuti Pegawai</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Approval Cuti</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs-custom rounded card-header-tabs border-bottom-0" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#tab-pending" role="tab">
                            <i class="bi bi-hourglass-split me-1"></i> Menunggu Konfirmasi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#tab-history" role="tab">
                            <i class="bi bi-clock-history me-1"></i> Riwayat Proses
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body p-4">
                <div class="tab-content">
                    
                    <div class="tab-pane active" id="tab-pending" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-nowrap table-striped table-bordered w-100" id="table-pending">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th>Nama Pegawai</th>
                                        <th>Jenis Cuti</th>
                                        <th>Tanggal Pengajuan</th>
                                        <th>Lama</th>
                                        <th>Bukti</th>
                                        <th width="15%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $query = mysqli_query($koneksi, "
                                        SELECT pc.*, p.nama_lengkap, p.nik, mc.nama_cuti, mc.kode_cuti 
                                        FROM tbl_pengajuan_cuti pc
                                        JOIN tbl_pjlp p ON pc.id_pjlp = p.id_pjlp
                                        JOIN tbl_master_cuti mc ON pc.id_master_cuti = mc.id_master_cuti
                                        WHERE pc.status_pengajuan = 'Diajukan'
                                        ORDER BY pc.tgl_diajukan ASC
                                    ");
                                    while ($row = mysqli_fetch_assoc($query)) {
                                    ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= $row['nama_lengkap'] ?></div>
                                            <small class="text-muted">NIK: <?= $row['nik'] ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-info-subtle text-info"><?= $row['nama_cuti'] ?></span>
                                            <div class="small mt-1 text-wrap" style="width: 200px; font-size: 11px;">
                                                Ket: <?= $row['keterangan_pjlp'] ?>
                                            </div>
                                        </td>
                                        <td>
                                            <i class="bi bi-calendar-event me-1"></i> <?= date('d/m/Y', strtotime($row['tgl_mulai'])) ?> <br>
                                            <small class="text-muted">s/d <?= date('d/m/Y', strtotime($row['tgl_selesai'])) ?></small>
                                        </td>
                                        <td><span class="fw-bold"><?= $row['jumlah_hari'] ?> Hari</span></td>
                                        <td>
                                            <?php if(!empty($row['file_pendukung'])): ?>
                                                <a href="assets/uploads/cuti/<?= $row['file_pendukung'] ?>" target="_blank" class="btn btn-sm btn-light border" title="Lihat File">
                                                    <i class="bi bi-file-earmark-pdf text-danger"></i>
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <button onclick="konfirmasiApprove('<?= $row['id_pengajuan'] ?>', '<?= $row['nama_lengkap'] ?>')" class="btn btn-sm btn-success">
                                                    <i class="bi bi-check-lg"></i> Setuju
                                                </button>
                                                <button type="button" class="btn btn-sm btn-danger" onclick="bukaModalTolak('<?= $row['id_pengajuan'] ?>', '<?= $row['nama_lengkap'] ?>')">
                                                    <i class="bi bi-x-lg"></i> Tolak
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                            <?php if(mysqli_num_rows($query) == 0) echo '<div class="text-center text-muted my-4">Tidak ada pengajuan cuti baru.</div>'; ?>
                        </div>
                    </div>

                    <div class="tab-pane" id="tab-history" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-nowrap table-striped table-bordered w-100" id="default_datatable">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th>Nama Pegawai</th>
                                        <th>Jenis Cuti</th>
                                        <th>Tanggal Cuti</th>
                                        <th>Status</th>
                                        <th>Approver</th>
                                        <th width="5%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $no = 1;
                                    $query = mysqli_query($koneksi, "
                                        SELECT pc.*, p.nama_lengkap, mc.nama_cuti, u.nama_lengkap as nama_penyetuju
                                        FROM tbl_pengajuan_cuti pc
                                        JOIN tbl_pjlp p ON pc.id_pjlp = p.id_pjlp
                                        JOIN tbl_master_cuti mc ON pc.id_master_cuti = mc.id_master_cuti
                                        LEFT JOIN tbl_users u ON pc.id_user_penyetuju = u.id_user
                                        WHERE pc.status_pengajuan != 'Diajukan'
                                        ORDER BY pc.tgl_disetujui DESC
                                    ");
                                    while ($row = mysqli_fetch_assoc($query)) {
                                    ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $row['nama_lengkap'] ?></td>
                                        <td><?= $row['nama_cuti'] ?></td>
                                        <td>
                                            <?= date('d M', strtotime($row['tgl_mulai'])) ?> - <?= date('d M Y', strtotime($row['tgl_selesai'])) ?>
                                            <span class="text-muted ms-1">(<?= $row['jumlah_hari'] ?> Hari)</span>
                                        </td>
                                        <td>
                                            <?php if($row['status_pengajuan'] == 'Disetujui'): ?>
                                                <span class="badge bg-success-subtle text-success">Disetujui</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger-subtle text-danger">Ditolak</span>
                                                <i class="bi bi-info-circle text-muted ms-1" data-bs-toggle="tooltip" title="Alasan: <?= $row['catatan_atasan'] ?>"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="d-block text-muted">Oleh: <?= $row['nama_penyetuju'] ?></small>
                                            <small class="d-block text-muted"><?= date('d/m/y H:i', strtotime($row['tgl_disetujui'])) ?></small>
                                        </td>
                                        <td>
                                            <?php if($_SESSION['level'] == 'admin'): ?>
                                            <button onclick="konfirmasiHapus('index.php?page=pengajuan_cuti_admin&act=hapus&id=<?= $row['id_pengajuan'] ?>')" class="btn btn-sm btn-outline-danger" title="Hapus Data">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalTolak" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tolak Pengajuan Cuti</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id_pengajuan" id="tolak_id">
                    <p>Anda akan menolak pengajuan atas nama <strong id="tolak_nama"></strong>.</p>
                    <div class="mb-3">
                        <label class="form-label">Alasan Penolakan <span class="text-danger">*</span></label>
                        <textarea name="catatan_atasan" class="form-control" rows="3" required placeholder="Contoh: Kuota habis, Tenaga dibutuhkan saat tanggal tersebut..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="btn_tolak" class="btn btn-danger">Tolak Pengajuan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function konfirmasiApprove(id, nama) {
        Swal.fire({
            title: 'Setujui Pengajuan?',
            text: "Pengajuan atas nama " + nama + " akan disetujui. Kuota cuti akan otomatis terpotong jika berlaku.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#198754',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, Setujui',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'index.php?page=pengajuan_cuti_admin&act=approve&id=' + id;
            }
        })
    }

    function bukaModalTolak(id, nama) {
        document.getElementById('tolak_id').value = id;
        document.getElementById('tolak_nama').innerText = nama;
        var myModal = new bootstrap.Modal(document.getElementById('modalTolak'));
        myModal.show();
    }
</script>