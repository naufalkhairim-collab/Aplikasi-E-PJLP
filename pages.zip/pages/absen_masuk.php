<?php
// 1. Keamanan: Hanya PJLP
if ($_SESSION['level'] != 'pjlp') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$id_pjlp = $_SESSION['id_user'];
$tgl_hari_ini = date('Y-m-d');

// 2. Cek Kontrak Aktif & Lokasi Kantor
// Kita join ke tabel lokasi kantor (Asumsi 1 lokasi utama atau berdasarkan unit jika ada relasi)
// Jika kantor banyak, logic ini harus disesuaikan dengan ID Lokasi di Unit Kerja.
$q_kontrak = mysqli_query($koneksi, "
    SELECT k.id_kontrak, u.nama_unit_kerja, l.latitude, l.longitude, l.radius_meter, l.nama_lokasi
    FROM tbl_kontrak k
    JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
    JOIN tbl_lokasi_kantor l ON l.id_lokasi = (SELECT id_lokasi FROM tbl_lokasi_kantor LIMIT 1) 
    WHERE k.id_pjlp='$id_pjlp' AND k.status_kontrak='Aktif'
");
$d_kontrak = mysqli_fetch_assoc($q_kontrak);

if (!$d_kontrak) {
    echo '<div class="alert alert-danger text-center">Anda tidak memiliki kontrak kerja aktif atau Data Lokasi Kantor belum disetting Admin.</div>';
    exit();
}

$id_kontrak = $d_kontrak['id_kontrak'];

// 3. Cek Apakah Sudah Absen Masuk?
$cek_absen = mysqli_query($koneksi, "SELECT id_absen, jam_masuk, status_masuk FROM tbl_absensi WHERE id_kontrak='$id_kontrak' AND tanggal='$tgl_hari_ini'");
if (mysqli_num_rows($cek_absen) > 0) {
    $data_absen = mysqli_fetch_assoc($cek_absen);
    ?>
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow border-0 text-center p-4">
                <div class="mb-3">
                    <i class="bi bi-check-circle-fill text-success" style="font-size: 5rem;"></i>
                </div>
                <h4 class="fw-bold">Sudah Absen Masuk</h4>
                <p class="text-muted">Anda telah melakukan absensi pada:</p>
                <h2 class="fw-bold text-primary mb-3"><?= date('H:i', strtotime($data_absen['jam_masuk'])) ?> WIB</h2>
                <span class="badge bg-<?= ($data_absen['status_masuk'] == 'Tepat Waktu') ? 'success' : 'warning' ?> fs-6 mb-4">
                    <?= $data_absen['status_masuk'] ?>
                </span>
                <a href="index.php" class="btn btn-outline-primary">Kembali ke Dashboard</a>
            </div>
        </div>
    </div>
    <?php
    exit();
}

// 4. Ambil Jadwal Kerja
$q_jadwal = mysqli_query($koneksi, "SELECT * FROM tbl_jadwal_kerja LIMIT 1");
$d_jadwal = mysqli_fetch_assoc($q_jadwal);

// ==================================================================================
// PROSES SIMPAN ABSEN (POST)
// ==================================================================================
if (isset($_POST['btn_absen'])) {
    $lat_masuk  = $_POST['latitude'];
    $long_masuk = $_POST['longitude'];
    // Validasi Lat/Long tidak boleh kosong
    if(empty($lat_masuk) || empty($long_masuk)){
        set_notifikasi('error', 'Gagal', 'Lokasi GPS tidak terdeteksi. Izinkan akses lokasi di browser.');
        echo "<script>history.back();</script>";
        exit();
    }

    $jam_skrg   = date('H:i:s');
    
    // Upload Foto
    $foto_name = '';
    if (!empty($_FILES['foto_masuk']['name'])) {
        $ext = pathinfo($_FILES['foto_masuk']['name'], PATHINFO_EXTENSION);
        $foto_name = "masuk_" . $id_pjlp . "_" . date('Ymd_His') . "." . $ext;
        
        // Pastikan folder ada
        if (!file_exists("assets/uploads/absensi")) {
            mkdir("assets/uploads/absensi", 0777, true);
        }
        
        move_uploaded_file($_FILES['foto_masuk']['tmp_name'], "assets/uploads/absensi/" . $foto_name);
    } else {
        set_notifikasi('warning', 'Foto Wajib', 'Anda harus mengambil foto selfie!');
        echo "<script>history.back();</script>";
        exit();
    }

    // Tentukan Status (Tepat Waktu / Terlambat)
    $jam_masuk_jadwal = $d_jadwal['jam_masuk'];
    $toleransi        = $d_jadwal['toleransi_masuk_menit'];
    // Tambah menit toleransi ke jam masuk
    $batas_telat      = date('H:i:s', strtotime("+$toleransi minutes", strtotime($jam_masuk_jadwal)));

    $status_masuk = ($jam_skrg > $batas_telat) ? 'Terlambat' : 'Tepat Waktu';

    // Insert Database
    $query = "INSERT INTO tbl_absensi (id_kontrak, tanggal, status_kehadiran, jam_masuk, foto_masuk, lat_masuk, long_masuk, status_masuk) 
              VALUES ('$id_kontrak', '$tgl_hari_ini', 'Hadir', '$jam_skrg', '$foto_name', '$lat_masuk', '$long_masuk', '$status_masuk')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Absensi Masuk Tercatat! Status: ' . $status_masuk);
        echo "<script>window.location.href='index.php';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem: ' . mysqli_error($koneksi));
    }
}
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body bg-primary text-white rounded p-4 text-center">
                <h5 class="fw-bold mb-1">Form Absensi Masuk</h5>
                <p class="mb-0 opacity-75"><?= date('l, d F Y') ?></p>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-3">
                
                <form action="" method="POST" enctype="multipart/form-data" id="formAbsen">
                    <input type="hidden" name="latitude" id="lat">
                    <input type="hidden" name="longitude" id="long">

                    <div class="mb-3 position-relative">
                        <label class="form-label fw-bold small text-muted text-uppercase">1. Deteksi Lokasi</label>
                        <div id="map" style="height: 280px; border-radius: 12px; border: 1px solid #dee2e6;"></div>
                        
                        <div class="position-absolute bottom-0 start-0 w-100 p-2" style="z-index: 999;">
                            <div class="card border-0 shadow-sm bg-white bg-opacity-90 backdrop-blur">
                                <div class="card-body p-2 d-flex justify-content-between align-items-center">
                                    <div style="font-size: 11px; line-height: 1.2;">
                                        <span class="text-muted">Jarak ke Kantor:</span><br>
                                        <strong id="info_jarak" class="fs-6">Mencari...</strong>
                                    </div>
                                    <div id="status_radius">
                                        <span class="badge bg-secondary">Menunggu GPS...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-muted text-uppercase">2. Bukti Foto</label>
                        <div class="input-group">
                            <input type="file" name="foto_masuk" class="form-control" accept="image/*" capture="user" required>
                            <span class="input-group-text"><i class="bi bi-camera-fill"></i></span>
                        </div>
                        <div class="form-text small">Wajib selfie menggunakan seragam kerja.</div>
                    </div>

                    <div class="alert alert-light border-start border-4 border-primary shadow-sm mb-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted d-block">Jam Masuk</small>
                                <span class="fw-bold text-dark fs-5"><?= date('H:i', strtotime($d_jadwal['jam_masuk'])) ?></span>
                            </div>
                            <div class="text-end">
                                <small class="text-muted d-block">Batas Toleransi</small>
                                <span class="fw-bold text-danger fs-5">
                                    <?= date('H:i', strtotime("+$d_jadwal[toleransi_masuk_menit] minutes", strtotime($d_jadwal['jam_masuk']))) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="btn_absen" id="btn_submit" class="btn btn-secondary w-100 py-3 fw-bold rounded-pill shadow-sm" disabled>
                        <i class="bi bi-geo-alt me-1"></i> Mencari Lokasi...
                    </button>

                </form>
            </div>
        </div>
        
        <div class="text-center mt-3 mb-5">
            <a href="index.php" class="text-muted text-decoration-none small"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
        </div>

    </div>
</div>

<script>
    // === KONFIGURASI DARI PHP ===
    var kantorLat = <?= $d_kontrak['latitude'] ?>;
    var kantorLng = <?= $d_kontrak['longitude'] ?>;
    var radiusMax = <?= $d_kontrak['radius_meter'] ?>; // dalam meter

    // === INISIALISASI PETA ===
    var map = L.map('map', {
        zoomControl: false // Sembunyikan kontrol zoom agar bersih di HP
    }).setView([kantorLat, kantorLng], 16);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OSM'
    }).addTo(map);

    // Marker Kantor
    var kantorIcon = L.divIcon({
        className: 'custom-div-icon',
        html: "<div style='background-color:#0d6efd; width:15px; height:15px; border-radius:50%; border:2px solid white; box-shadow: 0 0 5px rgba(0,0,0,0.3);'></div>",
        iconSize: [15, 15],
        iconAnchor: [7, 7]
    });
    L.marker([kantorLat, kantorLng], {icon: kantorIcon}).addTo(map).bindPopup("<b>Kantor</b>").openPopup();

    // Lingkaran Radius
    var circle = L.circle([kantorLat, kantorLng], {
        color: '#0d6efd',
        fillColor: '#0d6efd',
        fillOpacity: 0.1,
        radius: radiusMax
    }).addTo(map);

    // Marker User
    var userMarker;

    // Fungsi Hitung Jarak (Haversine Formula)
    function getDistance(lat1, lon1, lat2, lon2) {
        var R = 6371; // km
        var dLat = toRad(lat2 - lat1);
        var dLon = toRad(lon2 - lon1);
        var lat1 = toRad(lat1);
        var lat2 = toRad(lat2);

        var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
        var d = R * c;
        return Math.round(d * 1000); // return meter
    }

    function toRad(Value) {
        return Value * Math.PI / 180;
    }

    // === GEOLOCATION BROWSER ===
    if (navigator.geolocation) {
        navigator.geolocation.watchPosition(showPosition, showError, {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        });
    } else {
        alert("Browser Anda tidak mendukung Geolocation.");
    }

    function showPosition(position) {
        var lat = position.coords.latitude;
        var lng = position.coords.longitude;
        var acc = position.coords.accuracy;

        // Isi Input Hidden
        document.getElementById('lat').value = lat;
        document.getElementById('long').value = lng;

        // Update Marker User
        if (userMarker) {
            map.removeLayer(userMarker);
        }
        userMarker = L.marker([lat, lng], {
            icon: L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41]
            })
        }).addTo(map);

        // Hitung Jarak
        var jarak = getDistance(lat, lng, kantorLat, kantorLng);
        var infoJarak = document.getElementById('info_jarak');
        var statusRadius = document.getElementById('status_radius');
        var btnSubmit = document.getElementById('btn_submit');

        infoJarak.innerText = jarak + " Meter";

        // Logic Radius
        if (jarak <= radiusMax) {
            // DALAM RADIUS
            statusRadius.innerHTML = '<span class="badge bg-success"><i class="bi bi-geo-alt-fill"></i> Di Zona Absen</span>';
            
            circle.setStyle({color: '#198754', fillColor: '#198754'}); // Hijau

            btnSubmit.disabled = false;
            btnSubmit.classList.remove('btn-secondary', 'btn-danger');
            btnSubmit.classList.add('btn-primary');
            btnSubmit.innerHTML = '<i class="bi bi-send-fill me-1"></i> KIRIM ABSENSI';
        } else {
            // LUAR RADIUS
            statusRadius.innerHTML = '<span class="badge bg-danger"><i class="bi bi-x-circle-fill"></i> Terlalu Jauh</span>';
            
            circle.setStyle({color: '#dc3545', fillColor: '#dc3545'}); // Merah

            btnSubmit.disabled = true;
            btnSubmit.classList.remove('btn-primary', 'btn-secondary');
            btnSubmit.classList.add('btn-danger');
            btnSubmit.innerHTML = '<i class="bi bi-ban me-1"></i> Lokasi Terlalu Jauh';
        }

        // Auto Zoom Fit (Hanya sekali di awal atau jika jarak jauh)
        // var group = new L.featureGroup([L.marker([kantorLat, kantorLng]), userMarker]);
        // map.fitBounds(group.getBounds().pad(0.2));
    }

    function showError(error) {
        var btnSubmit = document.getElementById('btn_submit');
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = "GPS Error: " + error.message;
        
        Swal.fire({
            icon: 'error',
            title: 'GPS Bermasalah',
            text: 'Pastikan GPS aktif dan izin lokasi diberikan pada browser ini.'
        });
    }
</script>

<style>
    /* Backdrop blur effect */
    .backdrop-blur {
        backdrop-filter: blur(5px);
        -webkit-backdrop-filter: blur(5px);
    }
</style>