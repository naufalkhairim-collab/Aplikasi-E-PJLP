<?php
// 1. Cek Akses: Hanya Admin, Pimpinan, Keuangan yang bisa akses
// PJLP tidak bisa akses halaman input ini
if (in_array($_SESSION['level'], ['pjlp'])) {
    echo "<script>alert('Anda tidak memiliki akses ke halaman ini.'); window.location='index.php';</script>";
    exit();
}

$level_login = $_SESSION['level']; // admin, pimpinan, atau keuangan
$id_penilai  = $_SESSION['id_user'];
$bulan_ini   = date('m');
$tahun_ini   = date('Y');

// Handle Filter
$f_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : $bulan_ini;
$f_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : $tahun_ini;
$act     = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES SIMPAN NILAI
// ==================================================================================
if (isset($_POST['btn_simpan_nilai'])) {
    $id_kontrak_target = amankan_input($_POST['id_kontrak']);
    
    // 1. Cek/Buat Header Penilaian dulu (Jika belum ada di bulan ini)
    $cek_header = mysqli_query($koneksi, "SELECT id_penilaian FROM tbl_penilaian_header WHERE id_kontrak='$id_kontrak_target' AND bulan='$f_bulan' AND tahun='$f_tahun'");
    
    if (mysqli_num_rows($cek_header) > 0) {
        $d_head = mysqli_fetch_assoc($cek_header);
        $id_penilaian = $d_head['id_penilaian'];
    } else {
        // Buat header baru dengan nilai 0
        mysqli_query($koneksi, "INSERT INTO tbl_penilaian_header (id_kontrak, bulan, tahun, nilai_akhir) VALUES ('$id_kontrak_target', '$f_bulan', '$f_tahun', 0)");
        $id_penilaian = mysqli_insert_id($koneksi);
    }

    // 2. Hapus nilai lama dari penilai ini (agar bersih saat update)
    mysqli_query($koneksi, "DELETE FROM tbl_penilaian_detail WHERE id_penilaian='$id_penilaian' AND tipe_penilai='$level_login'");

    // 3. Simpan Nilai Per Kriteria (Looping input post)
    $kriteria = mysqli_query($koneksi, "SELECT * FROM tbl_kriteria_penilaian");
    while ($k = mysqli_fetch_assoc($kriteria)) {
        $id_krit = $k['id_kriteria'];
        $input_name = "nilai_" . $id_krit;
        // Ambil input, default 0 jika kosong
        $nilai_input = isset($_POST[$input_name]) ? (int)$_POST[$input_name] : 0;

        $q_insert = "INSERT INTO tbl_penilaian_detail (id_penilaian, id_kriteria, id_penilai, tipe_penilai, nilai_input) 
                     VALUES ('$id_penilaian', '$id_krit', '$id_penilai', '$level_login', '$nilai_input')";
        mysqli_query($koneksi, $q_insert);
    }

    // 4. HITUNG ULANG SKOR AKHIR (Weighted Average)
    // Bobot: Pimpinan 50%, Admin 30%, Keuangan 20%
    
    // Ambil rata-rata nilai per aktor
    $q_avg = mysqli_query($koneksi, "
        SELECT tipe_penilai, AVG(nilai_input) as rata_rata 
        FROM tbl_penilaian_detail 
        WHERE id_penilaian='$id_penilaian' 
        GROUP BY tipe_penilai
    ");
    
    $nilai_pimpinan = 0;
    $nilai_admin    = 0;
    $nilai_keuangan = 0;

    while($avg = mysqli_fetch_assoc($q_avg)){
        if($avg['tipe_penilai'] == 'pimpinan') $nilai_pimpinan = $avg['rata_rata'];
        if($avg['tipe_penilai'] == 'admin')    $nilai_admin    = $avg['rata_rata'];
        if($avg['tipe_penilai'] == 'keuangan') $nilai_keuangan = $avg['rata_rata'];
    }

    // Rumus Bobot
    $skor_akhir = ($nilai_pimpinan * 0.5) + ($nilai_admin * 0.3) + ($nilai_keuangan * 0.2);

    // Update Header dengan Skor Baru
    mysqli_query($koneksi, "UPDATE tbl_penilaian_header SET nilai_akhir='$skor_akhir' WHERE id_penilaian='$id_penilaian'");

    echo "<script>alert('Nilai berhasil disimpan!'); window.location='index.php?page=penilaian_kinerja&bulan=$f_bulan&tahun=$f_tahun';</script>";
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Penilaian Kinerja (Multi-Aktor)</h6>
    <div class="flex-shrink-0">
        <form method="GET" class="d-flex gap-2">
            <input type="hidden" name="page" value="penilaian_kinerja">
            <select name="bulan" class="form-select form-select-sm">
                <?php
                $bulan_indo = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
                foreach($bulan_indo as $kb => $nb){
                    $sel = ($kb == $f_bulan) ? 'selected' : '';
                    echo "<option value='$kb' $sel>$nb</option>";
                }
                ?>
            </select>
            <select name="tahun" class="form-select form-select-sm">
                <?php for($t=2024; $t<=date('Y')+1; $t++){ 
                    $sel = ($t == $f_tahun) ? 'selected' : '';
                    echo "<option value='$t' $sel>$t</option>";
                } ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-search"></i></button>
        </form>
    </div>
</div>

<?php if ($act == 'nilai'): 
    // ==========================================================================
    // FORM INPUT NILAI
    // ==========================================================================
    $id_k = amankan_input($_GET['id_kontrak']);
    
    // Ambil Data Pegawai
    $q_peg = mysqli_query($koneksi, "SELECT p.nama_lengkap, p.nik, u.nama_unit_kerja 
                                     FROM tbl_kontrak k 
                                     JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp 
                                     JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja 
                                     WHERE k.id_kontrak='$id_k'");
    $d_peg = mysqli_fetch_assoc($q_peg);
?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h6 class="mb-0 fw-bold">Form Penilaian: <?= ucfirst($level_login) ?></h6>
                </div>
                <div class="card-body">
                    <div class="alert alert-light border mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <small class="text-muted d-block">Nama PJLP</small>
                                <strong><?= $d_peg['nama_lengkap'] ?></strong>
                            </div>
                            <div class="col-md-6 text-end">
                                <small class="text-muted d-block">Periode Penilaian</small>
                                <strong><?= $bulan_indo[$f_bulan] ?> <?= $f_tahun ?></strong>
                            </div>
                        </div>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="id_kontrak" value="<?= $id_k ?>">
                        <table class="table table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Kriteria Penilaian</th>
                                    <th width="15%" class="text-center">Bobot</th>
                                    <th width="25%" class="text-center">Nilai (0-100)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $q_krit = mysqli_query($koneksi, "SELECT * FROM tbl_kriteria_penilaian ORDER BY nama_kriteria ASC");
                                while($kr = mysqli_fetch_assoc($q_krit)){
                                    // Cek apakah sudah ada nilai sebelumnya (untuk ditampilkan saat edit)
                                    $val_lama = '';
                                    
                                    // Cari Header ID dulu
                                    $q_ex_h = mysqli_query($koneksi, "SELECT id_penilaian FROM tbl_penilaian_header WHERE id_kontrak='$id_k' AND bulan='$f_bulan' AND tahun='$f_tahun'");
                                    if(mysqli_num_rows($q_ex_h) > 0){
                                        $d_ex_h = mysqli_fetch_assoc($q_ex_h);
                                        $id_pen_h = $d_ex_h['id_penilaian'];
                                        
                                        // Cari Detail Nilai user ini
                                        $q_ex_d = mysqli_query($koneksi, "SELECT nilai_input FROM tbl_penilaian_detail WHERE id_penilaian='$id_pen_h' AND id_kriteria='{$kr['id_kriteria']}' AND tipe_penilai='$level_login'");
                                        if($row_ex = mysqli_fetch_assoc($q_ex_d)){
                                            $val_lama = $row_ex['nilai_input'];
                                        }
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <span class="fw-bold"><?= $kr['nama_kriteria'] ?></span>
                                    </td>
                                    <td class="text-center"><?= $kr['bobot_persen'] ?>%</td>
                                    <td>
                                        <input type="number" name="nilai_<?= $kr['id_kriteria'] ?>" class="form-control text-center fw-bold" min="0" max="100" value="<?= $val_lama ?>" required placeholder="0">
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        
                        <div class="mt-4 d-flex justify-content-between">
                            <a href="index.php?page=penilaian_kinerja&bulan=<?= $f_bulan ?>&tahun=<?= $f_tahun ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" name="btn_simpan_nilai" class="btn btn-primary px-4">
                                <i class="bi bi-save me-2"></i> Simpan Penilaian
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php else: 
    // ==========================================================================
    // TABEL REKAPITULASI PENILAIAN
    // ==========================================================================
?>
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            
            <div class="mb-3 d-flex gap-3 small text-muted">
                <span><i class="bi bi-info-circle me-1"></i> Bobot Penilaian:</span>
                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary">Admin 30%</span>
                <span class="badge bg-success bg-opacity-10 text-success border border-success">Keuangan 20%</span>
                <span class="badge bg-info bg-opacity-10 text-info border border-info">Pimpinan 50%</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">No</th>
                            <th>Nama PJLP</th>
                            <th>Unit Kerja</th>
                            <th class="text-center">Nilai<br>Admin</th>
                            <th class="text-center">Nilai<br>Keuangan</th>
                            <th class="text-center">Nilai<br>Pimpinan</th>
                            <th class="text-center bg-light border-start border-end">Total Skor</th>
                            <th class="text-center" width="12%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        // Query ambil semua PJLP Aktif + Left Join ke Penilaian Header
                        $query = mysqli_query($koneksi, "
                            SELECT k.id_kontrak, p.nama_lengkap, u.nama_unit_kerja,
                                   h.nilai_akhir, h.id_penilaian
                            FROM tbl_kontrak k
                            JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                            JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                            LEFT JOIN tbl_penilaian_header h ON k.id_kontrak = h.id_kontrak AND h.bulan='$f_bulan' AND h.tahun='$f_tahun'
                            WHERE k.status_kontrak='Aktif'
                            ORDER BY p.nama_lengkap ASC
                        ");

                        while($row = mysqli_fetch_assoc($query)){
                            $id_penilaian = $row['id_penilaian'];
                            
                            // Variables Nilai Default
                            $n_admin    = '-';
                            $n_keuangan = '-';
                            $n_pimpinan = '-';
                            
                            // Jika sudah ada header penilaian, cek detailnya
                            if($id_penilaian){
                                // Cek Rata-rata Admin
                                $q_a = mysqli_query($koneksi, "SELECT AVG(nilai_input) as val FROM tbl_penilaian_detail WHERE id_penilaian='$id_penilaian' AND tipe_penilai='admin'");
                                $d_a = mysqli_fetch_assoc($q_a);
                                if($d_a['val'] !== null) $n_admin = number_format($d_a['val'], 0);

                                // Cek Rata-rata Keuangan
                                $q_k = mysqli_query($koneksi, "SELECT AVG(nilai_input) as val FROM tbl_penilaian_detail WHERE id_penilaian='$id_penilaian' AND tipe_penilai='keuangan'");
                                $d_k = mysqli_fetch_assoc($q_k);
                                if($d_k['val'] !== null) $n_keuangan = number_format($d_k['val'], 0);

                                // Cek Rata-rata Pimpinan
                                $q_p = mysqli_query($koneksi, "SELECT AVG(nilai_input) as val FROM tbl_penilaian_detail WHERE id_penilaian='$id_penilaian' AND tipe_penilai='pimpinan'");
                                $d_p = mysqli_fetch_assoc($q_p);
                                if($d_p['val'] !== null) $n_pimpinan = number_format($d_p['val'], 0);
                            }
                            
                            // Cek apakah USER YANG LOGIN saat ini sudah menilai?
                            $sudah_menilai = false;
                            if($level_login == 'admin' && $n_admin != '-') $sudah_menilai = true;
                            if($level_login == 'keuangan' && $n_keuangan != '-') $sudah_menilai = true;
                            if($level_login == 'pimpinan' && $n_pimpinan != '-') $sudah_menilai = true;
                        ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <span class="fw-bold"><?= $row['nama_lengkap'] ?></span>
                            </td>
                            <td><small class="text-muted"><?= $row['nama_unit_kerja'] ?></small></td>
                            
                            <td class="text-center">
                                <?php if($n_admin != '-'): ?>
                                    <span class="badge bg-primary bg-opacity-10 text-primary border border-primary"><?= $n_admin ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>

                            <td class="text-center">
                                <?php if($n_keuangan != '-'): ?>
                                    <span class="badge bg-success bg-opacity-10 text-success border border-success"><?= $n_keuangan ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>

                            <td class="text-center">
                                <?php if($n_pimpinan != '-'): ?>
                                    <span class="badge bg-info bg-opacity-10 text-info border border-info"><?= $n_pimpinan ?></span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>

                            <td class="text-center bg-light border-start border-end">
                                <?php 
                                    $final = $row['nilai_akhir'];
                                    if($final > 0) {
                                        $color = ($final >= 90) ? 'text-success' : (($final >= 75) ? 'text-primary' : 'text-danger');
                                        echo "<span class='fw-bold fs-6 $color'>".number_format($final, 2)."</span>";
                                    } else {
                                        echo "-";
                                    }
                                ?>
                            </td>

                            <td class="text-center">
                                <a href="index.php?page=penilaian_kinerja&act=nilai&id_kontrak=<?= $row['id_kontrak'] ?>&bulan=<?= $f_bulan ?>&tahun=<?= $f_tahun ?>" 
                                   class="btn btn-sm <?= $sudah_menilai ? 'btn-outline-warning' : 'btn-primary' ?> w-100">
                                    <i class="bi <?= $sudah_menilai ? 'bi-pencil-square' : 'bi-plus-lg' ?>"></i> 
                                    <?= $sudah_menilai ? 'Edit Nilai' : 'Nilai' ?>
                                </a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>