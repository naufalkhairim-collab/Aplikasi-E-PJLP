<?php
// 1. CEK LOGIN
if (!isset($_SESSION['status_login'])) {
    echo "<script>window.location.href='login.php';</script>";
    exit();
}

// 2. CONFIG & FILTER DEFAULTS
$jenis_laporan = isset($_GET['jenis']) ? $_GET['jenis'] : '1';
$id_unit_kerja = isset($_GET['unit']) ? $_GET['unit'] : 'all';
$bulan         = isset($_GET['bulan']) ? $_GET['bulan'] : date('n');
$tahun         = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
$tanggal       = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');

// DAFTAR 14 LAPORAN (Tanpa Nomor & Group)
$list_laporan = [
    '1'  => 'Data Induk PJLP',
    '2'  => 'Kontrak PJLP Aktif',
    '3'  => 'Peringatan Kontrak Berakhir',
    '4'  => 'Rekapitulasi Absensi Bulanan',
    '5'  => 'Detail Absensi Harian',
    '6'  => 'Rekapitulasi Pengajuan Cuti/Izin',
    '7'  => 'Penilaian Kinerja',
    '8'  => 'Monitoring Penugasan',
    '9'  => 'Daftar Gaji Nominatif', 
    '11' => 'Realisasi Anggaran',
    '12' => 'Rekapitulasi Potongan Gaji'
];

$judul_terpilih = isset($list_laporan[$jenis_laporan]) ? $list_laporan[$jenis_laporan] : 'Laporan';
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Pusat Laporan & Cetak Dokumen</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Laporan</li>
            </ol>
        </nav>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white py-3">
        <h6 class="card-title mb-0 fw-bold text-primary"><i class="bi bi-funnel-fill me-2"></i>Filter Laporan</h6>
    </div>
    <div class="card-body">
        
        <div class="alert alert-info border-0 d-flex align-items-center mb-4" role="alert">
            <i class="bi bi-info-circle-fill fs-4 me-3"></i>
            <div>
                <strong id="caption_judul">Pilih Laporan</strong>
                <div class="small" id="caption_desc">Silakan pilih jenis laporan dan filter yang sesuai.</div>
            </div>
        </div>

        <form action="" method="GET">
            <input type="hidden" name="page" value="laporan">
            
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label small fw-bold text-muted">Jenis Laporan</label>
                    <select name="jenis" id="jenis_laporan" class="form-select" onchange="aturFilter()">
                        <?php foreach($list_laporan as $key => $val): ?>
                            <option value="<?= $key ?>" <?= $jenis_laporan == $key ? 'selected' : '' ?>><?= $val ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-bold text-muted">Unit Kerja</label>
                    <select name="unit" class="form-select">
                        <option value="all">Semua Unit Kerja</option>
                        <?php
                        $q_u = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                        while($u = mysqli_fetch_assoc($q_u)){
                            $sel = ($id_unit_kerja == $u['id_unit_kerja']) ? 'selected' : '';
                            echo "<option value='{$u['id_unit_kerja']}' $sel>{$u['nama_unit_kerja']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="col-md-3" id="group_bulan">
                    <label class="form-label small fw-bold text-muted">Periode</label>
                    <div class="input-group">
                        <select name="bulan" class="form-select">
                            <?php 
                            $nm_bln = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
                            foreach($nm_bln as $k=>$v){
                                $sel = ($bulan == $k) ? 'selected' : '';
                                echo "<option value='$k' $sel>$v</option>";
                            }
                            ?>
                        </select>
                        <select name="tahun" class="form-select">
                            <?php for($i=date('Y'); $i>=2024; $i--): ?>
                                <option value="<?= $i ?>" <?= $tahun==$i?'selected':'' ?>><?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3 d-none" id="group_tanggal">
                    <label class="form-label small fw-bold text-muted">Pilih Tanggal</label>
                    <input type="date" name="tanggal" class="form-control" value="<?= $tanggal ?>">
                </div>

                <div class="col-md-2">
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary" title="Tampilkan Preview">
                            <i class="bi bi-search me-1"></i> Tampilkan
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
        <h6 class="card-title mb-0 fw-bold">Preview: <?= $judul_terpilih ?></h6>
        
        <div class="d-flex gap-2">
            <a href="index.php?page=laporan" class="btn btn-light border btn-sm" title="Reset Filter">
                <i class="bi bi-arrow-counterclockwise"></i> Reset
            </a>
            <a href="cetak_laporan.php?jenis=<?= $jenis_laporan ?>&unit=<?= $id_unit_kerja ?>&bulan=<?= $bulan ?>&tahun=<?= $tahun ?>&tanggal=<?= $tanggal ?>" target="_blank" class="btn btn-danger btn-sm">
                <i class="bi bi-file-earmark-pdf-fill me-2"></i>Cetak PDF
            </a>
        </div>
    </div>
    
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle mb-0" style="font-size: 0.9rem;">
                <thead class="table-light">
                    <tr>
                        <th class="text-center" width="5%">No</th>
                        
                        <?php if (in_array($jenis_laporan, ['1','2','3','13'])): ?>
                            <th>Nama Lengkap</th>
                            <th>NIK / NIB</th>
                            <th>Unit Kerja</th>
                            <th>Kontrak (Mulai - Selesai)</th>
                            <th>Status</th>

                        <?php elseif ($jenis_laporan == '4'): ?>
                            <th>Nama Pegawai</th>
                            <th class="text-center">Hadir</th>
                            <th class="text-center">Sakit</th>
                            <th class="text-center">Izin</th>
                            <th class="text-center">Alpa</th>
                            <th class="text-center">Terlambat</th>

                        <?php elseif ($jenis_laporan == '5'): ?>
                            <th>Nama Pegawai</th>
                            <th>Jam Masuk</th>
                            <th>Jam Pulang</th>
                            <th>Status Masuk</th>
                            <th>Status Kehadiran</th>

                        <?php elseif ($jenis_laporan == '6'): ?>
                            <th>Nama Pegawai</th>
                            <th>Jenis Cuti</th>
                            <th>Periode</th>
                            <th>Status</th>

                        <?php elseif ($jenis_laporan == '7'): ?>
                            <th>Nama Pegawai</th>
                            <th>Unit Kerja</th>
                            <th class="text-center">Nilai Admin (30%)</th>
                            <th class="text-center">Nilai Keuangan (20%)</th>
                            <th class="text-center">Nilai Pimpinan (50%)</th>
                            <th class="text-center">Total Skor</th>
                            <th class="text-center">Predikat</th>

                        <?php elseif ($jenis_laporan == '8' || $jenis_laporan == '14'): ?>
                            <th>Nama Pegawai</th>
                            <th>Judul Tugas</th>
                            <th>Deadline</th>
                            <th>Status</th>

                        <?php elseif (in_array($jenis_laporan, ['9','10','12'])): ?>
                            <th>Nama Pegawai</th>
                            <th>Gaji Pokok</th>
                            <th>Tunjangan</th>
                            <th>Potongan</th>
                            <th>Total Diterima</th>

                        <?php elseif ($jenis_laporan == '11'): ?>
                            <th>Kode Rekening</th>
                            <th>Nama Rekening</th>
                            <th>Pagu Anggaran</th>
                            <th>Realisasi</th>
                            <th>Sisa</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // --- QUERY BUILDER ---
                    $where_unit = ($id_unit_kerja != 'all') ? "AND k.id_unit_kerja = '$id_unit_kerja'" : "";
                    
                    // Khusus Laporan Anggaran (No 11) join-nya beda
                    $where_unit_dpa = ($id_unit_kerja != 'all') ? "AND d.id_unit_kerja = '$id_unit_kerja'" : "";

                    $query = "";

                    // A. KELOMPOK DATA PEGAWAI (1,2,3,13)
                    if (in_array($jenis_laporan, ['1','2','3','13'])) {
                        $query = "SELECT p.*, k.tgl_mulai_kontrak, k.tgl_selesai_kontrak, k.status_kontrak, u.nama_unit_kerja 
                                  FROM tbl_pjlp p 
                                  LEFT JOIN tbl_kontrak k ON p.id_pjlp = k.id_pjlp AND k.status_kontrak='Aktif'
                                  LEFT JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                  WHERE 1=1 $where_unit ORDER BY p.nama_lengkap ASC";
                    } 
                    // B. REKAP ABSENSI BULANAN (4)
                    elseif ($jenis_laporan == '4') {
                        $query = "SELECT p.nama_lengkap, u.nama_unit_kerja,
                                  SUM(CASE WHEN a.status_kehadiran='Hadir' THEN 1 ELSE 0 END) as hadir,
                                  SUM(CASE WHEN a.status_kehadiran='Sakit' THEN 1 ELSE 0 END) as sakit,
                                  SUM(CASE WHEN a.status_kehadiran='Izin' THEN 1 ELSE 0 END) as izin,
                                  SUM(CASE WHEN a.status_kehadiran='Alpa' THEN 1 ELSE 0 END) as alpa,
                                  SUM(CASE WHEN a.status_masuk='Terlambat' THEN 1 ELSE 0 END) as telat
                                  FROM tbl_pjlp p
                                  JOIN tbl_kontrak k ON p.id_pjlp = k.id_pjlp
                                  JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                  LEFT JOIN tbl_absensi a ON k.id_kontrak = a.id_kontrak 
                                       AND MONTH(a.tanggal) = '$bulan' AND YEAR(a.tanggal) = '$tahun'
                                  WHERE k.status_kontrak='Aktif' $where_unit
                                  GROUP BY p.id_pjlp ORDER BY p.nama_lengkap ASC";
                    }
                    // C. DETAIL ABSENSI HARIAN (5)
                    elseif ($jenis_laporan == '5') {
                        $query = "SELECT p.nama_lengkap, u.nama_unit_kerja, a.jam_masuk, a.jam_pulang, a.status_kehadiran, a.status_masuk
                                  FROM tbl_pjlp p
                                  JOIN tbl_kontrak k ON p.id_pjlp = k.id_pjlp
                                  JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                  LEFT JOIN tbl_absensi a ON k.id_kontrak = a.id_kontrak AND a.tanggal = '$tanggal'
                                  WHERE k.status_kontrak='Aktif' $where_unit
                                  ORDER BY p.nama_lengkap ASC";
                    }
                    // D. CUTI (6)
                    elseif ($jenis_laporan == '6') {
                        $query = "SELECT p.nama_lengkap, u.nama_unit_kerja, c.*, mc.nama_cuti 
                                  FROM tbl_pengajuan_cuti c
                                  JOIN tbl_pjlp p ON c.id_pjlp = p.id_pjlp
                                  JOIN tbl_kontrak k ON p.id_pjlp = k.id_pjlp AND k.status_kontrak='Aktif'
                                  JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                  JOIN tbl_master_cuti mc ON c.id_master_cuti = mc.id_master_cuti
                                  WHERE MONTH(c.tgl_mulai) = '$bulan' AND YEAR(c.tgl_mulai) = '$tahun' $where_unit
                                  ORDER BY c.tgl_diajukan DESC";
                    }
                    elseif ($jenis_laporan == '7') {
                        // Query Updated: Penilaian 360 Derajat
                        $query = "SELECT 
                                    p.nama_lengkap, 
                                    p.nik,
                                    u.nama_unit_kerja,
                                    h.nilai_akhir,
                                    h.id_penilaian,
                                    -- Subquery Nilai Per Aktor
                                    (SELECT COALESCE(AVG(nilai_input), 0) FROM tbl_penilaian_detail WHERE id_penilaian = h.id_penilaian AND tipe_penilai = 'admin') as nilai_admin,
                                    (SELECT COALESCE(AVG(nilai_input), 0) FROM tbl_penilaian_detail WHERE id_penilaian = h.id_penilaian AND tipe_penilai = 'keuangan') as nilai_keuangan,
                                    (SELECT COALESCE(AVG(nilai_input), 0) FROM tbl_penilaian_detail WHERE id_penilaian = h.id_penilaian AND tipe_penilai = 'pimpinan') as nilai_pimpinan
                                FROM tbl_penilaian_header h
                                JOIN tbl_kontrak k ON h.id_kontrak = k.id_kontrak
                                JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                WHERE h.bulan = '$bulan' AND h.tahun = '$tahun' $where_unit
                                ORDER BY h.nilai_akhir DESC, p.nama_lengkap ASC";
                    }
                    // F. TUGAS (8, 14)
                    elseif ($jenis_laporan == '8' || $jenis_laporan == '14') {
                        $query = "SELECT p.nama_lengkap, t.* FROM tbl_tugas t
                                  JOIN tbl_pjlp p ON t.id_pjlp_penerima = p.id_pjlp
                                  JOIN tbl_kontrak k ON p.id_pjlp = k.id_pjlp AND k.status_kontrak='Aktif'
                                  WHERE MONTH(t.tgl_beri) = '$bulan' AND YEAR(t.tgl_beri) = '$tahun' $where_unit
                                  ORDER BY t.tgl_beri DESC";
                    }
                    // G. GAJI (9, 10, 12)
                    elseif (in_array($jenis_laporan, ['9','10','12'])) {
                        $query = "SELECT p.nama_lengkap, py.*, u.nama_unit_kerja 
                                  FROM tbl_payroll py
                                  JOIN tbl_kontrak k ON py.id_kontrak = k.id_kontrak
                                  JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                  JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                  WHERE py.bulan = '$bulan' AND py.tahun = '$tahun' $where_unit
                                  ORDER BY p.nama_lengkap ASC";
                    }
                    // H. REALISASI ANGGARAN (11)
                    elseif ($jenis_laporan == '11') {
                        $query = "SELECT r.kode_rekening, r.nama_rekening, dd.pagu_anggaran_rekening, 
                                  (SELECT SUM(py.gaji_diterima) FROM tbl_payroll py WHERE py.id_dpa_detail = dd.id_dpa_detail AND py.status_bayar='Lunas') as realisasi
                                  FROM tbl_dpa_detail dd
                                  JOIN tbl_dpa d ON dd.id_dpa = d.id_dpa
                                  JOIN tbl_master_rekening r ON dd.id_rekening = r.id_rekening
                                  WHERE d.tahun_anggaran = '$tahun' $where_unit_dpa";
                    }
                    
                    // --- EKSEKUSI & TAMPILKAN ---
                    if($query) {
                        $run = mysqli_query($koneksi, $query);
                        $no = 1;
                        if($run && mysqli_num_rows($run) > 0) {
                            while($row = mysqli_fetch_assoc($run)) {
                                echo "<tr>";
                                echo "<td class='text-center'>{$no}</td>";
                                
                                // RENDER KOLOM SESUAI JENIS
                                if (in_array($jenis_laporan, ['1','2','3','13'])) {
                                    echo "<td><b>{$row['nama_lengkap']}</b></td>";
                                    echo "<td>{$row['nik']} / {$row['nib_nomor']}</td>";
                                    echo "<td>{$row['nama_unit_kerja']}</td>";
                                    $kontrak = ($row['tgl_mulai_kontrak']) ? date('d/m/Y', strtotime($row['tgl_mulai_kontrak'])) . " - " . date('d/m/Y', strtotime($row['tgl_selesai_kontrak'])) : "-";
                                    echo "<td>$kontrak</td>";
                                    echo "<td>{$row['status_pjlp']}</td>";
                                } 
                                elseif ($jenis_laporan == '4') {
                                    echo "<td>{$row['nama_lengkap']}</td>";
                                    echo "<td class='text-center'>{$row['hadir']}</td>";
                                    echo "<td class='text-center'>{$row['sakit']}</td>";
                                    echo "<td class='text-center'>{$row['izin']}</td>";
                                    echo "<td class='text-center text-danger'>{$row['alpa']}</td>";
                                    echo "<td class='text-center text-warning'>{$row['telat']}</td>";
                                }
                                elseif ($jenis_laporan == '5') {
                                    echo "<td>{$row['nama_lengkap']}</td>";
                                    echo "<td>".($row['jam_masuk']?:'-')."</td>";
                                    echo "<td>".($row['jam_pulang']?:'-')."</td>";
                                    echo "<td>{$row['status_masuk']}</td>";
                                    echo "<td><span class='badge bg-".($row['status_kehadiran']=='Hadir'?'success':'danger')."'>{$row['status_kehadiran']}</span></td>";
                                }
                                elseif ($jenis_laporan == '6') {
                                    echo "<td>{$row['nama_lengkap']}</td>";
                                    echo "<td>{$row['nama_cuti']}</td>";
                                    echo "<td>".date('d/m', strtotime($row['tgl_mulai']))." - ".date('d/m', strtotime($row['tgl_selesai']))."</td>";
                                    echo "<td>{$row['status_pengajuan']}</td>";
                                }
                                elseif ($jenis_laporan == '7') {
                                    // Logika Predikat
                                    $skor = $row['nilai_akhir'];
                                    if ($skor >= 90) { $predikat = "Sangat Baik"; $bg="success"; }
                                    elseif ($skor >= 75) { $predikat = "Baik"; $bg="primary"; }
                                    elseif ($skor >= 60) { $predikat = "Cukup"; $bg="warning"; }
                                    else { $predikat = "Kurang"; $bg="danger"; }

                                    echo "<td>
                                            <b>{$row['nama_lengkap']}</b><br>
                                            <small class='text-muted'>{$row['nik']}</small>
                                          </td>";
                                    echo "<td>{$row['nama_unit_kerja']}</td>";
                                    echo "<td class='text-center'>".number_format($row['nilai_admin'], 1)."</td>";
                                    echo "<td class='text-center'>".number_format($row['nilai_keuangan'], 1)."</td>";
                                    echo "<td class='text-center'>".number_format($row['nilai_pimpinan'], 1)."</td>";
                                    echo "<td class='text-center fw-bold'>".number_format($row['nilai_akhir'], 2)."</td>";
                                    echo "<td class='text-center'><span class='badge bg-{$bg}'>{$predikat}</span></td>";
                                }
                                elseif ($jenis_laporan == '8' || $jenis_laporan == '14') {
                                    echo "<td>{$row['nama_lengkap']}</td>";
                                    echo "<td>{$row['judul_tugas']}</td>";
                                    echo "<td>".($row['deadline'] ? date('d-m-Y H:i', strtotime($row['deadline'])) : '-')."</td>";
                                    echo "<td>{$row['status_tugas']}</td>";
                                }
                                elseif (in_array($jenis_laporan, ['9','10','12'])) {
                                    echo "<td>{$row['nama_lengkap']}</td>";
                                    echo "<td>Rp ".number_format($row['gaji_pokok'],0,',','.')."</td>";
                                    echo "<td>Rp ".number_format($row['total_tunjangan'],0,',','.')."</td>";
                                    echo "<td class='text-danger'>Rp ".number_format($row['total_potongan'],0,',','.')."</td>";
                                    echo "<td class='fw-bold text-success'>Rp ".number_format($row['gaji_diterima'],0,',','.')."</td>";
                                }
                                elseif ($jenis_laporan == '11') {
                                    echo "<td>{$row['kode_rekening']}</td>";
                                    echo "<td>{$row['nama_rekening']}</td>";
                                    echo "<td>Rp ".number_format($row['pagu_anggaran_rekening'],0,',','.')."</td>";
                                    echo "<td>Rp ".number_format($row['realisasi'],0,',','.')."</td>";
                                    echo "<td>Rp ".number_format($row['pagu_anggaran_rekening'] - $row['realisasi'],0,',','.')."</td>";
                                }

                                echo "</tr>";
                                $no++;
                            }
                        } else {
                            echo "<tr><td colspan='10' class='text-center py-4 text-muted'>Data tidak ditemukan untuk filter yang dipilih.</td></tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // DATA DESKRIPSI UNTUK CAPTION
    const captions = {
        '1': 'Menampilkan daftar seluruh data pegawai PJLP beserta status kepegawaiannya.',
        '2': 'Menampilkan daftar kontrak kerja yang masih aktif pada tahun berjalan.',
        '3': 'Menampilkan kontrak yang akan segera berakhir dalam waktu dekat.',
        '4': 'Rekapitulasi kehadiran (Hadir, Sakit, Izin, Alpa) per bulan.',
        '5': 'Detail jam masuk dan pulang pegawai pada tanggal tertentu.',
        '6': 'Daftar pengajuan cuti dan izin beserta status persetujuannya.',
        '7': 'Hasil penilaian kinerja pegawai oleh pimpinan pada periode tertentu.',
        '8': 'Monitoring status penyelesaian tugas yang diberikan.',
        '9': 'Daftar rekapitulasi pembayaran gaji bersih (payroll) per bulan.',
        '10': 'Cetak slip gaji rinci untuk arsip atau dibagikan ke pegawai.',
        '11': 'Realisasi penyerapan anggaran DPA per kode rekening.',
        '12': 'Rincian potongan gaji (BPJS, PPh, dll) per pegawai.',
        '13': 'Cetak Surat Keputusan (SK) Perpanjangan Kontrak Kerja.',
        '14': 'Cetak Surat Perintah Tugas (SPT) untuk penugasan resmi.'
    };

    function aturFilter() {
        var jenis = document.getElementById('jenis_laporan').value;
        var groupBulan = document.getElementById('group_bulan');
        var groupTanggal = document.getElementById('group_tanggal');
        
        // Update Caption
        document.getElementById('caption_judul').innerText = document.getElementById('jenis_laporan').options[document.getElementById('jenis_laporan').selectedIndex].text;
        document.getElementById('caption_desc').innerText = captions[jenis] || 'Silakan pilih filter.';

        // Laporan Harian (5) butuh Tanggal
        if (jenis === '5') { 
            groupBulan.classList.add('d-none');
            groupTanggal.classList.remove('d-none');
        } 
        // Laporan Master (1, 2, 3, 13) biasanya tidak butuh bulan/tanggal
        else if (['1','2','3','13'].includes(jenis)) {
            groupBulan.classList.remove('d-none'); // Tampilkan tahun saja (bulan opsional/diabaikan di query)
            groupTanggal.classList.add('d-none');
        }
        // Sisanya Bulanan
        else {
            groupBulan.classList.remove('d-none');
            groupTanggal.classList.add('d-none');
        }
    }
    
    // Run on load
    document.addEventListener("DOMContentLoaded", function() {
        aturFilter();
    });
</script>