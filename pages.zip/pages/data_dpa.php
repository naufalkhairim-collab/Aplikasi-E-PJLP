<?php
// 1. Keamanan: Hanya Admin & Keuangan
if (!in_array($_SESSION['level'], ['admin', 'keuangan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- SIMPAN DATA ---
if (isset($_POST['btn_simpan'])) {
    $id_unit    = amankan_input($_POST['id_unit_kerja']);
    $tahun      = amankan_input($_POST['tahun_anggaran']);
    $nomor      = amankan_input($_POST['nomor_dpa']);
    $tanggal    = amankan_input($_POST['tgl_dpa']);
    
    // Hitung Total dari Detail
    $total_anggaran = 0;
    if (isset($_POST['id_rekening'])) {
        foreach ($_POST['pagu'] as $nominal) {
            $total_anggaran += (int)$nominal;
        }
    }

    // 1. Insert Header DPA
    $query_header = "INSERT INTO tbl_dpa (id_unit_kerja, tahun_anggaran, nomor_dpa, tgl_dpa, total_anggaran_dpa) 
                     VALUES ('$id_unit', '$tahun', '$nomor', '$tanggal', '$total_anggaran')";

    if (mysqli_query($koneksi, $query_header)) {
        $id_dpa_baru = mysqli_insert_id($koneksi);

        // 2. Insert Detail Rekening
        if (isset($_POST['id_rekening'])) {
            $count = count($_POST['id_rekening']);
            for ($i = 0; $i < $count; $i++) {
                $id_rek = $_POST['id_rekening'][$i];
                $pagu   = $_POST['pagu'][$i];
                
                if ($id_rek != "" && $pagu > 0) {
                    mysqli_query($koneksi, "INSERT INTO tbl_dpa_detail (id_dpa, id_rekening, pagu_anggaran_rekening) VALUES ('$id_dpa_baru', '$id_rek', '$pagu')");
                }
            }
        }

        set_notifikasi('success', 'Berhasil', 'Data DPA dan Anggaran berhasil disimpan');
        echo "<script>window.location.href='index.php?page=data_dpa';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_dpa     = amankan_input($_POST['id_dpa']);
    $id_unit    = amankan_input($_POST['id_unit_kerja']);
    $tahun      = amankan_input($_POST['tahun_anggaran']);
    $nomor      = amankan_input($_POST['nomor_dpa']);
    $tanggal    = amankan_input($_POST['tgl_dpa']);

    // Hitung Total Baru
    $total_anggaran = 0;
    if (isset($_POST['id_rekening'])) {
        foreach ($_POST['pagu'] as $nominal) {
            $total_anggaran += (int)$nominal;
        }
    }

    // 1. Update Header
    $query_update = "UPDATE tbl_dpa SET 
                     id_unit_kerja='$id_unit', tahun_anggaran='$tahun', nomor_dpa='$nomor', tgl_dpa='$tanggal', total_anggaran_dpa='$total_anggaran' 
                     WHERE id_dpa='$id_dpa'";

    if (mysqli_query($koneksi, $query_update)) {
        // 2. Reset Detail (Hapus semua detail lama, insert yang baru)
        // Note: Ini cara termudah. Jika detail sudah dipakai di kontrak, harus hati-hati. 
        // Idealnya cek dulu, tapi untuk simplifikasi kita hapus & insert ulang.
        mysqli_query($koneksi, "DELETE FROM tbl_dpa_detail WHERE id_dpa='$id_dpa'");

        if (isset($_POST['id_rekening'])) {
            $count = count($_POST['id_rekening']);
            for ($i = 0; $i < $count; $i++) {
                $id_rek = $_POST['id_rekening'][$i];
                $pagu   = $_POST['pagu'][$i];
                
                if ($id_rek != "" && $pagu > 0) {
                    mysqli_query($koneksi, "INSERT INTO tbl_dpa_detail (id_dpa, id_rekening, pagu_anggaran_rekening) VALUES ('$id_dpa', '$id_rek', '$pagu')");
                }
            }
        }

        set_notifikasi('success', 'Berhasil', 'Data DPA diperbarui');
        echo "<script>window.location.href='index.php?page=data_dpa';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    // Cek Relasi dengan Tabel Kontrak (Lewat tbl_dpa_detail)
    // Kita harus mencari id_dpa_detail milik id_dpa ini
    $cek_kontrak = mysqli_query($koneksi, "
        SELECT k.id_kontrak 
        FROM tbl_kontrak k
        JOIN tbl_dpa_detail dd ON k.id_dpa_detail = dd.id_dpa_detail
        WHERE dd.id_dpa = '$id'
    ");
    
    if (mysqli_num_rows($cek_kontrak) > 0) {
        set_notifikasi('error', 'Gagal Hapus', 'DPA ini sudah digunakan dalam Kontrak Kerja pegawai. Hapus kontrak terkait terlebih dahulu.');
        echo "<script>window.location.href='index.php?page=data_dpa';</script>";
        exit();
    }

    // Detail akan terhapus otomatis jika cascade, atau hapus manual:
    mysqli_query($koneksi, "DELETE FROM tbl_dpa_detail WHERE id_dpa='$id'");
    
    $query = "DELETE FROM tbl_dpa WHERE id_dpa='$id'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Data DPA berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem');
    }
    echo "<script>window.location.href='index.php?page=data_dpa';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen DPA & Anggaran</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data DPA</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH (DINAMIS)
    // ==========================================================================
    case 'tambah':
        // Siapkan opsi rekening untuk JS
        $opsi_rekening = "";
        $q_rek = mysqli_query($koneksi, "SELECT * FROM tbl_master_rekening ORDER BY kode_rekening ASC");
        while($r = mysqli_fetch_assoc($q_rek)){
            $opsi_rekening .= "<option value='{$r['id_rekening']}'>{$r['kode_rekening']} - {$r['nama_rekening']}</option>";
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Input DPA Baru</h5>
                    <a href="index.php?page=data_dpa" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <h6 class="mb-3 text-primary fw-bold">1. Informasi Umum DPA</h6>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Unit Kerja <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <select name="id_unit_kerja" class="form-select" required>
                                    <option value="" disabled selected>-- Pilih Unit --</option>
                                    <?php
                                    $q_unit = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                                    while ($u = mysqli_fetch_assoc($q_unit)) {
                                        echo "<option value='{$u['id_unit_kerja']}'>{$u['nama_unit_kerja']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nomor DPA <span class="text-danger">*</span></label>
                            <div class="col-sm-5">
                                <input type="text" name="nomor_dpa" class="form-control" required placeholder="No. DPA / Dokumen">
                            </div>
                            <div class="col-sm-4">
                                <input type="number" name="tahun_anggaran" class="form-control" value="<?= date('Y') ?>" required placeholder="Tahun">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tanggal Sah</label>
                            <div class="col-sm-5">
                                <input type="date" name="tgl_dpa" class="form-control" required>
                            </div>
                        </div>

                        <hr class="my-4 border-dashed">
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="text-primary fw-bold mb-0">2. Rincian Rekening Belanja</h6>
                            <button type="button" class="btn btn-sm btn-success" onclick="tambahBaris()">
                                <i class="bi bi-plus-lg me-1"></i> Tambah Rekening
                            </button>
                        </div>

                        <div id="container-rekening">
                            <div class="row mb-2 baris-rekening">
                                <div class="col-md-7">
                                    <select name="id_rekening[]" class="form-select" required>
                                        <option value="" disabled selected>-- Pilih Kode Rekening --</option>
                                        <?= $opsi_rekening ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" name="pagu[]" class="form-control input-pagu" placeholder="Pagu Anggaran" required min="0" oninput="hitungTotal()">
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger w-100" onclick="hapusBaris(this)"><i class="bi bi-trash"></i></button>
                                </div>
                            </div>
                        </div>

                        <hr class="my-3">

                        <div class="row justify-content-end">
                            <div class="col-md-5">
                                <div class="d-flex justify-content-between align-items-center fw-bold fs-16">
                                    <span>Total Anggaran:</span>
                                    <span class="text-primary" id="label-total">Rp 0</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12 text-end">
                                <button type="reset" class="btn btn-light me-2">Reset</button>
                                <button type="submit" name="btn_simpan" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i> Simpan DPA</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        // Ambil Header
        $q_header = mysqli_query($koneksi, "SELECT * FROM tbl_dpa WHERE id_dpa='$id'");
        $d = mysqli_fetch_assoc($q_header);
        
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_dpa';</script>";
            exit();
        }

        // Siapkan opsi rekening untuk JS
        $opsi_rekening = "";
        $q_rek = mysqli_query($koneksi, "SELECT * FROM tbl_master_rekening ORDER BY kode_rekening ASC");
        while($r = mysqli_fetch_assoc($q_rek)){
            $opsi_rekening .= "<option value='{$r['id_rekening']}'>{$r['kode_rekening']} - {$r['nama_rekening']}</option>";
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Data DPA</h5>
                    <a href="index.php?page=data_dpa" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_dpa" value="<?= $d['id_dpa'] ?>">
                        
                        <h6 class="mb-3 text-primary fw-bold">1. Informasi Umum DPA</h6>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Unit Kerja</label>
                            <div class="col-sm-9">
                                <select name="id_unit_kerja" class="form-select" required>
                                    <?php
                                    $q_unit = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                                    while ($u = mysqli_fetch_assoc($q_unit)) {
                                        $sel = ($u['id_unit_kerja'] == $d['id_unit_kerja']) ? 'selected' : '';
                                        echo "<option value='{$u['id_unit_kerja']}' $sel>{$u['nama_unit_kerja']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nomor DPA</label>
                            <div class="col-sm-5">
                                <input type="text" name="nomor_dpa" class="form-control" value="<?= $d['nomor_dpa'] ?>" required>
                            </div>
                            <div class="col-sm-4">
                                <input type="number" name="tahun_anggaran" class="form-control" value="<?= $d['tahun_anggaran'] ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Tanggal Sah</label>
                            <div class="col-sm-5">
                                <input type="date" name="tgl_dpa" class="form-control" value="<?= $d['tgl_dpa'] ?>" required>
                            </div>
                        </div>

                        <hr class="my-4 border-dashed">
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 class="text-primary fw-bold mb-0">2. Rincian Rekening Belanja</h6>
                            <button type="button" class="btn btn-sm btn-success" onclick="tambahBaris()">
                                <i class="bi bi-plus-lg me-1"></i> Tambah Rekening
                            </button>
                        </div>

                        <div id="container-rekening">
                            <?php
                            // Ambil Detail Lama
                            $q_detail = mysqli_query($koneksi, "SELECT * FROM tbl_dpa_detail WHERE id_dpa='$id'");
                            while($det = mysqli_fetch_assoc($q_detail)):
                            ?>
                            <div class="row mb-2 baris-rekening">
                                <div class="col-md-7">
                                    <select name="id_rekening[]" class="form-select" required>
                                        <option value="" disabled>-- Pilih Kode Rekening --</option>
                                        <?php
                                        // Reset pointer result query master rekening
                                        mysqli_data_seek($q_rek, 0); 
                                        while($r = mysqli_fetch_assoc($q_rek)){
                                            $sel = ($r['id_rekening'] == $det['id_rekening']) ? 'selected' : '';
                                            echo "<option value='{$r['id_rekening']}' $sel>{$r['kode_rekening']} - {$r['nama_rekening']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <span class="input-group-text">Rp</span>
                                        <input type="number" name="pagu[]" class="form-control input-pagu" value="<?= $det['pagu_anggaran_rekening'] ?>" required min="0" oninput="hitungTotal()">
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <button type="button" class="btn btn-danger w-100" onclick="hapusBaris(this)"><i class="bi bi-trash"></i></button>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>

                        <hr class="my-3">

                        <div class="row justify-content-end">
                            <div class="col-md-5">
                                <div class="d-flex justify-content-between align-items-center fw-bold fs-16">
                                    <span>Total Anggaran:</span>
                                    <span class="text-primary" id="label-total">Rp <?= number_format($d['total_anggaran_dpa'], 0, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12 text-end">
                                <button type="submit" name="btn_update" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA DPA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Dokumen Pelaksanaan Anggaran (DPA)</h5>
                    <a href="index.php?page=data_dpa&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Input DPA
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nomor DPA</th>
                                    <th>Unit Kerja</th>
                                    <th>Tahun</th>
                                    <th>Total Pagu Anggaran</th>
                                    <th>Tanggal Sah</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "
                                    SELECT d.*, u.nama_unit_kerja 
                                    FROM tbl_dpa d
                                    JOIN tbl_unit_kerja u ON d.id_unit_kerja = u.id_unit_kerja
                                    ORDER BY d.tahun_anggaran DESC, d.id_dpa DESC
                                ");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td class="fw-medium text-primary"><?= $row['nomor_dpa'] ?></td>
                                    <td><?= $row['nama_unit_kerja'] ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= $row['tahun_anggaran'] ?></span></td>
                                    <td class="fw-bold">Rp <?= number_format($row['total_anggaran_dpa'], 0, ',', '.') ?></td>
                                    <td><?= date('d/m/Y', strtotime($row['tgl_dpa'])) ?></td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_dpa&act=edit&id=<?= $row['id_dpa'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit Detail">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=data_dpa&act=hapus&id=<?= $row['id_dpa'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>

<?php if($act == 'tambah' || $act == 'edit'): ?>
<script>
    // Variable string opsi rekening dari PHP
    var optionsRekening = `<?= $opsi_rekening ?>`;

    function tambahBaris() {
        var html = `
        <div class="row mb-2 baris-rekening">
            <div class="col-md-7">
                <select name="id_rekening[]" class="form-select" required>
                    <option value="" disabled selected>-- Pilih Kode Rekening --</option>
                    ${optionsRekening}
                </select>
            </div>
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text">Rp</span>
                    <input type="number" name="pagu[]" class="form-control input-pagu" placeholder="Pagu Anggaran" required min="0" oninput="hitungTotal()">
                </div>
            </div>
            <div class="col-md-1">
                <button type="button" class="btn btn-danger w-100" onclick="hapusBaris(this)"><i class="bi bi-trash"></i></button>
            </div>
        </div>`;
        
        document.getElementById('container-rekening').insertAdjacentHTML('beforeend', html);
    }

    function hapusBaris(btn) {
        var row = btn.closest('.baris-rekening');
        // Pastikan minimal ada 1 baris (opsional)
        var totalRow = document.querySelectorAll('.baris-rekening').length;
        if(totalRow > 1) {
            row.remove();
            hitungTotal();
        } else {
            Swal.fire('Info', 'Minimal harus ada satu rekening belanja.', 'info');
        }
    }

    function hitungTotal() {
        var inputs = document.querySelectorAll('.input-pagu');
        var total = 0;
        
        inputs.forEach(function(input) {
            var val = parseFloat(input.value);
            if (!isNaN(val)) {
                total += val;
            }
        });

        // Format Rupiah
        var formatter = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        });

        document.getElementById('label-total').innerText = formatter.format(total);
    }
    
    // Hitung total saat halaman edit dimuat pertama kali
    document.addEventListener('DOMContentLoaded', function() {
        hitungTotal();
    });
</script>
<?php endif; ?>