<?php
// 1. Keamanan: Hanya PJLP
if ($_SESSION['level'] != 'pjlp') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$id_pjlp = $_SESSION['id_user'];
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN & BATAL)
// ==================================================================================

// --- AJUKAN CUTI ---
if (isset($_POST['btn_ajukan'])) {
    $id_jenis   = amankan_input($_POST['id_master_cuti']);
    $tgl_mulai  = amankan_input($_POST['tgl_mulai']);
    $tgl_selesai= amankan_input($_POST['tgl_selesai']);
    $ket        = amankan_input($_POST['keterangan_pjlp']);
    
    // Hitung Durasi Hari
    $start = new DateTime($tgl_mulai);
    $end   = new DateTime($tgl_selesai);
    $diff  = $start->diff($end);
    $jml_hari = $diff->days + 1; // +1 karena inklusif hari pertama

    // Validasi Tanggal
    if ($tgl_selesai < $tgl_mulai) {
        set_notifikasi('warning', 'Tanggal Invalid', 'Tanggal selesai tidak boleh lebih kecil dari tanggal mulai.');
        echo "<script>history.back();</script>";
        exit();
    }

    // Upload File Pendukung
    $file_name = '';
    if (!empty($_FILES['file_pendukung']['name'])) {
        $ext = pathinfo($_FILES['file_pendukung']['name'], PATHINFO_EXTENSION);
        $file_name = "cuti_" . $id_pjlp . "_" . date('YmdHis') . "." . $ext;
        
        if (!file_exists("assets/uploads/cuti")) mkdir("assets/uploads/cuti", 0777, true);
        move_uploaded_file($_FILES['file_pendukung']['tmp_name'], "assets/uploads/cuti/" . $file_name);
    } else {
        // Cek apakah jenis cuti ini WAJIB file?
        $q_cek = mysqli_query($koneksi, "SELECT memerlukan_file FROM tbl_master_cuti WHERE id_master_cuti='$id_jenis'");
        $d_cek = mysqli_fetch_assoc($q_cek);
        if ($d_cek['memerlukan_file'] == 1) {
            set_notifikasi('warning', 'Wajib Upload', 'Jenis izin ini memerlukan lampiran bukti (misal: Surat Dokter).');
            echo "<script>history.back();</script>";
            exit();
        }
    }

    $tgl_aju = date('Y-m-d H:i:s');

    $query = "INSERT INTO tbl_pengajuan_cuti (id_pjlp, id_master_cuti, tgl_diajukan, tgl_mulai, tgl_selesai, jumlah_hari, keterangan_pjlp, file_pendukung, status_pengajuan) 
              VALUES ('$id_pjlp', '$id_jenis', '$tgl_aju', '$tgl_mulai', '$tgl_selesai', '$jml_hari', '$ket', '$file_name', 'Diajukan')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terkirim', 'Pengajuan Anda berhasil dikirim dan menunggu persetujuan.');
        echo "<script>window.location.href='index.php?page=pengajuan_cuti_pjlp';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem.');
    }
}

// --- BATALKAN PENGAJUAN ---
if ($act == 'batal' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);
    
    // Pastikan milik sendiri dan status masih Diajukan
    $cek = mysqli_query($koneksi, "SELECT status_pengajuan, file_pendukung FROM tbl_pengajuan_cuti WHERE id_pengajuan='$id' AND id_pjlp='$id_pjlp'");
    $d = mysqli_fetch_assoc($cek);

    if ($d && $d['status_pengajuan'] == 'Diajukan') {
        // Hapus file fisik jika ada
        if (!empty($d['file_pendukung']) && file_exists("assets/uploads/cuti/" . $d['file_pendukung'])) {
            unlink("assets/uploads/cuti/" . $d['file_pendukung']);
        }

        mysqli_query($koneksi, "DELETE FROM tbl_pengajuan_cuti WHERE id_pengajuan='$id'");
        set_notifikasi('success', 'Dibatalkan', 'Pengajuan berhasil ditarik kembali.');
    } else {
        set_notifikasi('error', 'Gagal', 'Pengajuan tidak bisa dibatalkan (Sudah diproses atau bukan milik Anda).');
    }
    echo "<script>window.location.href='index.php?page=pengajuan_cuti_pjlp';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Pengajuan Cuti & Izin</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Cuti</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-primary text-white py-3">
                <h6 class="card-title mb-0 text-white"><i class="bi bi-plus-circle me-2"></i>Buat Pengajuan Baru</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Jenis Pengajuan <span class="text-danger">*</span></label>
                        <select name="id_master_cuti" id="jenis_cuti" class="form-select" required onchange="cekSyaratFile()">
                            <option value="" disabled selected>-- Pilih Jenis --</option>
                            <?php
                            $q_mc = mysqli_query($koneksi, "SELECT * FROM tbl_master_cuti ORDER BY nama_cuti ASC");
                            while ($mc = mysqli_fetch_assoc($q_mc)) {
                                echo "<option value='{$mc['id_master_cuti']}' data-file='{$mc['memerlukan_file']}'>{$mc['nama_cuti']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Tanggal Mulai <span class="text-danger">*</span></label>
                        <input type="date" name="tgl_mulai" id="tgl_mulai" class="form-control" required onchange="hitungDurasi()">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Tanggal Selesai <span class="text-danger">*</span></label>
                        <input type="date" name="tgl_selesai" id="tgl_selesai" class="form-control" required onchange="hitungDurasi()">
                    </div>

                    <div class="alert alert-light border small text-center py-2 mb-3" id="info_durasi" style="display:none;">
                        Durasi: <span class="fw-bold text-primary">0 Hari</span>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Keterangan / Alasan</label>
                        <textarea name="keterangan_pjlp" class="form-control" rows="3" placeholder="Contoh: Sakit demam tinggi..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Lampiran Bukti <span id="label_wajib" class="text-danger d-none">*</span></label>
                        <input type="file" name="file_pendukung" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png">
                        <div class="form-text" style="font-size: 11px;">Surat Dokter / Bukti Pendukung (Max 2MB)</div>
                    </div>

                    <div class="d-grid">
                        <button type="submit" name="btn_ajukan" class="btn btn-primary">
                            <i class="bi bi-send me-1"></i> Kirim Pengajuan
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <h6 class="card-title mb-0">Riwayat Pengajuan Anda</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Tgl Pengajuan</th>
                                <th>Jenis</th>
                                <th>Periode</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = mysqli_query($koneksi, "
                                SELECT pc.*, mc.nama_cuti, u.nama_lengkap as approver
                                FROM tbl_pengajuan_cuti pc
                                JOIN tbl_master_cuti mc ON pc.id_master_cuti = mc.id_master_cuti
                                LEFT JOIN tbl_users u ON pc.id_user_penyetuju = u.id_user
                                WHERE pc.id_pjlp = '$id_pjlp'
                                ORDER BY pc.tgl_diajukan DESC
                            ");

                            if (mysqli_num_rows($query) > 0) {
                                while ($row = mysqli_fetch_assoc($query)) {
                            ?>
                            <tr>
                                <td class="ps-4">
                                    <small class="text-muted"><?= date('d/m/Y', strtotime($row['tgl_diajukan'])) ?></small>
                                </td>
                                <td>
                                    <span class="fw-bold text-dark"><?= $row['nama_cuti'] ?></span>
                                    <?php if($row['file_pendukung']): ?>
                                        <a href="assets/uploads/cuti/<?= $row['file_pendukung'] ?>" target="_blank" class="ms-1 text-primary"><i class="bi bi-paperclip"></i></a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small>
                                        <?= date('d M', strtotime($row['tgl_mulai'])) ?> - <?= date('d M Y', strtotime($row['tgl_selesai'])) ?>
                                        <br>
                                        <span class="text-muted">(<?= $row['jumlah_hari'] ?> Hari)</span>
                                    </small>
                                </td>
                                <td>
                                    <?php 
                                        if($row['status_pengajuan'] == 'Diajukan') 
                                            echo '<span class="badge bg-warning-subtle text-warning">Menunggu</span>';
                                        elseif($row['status_pengajuan'] == 'Disetujui') 
                                            echo '<span class="badge bg-success-subtle text-success">Disetujui</span>';
                                        else 
                                            echo '<span class="badge bg-danger-subtle text-danger">Ditolak</span>';
                                    ?>
                                </td>
                                <td class="text-end pe-4">
                                    <?php if($row['status_pengajuan'] == 'Diajukan'): ?>
                                        <button onclick="konfirmasiHapus('index.php?page=pengajuan_cuti_pjlp&act=batal&id=<?= $row['id_pengajuan'] ?>', 'Batalkan pengajuan ini?')" class="btn btn-sm btn-outline-danger" data-bs-toggle="tooltip" title="Batalkan">
                                            <i class="bi bi-x-lg"></i>
                                        </button>
                                    <?php else: ?>
                                        <?php if($row['catatan_atasan']): ?>
                                            <button type="button" class="btn btn-sm btn-light border" data-bs-toggle="popover" data-bs-trigger="focus" title="Catatan Atasan" data-bs-content="<?= $row['catatan_atasan'] ?>">
                                                <i class="bi bi-chat-text"></i>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php 
                                }
                            } else {
                                echo '<tr><td colspan="5" class="text-center py-5 text-muted"><img src="assets/img/no-data.jpg" height="80" class="mb-3 opacity-50"><br>Belum ada riwayat pengajuan.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Validasi & Hitung Durasi
    function hitungDurasi() {
        var start = new Date(document.getElementById('tgl_mulai').value);
        var end = new Date(document.getElementById('tgl_selesai').value);
        var info = document.getElementById('info_durasi');

        if (start && end && !isNaN(start) && !isNaN(end)) {
            // Hitung selisih waktu
            var diffTime = end - start;
            // Konversi ke hari (ms -> hari)
            var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; 

            if (diffDays > 0) {
                info.style.display = 'block';
                info.innerHTML = 'Durasi: <span class="fw-bold text-primary">' + diffDays + ' Hari</span>';
                info.classList.remove('alert-danger');
                info.classList.add('alert-light');
            } else {
                info.style.display = 'block';
                info.innerHTML = '<i class="bi bi-exclamation-circle me-1"></i> Tanggal Selesai salah!';
                info.classList.remove('alert-light');
                info.classList.add('alert-danger');
            }
        }
    }

    // Cek apakah perlu file
    function cekSyaratFile() {
        var select = document.getElementById('jenis_cuti');
        var option = select.options[select.selectedIndex];
        var isRequired = option.getAttribute('data-file');
        var labelWajib = document.getElementById('label_wajib');

        if (isRequired == '1') {
            labelWajib.classList.remove('d-none');
        } else {
            labelWajib.classList.add('d-none');
        }
    }

    // Init Popover
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
      return new bootstrap.Popover(popoverTriggerEl)
    })
</script>