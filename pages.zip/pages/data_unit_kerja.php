<?php
// 1. Keamanan: Hanya Admin yang boleh akses
if ($_SESSION['level'] != 'admin') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

// 2. Menangkap Parameter 'act' (action) dari URL
$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// PROSES LOGIC (SIMPAN, UPDATE, HAPUS)
// ==================================================================================

// --- PROSES SIMPAN DATA BARU ---
if (isset($_POST['btn_simpan'])) {
    $nama_unit = amankan_input($_POST['nama_unit_kerja']);

    // Validasi Duplikasi
    $cek = mysqli_query($koneksi, "SELECT nama_unit_kerja FROM tbl_unit_kerja WHERE nama_unit_kerja='$nama_unit'");
    if (mysqli_num_rows($cek) > 0) {
        set_notifikasi('warning', 'Duplikasi', 'Nama Unit Kerja sudah ada!');
        echo "<script>history.back();</script>";
        exit();
    }

    $query = "INSERT INTO tbl_unit_kerja (nama_unit_kerja) VALUES ('$nama_unit')";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Unit Kerja berhasil ditambahkan');
        echo "<script>window.location.href='index.php?page=data_unit_kerja';</script>";
        exit(); 
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan SQL');
    }
}

// --- PROSES UPDATE DATA ---
if (isset($_POST['btn_update'])) {
    $id_unit   = amankan_input($_POST['id_unit_kerja']);
    $nama_unit = amankan_input($_POST['nama_unit_kerja']);

    $query = "UPDATE tbl_unit_kerja SET nama_unit_kerja='$nama_unit' WHERE id_unit_kerja='$id_unit'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Berhasil', 'Unit Kerja berhasil diperbarui');
        echo "<script>window.location.href='index.php?page=data_unit_kerja';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan update');
    }
}

// --- PROSES HAPUS DATA ---
if ($act == 'hapus' && isset($_GET['id'])) {
    $id_unit = amankan_input($_GET['id']);
    
    // Cek Relasi Data (Mencegah error foreign key)
    // Cek di Tabel Kontrak
    $cek_kontrak = mysqli_query($koneksi, "SELECT id_kontrak FROM tbl_kontrak WHERE id_unit_kerja='$id_unit'");
    // Cek di Tabel DPA
    $cek_dpa     = mysqli_query($koneksi, "SELECT id_dpa FROM tbl_dpa WHERE id_unit_kerja='$id_unit'");

    if (mysqli_num_rows($cek_kontrak) > 0 || mysqli_num_rows($cek_dpa) > 0) {
        set_notifikasi('error', 'Gagal Hapus', 'Data ini sedang digunakan di Data Kontrak atau DPA. Hapus data terkait terlebih dahulu.');
        echo "<script>window.location.href='index.php?page=data_unit_kerja';</script>";
        exit();
    }

    $query = "DELETE FROM tbl_unit_kerja WHERE id_unit_kerja='$id_unit'";
    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Terhapus', 'Unit Kerja berhasil dihapus');
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem saat menghapus');
    }
    echo "<script>window.location.href='index.php?page=data_unit_kerja';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Data Master Unit Kerja</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Unit Kerja</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    // ==========================================================================
    // CASE 1: FORM TAMBAH (HORIZONTAL)
    // ==========================================================================
    case 'tambah':
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Tambah Unit Kerja</h5>
                    <a href="index.php?page=data_unit_kerja" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Unit Kerja <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_unit_kerja" class="form-control" required placeholder="Contoh: Bidang Kebersihan, Tata Usaha">
                                <div class="invalid-feedback">Nama unit kerja wajib diisi.</div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_simpan" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Data</button>
                                <button type="reset" class="btn btn-light">Reset</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // CASE 2: FORM EDIT (HORIZONTAL)
    // ==========================================================================
    case 'edit':
        $id = amankan_input($_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja WHERE id_unit_kerja='$id'");
        $d = mysqli_fetch_assoc($query);
        if (!$d) {
            echo "<script>window.location.href='index.php?page=data_unit_kerja';</script>";
            exit();
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Edit Unit Kerja</h5>
                    <a href="index.php?page=data_unit_kerja" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="id_unit_kerja" value="<?= $d['id_unit_kerja'] ?>">
                        
                        <div class="row mb-3">
                            <label class="col-sm-3 col-form-label text-end">Nama Unit Kerja <span class="text-danger">*</span></label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_unit_kerja" class="form-control" value="<?= $d['nama_unit_kerja'] ?>" required>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-sm-9 offset-sm-3 d-flex gap-2">
                                <button type="submit" name="btn_update" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA UNIT KERJA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Unit Kerja</h5>
                    <a href="index.php?page=data_unit_kerja&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Unit
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-nowrap table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Unit Kerja</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $query = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-xs bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center me-2">
                                                <i class="bi bi-building"></i>
                                            </div>
                                            <span class="fw-medium"><?= $row['nama_unit_kerja'] ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=data_unit_kerja&act=edit&id=<?= $row['id_unit_kerja'] ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <button onclick="konfirmasiHapus('index.php?page=data_unit_kerja&act=hapus&id=<?= $row['id_unit_kerja'] ?>')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>