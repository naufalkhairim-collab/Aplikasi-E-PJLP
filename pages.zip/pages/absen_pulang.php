<?php
// 1. Keamanan: Hanya PJLP
if ($_SESSION['level'] != 'pjlp') {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$id_pjlp = $_SESSION['id_user'];
$tgl_hari_ini = date('Y-m-d');

// 2. Ambil Data Kontrak & Lokasi
$q_kontrak = mysqli_query($koneksi, "
    SELECT k.id_kontrak, u.nama_unit_kerja, l.latitude, l.longitude, l.radius_meter, l.nama_lokasi
    FROM tbl_kontrak k
    JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
    JOIN tbl_lokasi_kantor l ON l.id_lokasi = (SELECT id_lokasi FROM tbl_lokasi_kantor LIMIT 1) 
    WHERE k.id_pjlp='$id_pjlp' AND k.status_kontrak='Aktif'
");
$d_kontrak = mysqli_fetch_assoc($q_kontrak);

if (!$d_kontrak) {
    echo '<div class="alert alert-danger">Data kontrak tidak ditemukan.</div>';
    exit();
}
$id_kontrak = $d_kontrak['id_kontrak'];

// 3. Cek Status Absensi Hari Ini
$q_absen = mysqli_query($koneksi, "SELECT * FROM tbl_absensi WHERE id_kontrak='$id_kontrak' AND tanggal='$tgl_hari_ini'");
$d_absen = mysqli_fetch_assoc($q_absen);

// Skenario A: Belum Absen Masuk
if (!$d_absen || empty($d_absen['jam_masuk'])) {
    set_notifikasi('warning', 'Belum Masuk', 'Anda belum melakukan absen masuk hari ini.');
    echo "<script>window.location.href='index.php?page=absen_masuk';</script>";
    exit();
}

// Skenario B: Sudah Absen Pulang
if (!empty($d_absen['jam_pulang'])) {
    ?>
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow border-0 text-center p-4">
                <div class="mb-3">
                    <i class="bi bi-house-door-fill text-primary" style="font-size: 5rem;"></i>
                </div>
                <h4 class="fw-bold">Sudah Absen Pulang</h4>
                <p class="text-muted">Terima kasih atas kerja keras Anda hari ini.</p>
                
                <div class="row g-2 mt-4">
                    <div class="col-6">
                        <div class="border rounded p-2">
                            <small class="text-muted d-block">Masuk</small>
                            <strong class="text-dark"><?= date('H:i', strtotime($d_absen['jam_masuk'])) ?></strong>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="border rounded p-2 bg-light">
                            <small class="text-muted d-block">Pulang</small>
                            <strong class="text-primary"><?= date('H:i', strtotime($d_absen['jam_pulang'])) ?></strong>
                        </div>
                    </div>
                </div>

                <a href="index.php" class="btn btn-outline-secondary mt-4">Kembali ke Dashboard</a>
            </div>
        </div>
    </div>
    <?php
    exit();
}

// ==================================================================================
// PROSES ABSEN PULANG
// ==================================================================================
if (isset($_POST['btn_pulang'])) {
    $lat_pulang  = $_POST['latitude'];
    $long_pulang = $_POST['longitude'];
    
    // Validasi GPS
    if(empty($lat_pulang) || empty($long_pulang)){
        set_notifikasi('error', 'Gagal', 'Lokasi GPS tidak terdeteksi.');
        echo "<script>history.back();</script>";
        exit();
    }

    $jam_skrg = date('H:i:s');

    // Upload Foto
    $foto_name = '';
    if (!empty($_FILES['foto_pulang']['name'])) {
        $ext = pathinfo($_FILES['foto_pulang']['name'], PATHINFO_EXTENSION);
        $foto_name = "pulang_" . $id_pjlp . "_" . date('Ymd_His') . "." . $ext;
        
        if (!file_exists("assets/uploads/absensi")) mkdir("assets/uploads/absensi", 0777, true);
        move_uploaded_file($_FILES['foto_pulang']['tmp_name'], "assets/uploads/absensi/" . $foto_name);
    } else {
        set_notifikasi('warning', 'Foto Wajib', 'Anda harus mengambil foto selfie!');
        echo "<script>history.back();</script>";
        exit();
    }

    // Update Database
    $query = "UPDATE tbl_absensi SET 
              jam_pulang='$jam_skrg', 
              foto_pulang='$foto_name', 
              lat_pulang='$lat_pulang', 
              long_pulang='$long_pulang' 
              WHERE id_absen='{$d_absen['id_absen']}'";

    if (mysqli_query($koneksi, $query)) {
        set_notifikasi('success', 'Hati-hati di Jalan', 'Absen pulang berhasil disimpan.');
        echo "<script>window.location.href='index.php';</script>";
        exit();
    } else {
        set_notifikasi('error', 'Gagal', 'Terjadi kesalahan sistem.');
    }
}
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body bg-warning text-dark rounded p-4 text-center">
                <h5 class="fw-bold mb-1 text-white">Form Absensi Pulang</h5>
                <p class="mb-0 text-white-50"><?= date('l, d F Y') ?></p>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-3">
                
                <div class="alert alert-light border-start border-4 border-success mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted">Anda Masuk Pukul</small>
                            <h5 class="fw-bold text-dark mb-0"><?= date('H:i', strtotime($d_absen['jam_masuk'])) ?> WIB</h5>
                        </div>
                        <div class="text-end">
                            <small class="text-muted">Durasi Kerja</small>
                            <?php
                                // Hitung selisih jam
                                $start = new DateTime($d_absen['jam_masuk']);
                                $now   = new DateTime();
                                $diff  = $start->diff($now);
                            ?>
                            <h6 class="fw-bold text-success mb-0"><?= $diff->h ?> Jam <?= $diff->i ?> Menit</h6>
                        </div>
                    </div>
                </div>

                <form action="" method="POST" enctype="multipart/form-data" id="formPulang">
                    <input type="hidden" name="latitude" id="lat">
                    <input type="hidden" name="longitude" id="long">

                    <div class="mb-3 position-relative">
                        <div id="map" style="height: 250px; border-radius: 12px; border: 1px solid #dee2e6;"></div>
                        
                        <div class="position-absolute bottom-0 start-0 w-100 p-2" style="z-index: 999;">
                            <div class="card border-0 shadow-sm bg-white bg-opacity-90 backdrop-blur">
                                <div class="card-body p-2 d-flex justify-content-between align-items-center">
                                    <div style="font-size: 11px;">
                                        <span class="text-muted">Jarak:</span>
                                        <strong id="info_jarak">Mencari...</strong>
                                    </div>
                                    <div id="status_radius">
                                        <span class="badge bg-secondary">GPS...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold small text-muted">Foto Selfie Pulang</label>
                        <div class="input-group">
                            <input type="file" name="foto_pulang" class="form-control" accept="image/*" capture="user" required>
                            <span class="input-group-text"><i class="bi bi-camera-fill"></i></span>
                        </div>
                    </div>

                    <button type="submit" name="btn_pulang" id="btn_submit" class="btn btn-secondary w-100 py-3 fw-bold rounded-pill shadow-sm" disabled>
                        <i class="bi bi-house-door me-1"></i> Mencari Lokasi...
                    </button>

                </form>
            </div>
        </div>

        <div class="text-center mt-3 mb-5">
            <a href="index.php" class="text-muted text-decoration-none small"><i class="bi bi-arrow-left"></i> Batal & Kembali</a>
        </div>

    </div>
</div>

<script>
    var kantorLat = <?= $d_kontrak['latitude'] ?>;
    var kantorLng = <?= $d_kontrak['longitude'] ?>;
    var radiusMax = <?= $d_kontrak['radius_meter'] ?>; 

    // Init Map
    var map = L.map('map', { zoomControl: false }).setView([kantorLat, kantorLng], 16);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '' }).addTo(map);

    // Marker Kantor
    var kantorIcon = L.divIcon({
        className: 'custom-div-icon',
        html: "<div style='background-color:#ffc107; width:15px; height:15px; border-radius:50%; border:2px solid white; box-shadow: 0 0 5px rgba(0,0,0,0.3);'></div>",
        iconSize: [15, 15], iconAnchor: [7, 7]
    });
    L.marker([kantorLat, kantorLng], {icon: kantorIcon}).addTo(map).bindPopup("<b>Kantor</b>").openPopup();

    // Lingkaran Radius
    var circle = L.circle([kantorLat, kantorLng], {
        color: '#ffc107', fillColor: '#ffc107', fillOpacity: 0.1, radius: radiusMax
    }).addTo(map);

    var userMarker;

    function getDistance(lat1, lon1, lat2, lon2) {
        var R = 6371; 
        var dLat = (lat2-lat1) * (Math.PI/180);
        var dLon = (lon2-lon1) * (Math.PI/180); 
        var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1*(Math.PI/180)) * Math.cos(lat2*(Math.PI/180)) * Math.sin(dLon/2) * Math.sin(dLon/2); 
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
        return Math.round(R * c * 1000); 
    }

    if (navigator.geolocation) {
        navigator.geolocation.watchPosition(function(position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;

            document.getElementById('lat').value = lat;
            document.getElementById('long').value = lng;

            if(userMarker) map.removeLayer(userMarker);
            userMarker = L.marker([lat, lng], {
                icon: L.icon({
                    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
                    iconSize: [25, 41], iconAnchor: [12, 41]
                })
            }).addTo(map);

            var jarak = getDistance(lat, lng, kantorLat, kantorLng);
            document.getElementById('info_jarak').innerText = jarak + " Meter";
            var statusRadius = document.getElementById('status_radius');
            var btnSubmit = document.getElementById('btn_submit');

            if(jarak <= radiusMax) {
                statusRadius.innerHTML = '<span class="badge bg-success">Bisa Pulang</span>';
                circle.setStyle({color: '#198754', fillColor: '#198754'});
                
                btnSubmit.disabled = false;
                btnSubmit.classList.remove('btn-secondary', 'btn-danger');
                btnSubmit.classList.add('btn-warning', 'text-white');
                btnSubmit.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i> KONFIRMASI PULANG';
            } else {
                statusRadius.innerHTML = '<span class="badge bg-danger">Terlalu Jauh</span>';
                circle.setStyle({color: '#dc3545', fillColor: '#dc3545'});
                
                btnSubmit.disabled = true;
                btnSubmit.classList.remove('btn-warning');
                btnSubmit.classList.add('btn-danger');
                btnSubmit.innerHTML = 'Lokasi Terlalu Jauh';
            }

        }, function(error) {
            alert('GPS Error: ' + error.message);
        }, { enableHighAccuracy: true });
    }
</script>

<style>
    .backdrop-blur { backdrop-filter: blur(5px); -webkit-backdrop-filter: blur(5px); }
</style>