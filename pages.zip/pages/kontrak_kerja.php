<?php
// 1. Keamanan: Hanya Admin & Keuangan (Read Only)
if (!in_array($_SESSION['level'], ['admin', 'keuangan', 'pimpinan'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$act = isset($_GET['act']) ? $_GET['act'] : '';

// ==================================================================================
// FUNGSI UPLOAD FILE
// ==================================================================================
function upload_file_kontrak($files) {
    $nama_file      = $files['name'];
    $ukuran_file    = $files['size'];
    $tmp_file       = $files['tmp_name'];
    $error          = $files['error'];
    $ekstensi_valid = ['pdf', 'jpg', 'jpeg', 'png'];
    
    // Cek apakah ada file yg diupload
    if ($error === 4) {
        return false; // Tidak ada file
    }

    // Cek Ekstensi
    $ekstensi_file = explode('.', $nama_file);
    $ekstensi_file = strtolower(end($ekstensi_file));
    if (!in_array($ekstensi_file, $ekstensi_valid)) {
        echo "<script>alert('Format file tidak valid! Harap upload PDF/JPG/PNG.');</script>";
        return false;
    }

    // Cek Ukuran (Max 2MB)
    if ($ukuran_file > 2000000) {
        echo "<script>alert('Ukuran file terlalu besar! Maksimal 2MB.');</script>";
        return false;
    }

    // Generate Nama Baru
    $nama_file_baru = "KONTRAK_" . time() . "_" . uniqid() . "." . $ekstensi_file;
    
    // Pindahkan File
    // Pastikan folder assets/uploads/kontrak/ sudah dibuat!
    move_uploaded_file($tmp_file, 'assets/uploads/kontrak/' . $nama_file_baru);

    return $nama_file_baru;
}

// ==================================================================================
// PROSES SIMPAN & UPDATE (TRANSAKSI RELASIONAL)
// ==================================================================================
if (isset($_POST['btn_simpan']) || isset($_POST['btn_update'])) {
    
    // Ambil Data Input
    $id_pjlp      = amankan_input($_POST['id_pjlp']);
    $id_unit      = amankan_input($_POST['id_unit_kerja']);
    $id_dpa       = amankan_input($_POST['id_dpa_detail']); // Sumber Dana
    $no_kontrak   = amankan_input($_POST['nomor_kontrak']);
    $tgl_mulai    = amankan_input($_POST['tgl_mulai_kontrak']);
    $tgl_selesai  = amankan_input($_POST['tgl_selesai_kontrak']);
    $status       = amankan_input($_POST['status_kontrak']);
    $gaji_pokok   = str_replace('.', '', amankan_input($_POST['gaji_pokok'])); // Hapus titik format ribuan

    // [REVISI 1] Proses File Upload
    $file_upload = upload_file_kontrak($_FILES['file_kontrak']);

    if (isset($_POST['btn_simpan'])) {
        // 1. Cek Apakah PJLP sudah punya kontrak AKTIF?
        $cek = mysqli_query($koneksi, "SELECT * FROM tbl_kontrak WHERE id_pjlp='$id_pjlp' AND status_kontrak='Aktif'");
        if (mysqli_num_rows($cek) > 0) {
            set_notifikasi('warning', 'Gagal', 'Pegawai ini masih memiliki kontrak Aktif.');
            echo "<script>history.back();</script>";
            exit();
        }

        // Jika upload gagal tapi bukan karena kosong (format salah dll), stop
        // Tapi kalau kosong ($file_upload === false), lanjut (boleh null)
        $nama_file_db = ($file_upload) ? $file_upload : NULL;

        // 2. Insert Kontrak ([REVISI 1] Tambah kolom file_kontrak)
        $q_kontrak = "INSERT INTO tbl_kontrak (id_pjlp, id_unit_kerja, id_dpa_detail, nomor_kontrak, tgl_mulai_kontrak, tgl_selesai_kontrak, status_kontrak, file_kontrak) 
                      VALUES ('$id_pjlp', '$id_unit', '$id_dpa', '$no_kontrak', '$tgl_mulai', '$tgl_selesai', '$status', '$nama_file_db')";
        
        if (mysqli_query($koneksi, $q_kontrak)) {
            // 3. Ambil ID Kontrak Barusan
            $new_id = mysqli_insert_id($koneksi);

            // 4. Insert Gaji Pokok ke tbl_gaji_pjlp
            $q_gaji = "INSERT INTO tbl_gaji_pjlp (id_kontrak, gaji_pokok) VALUES ('$new_id', '$gaji_pokok')";
            mysqli_query($koneksi, $q_gaji);

            set_notifikasi('success', 'Berhasil', 'Kontrak dan Gaji berhasil dibuat.');
            echo "<script>window.location.href='index.php?page=kontrak_kerja';</script>";
            exit();
        }
    } 
    else {
        // UPDATE
        $id_kontrak = amankan_input($_POST['id_kontrak']);
        
        // [REVISI 1] Logic Update File
        // Kalau user upload file baru ($file_upload ada isinya)
        if ($file_upload) {
            // Hapus file lama dulu
            $q_cek_file = mysqli_query($koneksi, "SELECT file_kontrak FROM tbl_kontrak WHERE id_kontrak='$id_kontrak'");
            $d_file = mysqli_fetch_assoc($q_cek_file);
            if (!empty($d_file['file_kontrak']) && file_exists("assets/uploads/kontrak/" . $d_file['file_kontrak'])) {
                unlink("assets/uploads/kontrak/" . $d_file['file_kontrak']);
            }
            // Tambahkan string update SQL
            $sql_file = ", file_kontrak='$file_upload'";
        } else {
            // User tidak upload file baru, jangan ubah kolom file
            $sql_file = "";
        }

        // 1. Update Tabel Kontrak
        $q_up_kontrak = "UPDATE tbl_kontrak SET 
                         id_pjlp='$id_pjlp', id_unit_kerja='$id_unit', id_dpa_detail='$id_dpa', 
                         nomor_kontrak='$no_kontrak', tgl_mulai_kontrak='$tgl_mulai', 
                         tgl_selesai_kontrak='$tgl_selesai', status_kontrak='$status' 
                         $sql_file 
                         WHERE id_kontrak='$id_kontrak'";
        mysqli_query($koneksi, $q_up_kontrak);

        // 2. Update Tabel Gaji (Cek dulu apa sudah ada barisnya)
        $cek_gaji = mysqli_query($koneksi, "SELECT id_gaji_pjlp FROM tbl_gaji_pjlp WHERE id_kontrak='$id_kontrak'");
        if(mysqli_num_rows($cek_gaji) > 0) {
            // Update
            $q_up_gaji = "UPDATE tbl_gaji_pjlp SET gaji_pokok='$gaji_pokok' WHERE id_kontrak='$id_kontrak'";
        } else {
            // Insert (Jika data lama tidak punya record gaji)
            $q_up_gaji = "INSERT INTO tbl_gaji_pjlp (id_kontrak, gaji_pokok) VALUES ('$id_kontrak', '$gaji_pokok')";
        }
        mysqli_query($koneksi, $q_up_gaji);

        set_notifikasi('success', 'Tersimpan', 'Data kontrak dan gaji diperbarui.');
        echo "<script>window.location.href='index.php?page=kontrak_kerja';</script>";
        exit();
    }
}

// HAPUS DATA
if ($act == 'hapus' && isset($_GET['id'])) {
    $id = amankan_input($_GET['id']);

    // [REVISI 1] Hapus File Fisik
    $q_cek_file = mysqli_query($koneksi, "SELECT file_kontrak FROM tbl_kontrak WHERE id_kontrak='$id'");
    $d_file = mysqli_fetch_assoc($q_cek_file);
    if (!empty($d_file['file_kontrak']) && file_exists("assets/uploads/kontrak/" . $d_file['file_kontrak'])) {
        unlink("assets/uploads/kontrak/" . $d_file['file_kontrak']);
    }

    // Hapus kontrak (Gaji akan terhapus otomatis jika diset CASCADE di database, tapi kita hapus manual untuk aman)
    mysqli_query($koneksi, "DELETE FROM tbl_gaji_pjlp WHERE id_kontrak='$id'");
    mysqli_query($koneksi, "DELETE FROM tbl_kontrak WHERE id_kontrak='$id'");
    
    set_notifikasi('success', 'Terhapus', 'Data kontrak dan file dihapus.');
    echo "<script>window.location.href='index.php?page=kontrak_kerja';</script>";
    exit();
}
?>

<div class="d-flex align-items-center mt-2 mb-4">
    <h6 class="mb-0 flex-grow-1">Manajemen Kontrak Kerja</h6>
    <div class="flex-shrink-0">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-end mb-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Kontrak</li>
            </ol>
        </nav>
    </div>
</div>

<?php
switch ($act) {
    case 'tambah':
    case 'edit':
        $is_edit = ($act == 'edit');
        $d = [];
        $gaji_val = 0;

        if ($is_edit) {
            $id_edit = amankan_input($_GET['id']);
            // Join ke Gaji PJLP untuk ambil nominalnya
            $q_edit = mysqli_query($koneksi, "
                SELECT k.*, g.gaji_pokok 
                FROM tbl_kontrak k 
                LEFT JOIN tbl_gaji_pjlp g ON k.id_kontrak = g.id_kontrak 
                WHERE k.id_kontrak='$id_edit'
            ");
            $d = mysqli_fetch_assoc($q_edit);
            $gaji_val = $d['gaji_pokok'];
        }
?>
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0 fw-bold text-primary">
                        <i class="bi bi-file-earmark-text me-2"></i><?= $is_edit ? 'Edit Kontrak & Gaji' : 'Buat Kontrak Baru' ?>
                    </h5>
                    <a href="index.php?page=kontrak_kerja" class="btn btn-light btn-sm"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                        <?php if($is_edit): ?>
                            <input type="hidden" name="id_kontrak" value="<?= $d['id_kontrak'] ?>">
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6 border-end">
                                <h6 class="fw-bold mb-3 text-secondary">A. Data Kontrak</h6>
                                
                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Pilih Pegawai (PJLP)</label>
                                    <select name="id_pjlp" class="form-select select2" required>
                                        <option value="" disabled selected>-- Cari Nama / NIK --</option>
                                        <?php
                                        // Tampilkan semua PJLP (di mode edit, yang terpilih akan muncul)
                                        $q_p = mysqli_query($koneksi, "SELECT id_pjlp, nama_lengkap, nik FROM tbl_pjlp ORDER BY nama_lengkap ASC");
                                        while($p = mysqli_fetch_assoc($q_p)){
                                            $sel = ($is_edit && $p['id_pjlp'] == $d['id_pjlp']) ? 'selected' : '';
                                            echo "<option value='{$p['id_pjlp']}' $sel>{$p['nama_lengkap']} - {$p['nik']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Nomor Kontrak (SPK)</label>
                                    <input type="text" name="nomor_kontrak" class="form-control" value="<?= $is_edit ? $d['nomor_kontrak'] : '' ?>" required placeholder="Contoh: 800/001/SPK/2025">
                                </div>

                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Tgl Mulai</label>
                                        <input type="date" name="tgl_mulai_kontrak" class="form-control" value="<?= $is_edit ? $d['tgl_mulai_kontrak'] : date('Y-01-01') ?>" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small fw-bold">Tgl Selesai</label>
                                        <input type="date" name="tgl_selesai_kontrak" class="form-control" value="<?= $is_edit ? $d['tgl_selesai_kontrak'] : date('Y-12-31') ?>" required>
                                    </div>
                                </div>

                                <div class="mb-3 mt-3">
                                    <label class="form-label small fw-bold">Status Kontrak</label>
                                    <select name="status_kontrak" class="form-select">
                                        <option value="Aktif" <?= ($is_edit && $d['status_kontrak'] == 'Aktif') ? 'selected' : '' ?>>Aktif</option>
                                        <option value="Berakhir" <?= ($is_edit && $d['status_kontrak'] == 'Berakhir') ? 'selected' : '' ?>>Berakhir / Non-Aktif</option>
                                    </select>
                                </div>

                                <div class="mb-3 bg-light p-2 rounded">
                                    <label class="form-label small fw-bold">Upload Scan Kontrak (PDF/JPG)</label>
                                    <input type="file" name="file_kontrak" class="form-control form-control-sm" accept=".pdf,.jpg,.jpeg,.png">
                                    <div class="form-text text-muted" style="font-size: 11px;">Maksimal 2MB.</div>
                                    
                                    <?php if($is_edit && !empty($d['file_kontrak'])): ?>
                                        <div class="mt-2 small">
                                            <i class="bi bi-paperclip"></i> File Saat ini: 
                                            <a href="assets/uploads/kontrak/<?= $d['file_kontrak'] ?>" target="_blank" class="text-decoration-none fw-bold"><?= $d['file_kontrak'] ?></a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-6 ps-4">
                                <h6 class="fw-bold mb-3 text-secondary">B. Penempatan & Gaji</h6>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Unit Kerja</label>
                                    <select name="id_unit_kerja" class="form-select" required>
                                        <option value="">-- Pilih Unit --</option>
                                        <?php
                                        $q_u = mysqli_query($koneksi, "SELECT * FROM tbl_unit_kerja ORDER BY nama_unit_kerja ASC");
                                        while($u = mysqli_fetch_assoc($q_u)){
                                            $sel = ($is_edit && $u['id_unit_kerja'] == $d['id_unit_kerja']) ? 'selected' : '';
                                            echo "<option value='{$u['id_unit_kerja']}' $sel>{$u['nama_unit_kerja']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small fw-bold">Sumber Anggaran (DPA)</label>
                                    <select name="id_dpa_detail" class="form-select" required>
                                        <option value="">-- Pilih Rekening DPA --</option>
                                        <?php
                                        // Join DPA Detail dengan Master Rekening untuk menampilkan nama rekening
                                        $q_dpa = mysqli_query($koneksi, "
                                            SELECT dd.id_dpa_detail, mr.kode_rekening, mr.nama_rekening, d.tahun_anggaran 
                                            FROM tbl_dpa_detail dd
                                            JOIN tbl_dpa d ON dd.id_dpa = d.id_dpa
                                            JOIN tbl_master_rekening mr ON dd.id_rekening = mr.id_rekening
                                            ORDER BY d.tahun_anggaran DESC, mr.kode_rekening ASC
                                        ");
                                        while($dp = mysqli_fetch_assoc($q_dpa)){
                                            $sel = ($is_edit && $dp['id_dpa_detail'] == $d['id_dpa_detail']) ? 'selected' : '';
                                            echo "<option value='{$dp['id_dpa_detail']}' $sel>[{$dp['tahun_anggaran']}] {$dp['kode_rekening']} - {$dp['nama_rekening']}</option>";
                                        }
                                        ?>
                                    </select>
                                    <div class="form-text">Gaji pegawai ini akan memotong anggaran rekening yang dipilih.</div>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label small fw-bold text-success">Gaji Pokok (Rp)</label>
                                    <div class="input-group input-group-lg">
                                        <span class="input-group-text bg-success text-white">Rp</span>
                                        <input type="number" name="gaji_pokok" class="form-control fw-bold text-success" value="<?= $is_edit ? $gaji_val : '' ?>" required placeholder="0">
                                    </div>
                                    <div class="form-text text-danger">* Input angka saja tanpa titik/koma.</div>
                                </div>

                            </div>
                        </div>

                        <hr class="my-4">
                        <div class="text-end">
                            <button type="submit" name="<?= $is_edit ? 'btn_update' : 'btn_simpan' ?>" class="btn btn-primary px-4">
                                <i class="bi bi-save me-1"></i> Simpan Data
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php
    break;

    // ==========================================================================
    // DEFAULT: LIST DATA
    // ==========================================================================
    default:
?>
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0 fw-bold">Data Kontrak Pegawai</h5>
                    <?php if($_SESSION['level'] == 'admin'): ?>
                    <a href="index.php?page=kontrak_kerja&act=tambah" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg me-1"></i> Tambah Kontrak
                    </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="default_datatable" class="table table-hover align-middle" style="width:100%">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Pegawai</th>
                                    <th>No. Kontrak / Periode</th>
                                    <th>Unit Kerja</th>
                                    <th>Gaji Pokok</th>
                                    <th>Status</th>
                                    <th>File</th> 
                                    <?php if($_SESSION['level'] == 'admin'): ?>
                                    <th width="10%">Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                // Join Lengkap: PJLP, Unit, dan Gaji
                                $query = mysqli_query($koneksi, "
                                    SELECT k.*, p.nama_lengkap, p.nik, u.nama_unit_kerja, g.gaji_pokok
                                    FROM tbl_kontrak k
                                    JOIN tbl_pjlp p ON k.id_pjlp = p.id_pjlp
                                    JOIN tbl_unit_kerja u ON k.id_unit_kerja = u.id_unit_kerja
                                    LEFT JOIN tbl_gaji_pjlp g ON k.id_kontrak = g.id_kontrak
                                    ORDER BY k.status_kontrak ASC, p.nama_lengkap ASC
                                ");
                                while ($row = mysqli_fetch_assoc($query)) {
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <span class="fw-bold text-dark"><?= $row['nama_lengkap'] ?></span><br>
                                        <small class="text-muted"><?= $row['nik'] ?></small>
                                    </td>
                                    <td>
                                        <span class="d-block small fw-bold"><?= $row['nomor_kontrak'] ?></span>
                                        <small class="text-muted">
                                            <?= date('d M Y', strtotime($row['tgl_mulai_kontrak'])) ?> s/d 
                                            <?= date('d M Y', strtotime($row['tgl_selesai_kontrak'])) ?>
                                        </small>
                                    </td>
                                    <td><?= $row['nama_unit_kerja'] ?></td>
                                    <td>
                                        <span class="fw-bold text-success">
                                            Rp <?= number_format($row['gaji_pokok'] ?? 0, 0, ',', '.') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($row['status_kontrak'] == 'Aktif'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger">Berakhir</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if (!empty($row['file_kontrak'])): ?>
                                            <a href="assets/uploads/kontrak/<?= $row['file_kontrak'] ?>" target="_blank" class="btn btn-sm btn-info text-white" title="Lihat Kontrak">
                                                <i class="bi bi-file-earmark-pdf"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>

                                    <?php if($_SESSION['level'] == 'admin'): ?>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="index.php?page=kontrak_kerja&act=edit&id=<?= $row['id_kontrak'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil-square"></i></a>
                                            <button onclick="konfirmasiHapus('index.php?page=kontrak_kerja&act=hapus&id=<?= $row['id_kontrak'] ?>')" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></button>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    break;
}
?>