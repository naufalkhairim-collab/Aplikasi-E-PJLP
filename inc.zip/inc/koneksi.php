<?php
// inc/koneksi.php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_pjlp";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Gagal terhubung ke database: " . mysqli_connect_error());
}

// Memulai session di awal koneksi agar bisa digunakan di seluruh halaman
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Set timezone ke Indonesia (WITA sesuai lokasi Anda, atau WIB/WIT)
date_default_timezone_set('Asia/Makassar'); 
?>