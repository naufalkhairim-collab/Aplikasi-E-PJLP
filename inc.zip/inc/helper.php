<?php
// inc/helper.php

/**
 * 1. FORMAT TANGGAL INDONESIA
 * Contoh: 2025-11-02 -> 02 November 2025
 */
function format_tanggal_indo($tanggal) {
    if($tanggal == '0000-00-00' || $tanggal == null) {
        return "-";
    }
    
    $bulan = array (
        1 => 'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    
    $pecahkan = explode('-', $tanggal);
    
    // Variabel pecahkan 0 = tahun, 1 = bulan, 2 = tanggal
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

/**
 * 2. FORMAT RUPIAH (OUTPUT)
 * Contoh: 1000000 -> 1.000.000
 */
function format_rupiah($angka) {
    if($angka == null || $angka == "") {
        return "0";
    }
    return number_format($angka, 0, ',', '.');
}

/**
 * 3. BERSIHKAN RUPIAH (INPUT DATABASE)
 * Digunakan saat menyimpan data. Menghapus titik (.) agar bisa masuk ke tipe data INT/DECIMAL/BIGINT
 * Contoh: 1.000.000 -> 1000000
 */
function bersihkan_rupiah($string_rupiah) {
    return str_replace('.', '', $string_rupiah);
}

/**
 * 4. FUNGSI GENERATE NOMOR OTOMATIS
 * Membuat nomor urut seperti: SPK-2025-001, TUGAS-001, dll
 * * $prefix = Kode depan (misal: "SPK-")
 * $tabel  = Nama tabel database
 * $kolom  = Nama kolom primary key/kode di tabel (misal: "nomor_kontrak")
 */
function generate_nomor($prefix, $tabel, $kolom) {
    global $koneksi;
    
    // Ambil data terakhir, urutkan dari yang terbesar
    $query = "SELECT $kolom FROM $tabel ORDER BY $kolom DESC LIMIT 1";
    $result = mysqli_query($koneksi, $query);
    $data   = mysqli_fetch_array($result);

    if ($data) {
        // Misal format: SPK-001. Kita ambil 3 angka terakhir
        // Sesuaikan panjang string jika format berbeda
        $kode_terakhir = $data[$kolom];
        
        // Ambil angka dari string (asumsi 3 digit terakhir adalah urutan)
        // Sesuaikan substr berdasarkan panjang prefix Anda
        $urutan = (int) substr($kode_terakhir, -3); 
        $urutan++;
    } else {
        // Jika belum ada data
        $urutan = 1;
    }

    // Format menjadi 3 digit (001, 002, dst)
    $kode_baru = $prefix . sprintf("%03s", $urutan);
    return $kode_baru;
}

/**
 * 5. MANAJEMEN NOTIFIKASI SWEETALERT2
 * * Cara pakai di proses PHP: 
 * set_notifikasi('success', 'Berhasil', 'Data berhasil disimpan');
 * header("Location: index.php");
 */

function set_notifikasi($icon, $title, $text) {
    $_SESSION['swal_icon']  = $icon;  // success, error, warning, info
    $_SESSION['swal_title'] = $title;
    $_SESSION['swal_text']  = $text;
}

function tampilkan_notifikasi() {
    if (isset($_SESSION['swal_icon'])) {
        $icon  = $_SESSION['swal_icon'];
        $title = $_SESSION['swal_title'];
        $text  = $_SESSION['swal_text'];

        echo "
        <script>
            Swal.fire({
                icon: '$icon',
                title: '$title',
                text: '$text',
                showConfirmButton: true,
                timer: 3000 // Otomatis hilang dalam 3 detik
            });
        </script>
        ";

        // Hapus session setelah ditampilkan agar tidak muncul terus menerus
        unset($_SESSION['swal_icon']);
        unset($_SESSION['swal_title']);
        unset($_SESSION['swal_text']);
    }
}

/**
 * 6. KEAMANAN SEDERHANA (Mencegah SQL Injection Dasar)
 * Karena tidak pakai prepared statement, wajib pakai ini untuk input string.
 */
function amankan_input($data) {
    global $koneksi;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($koneksi, $data);
}
?>